// >~~~~~~ Settings ~~~~~~~< //
global.prefix = ["!", "."];
global.owner = ["62895384520656", "62895417273523"]; // owner utama
global.bot = "jiraya x thin"; // nama bot
global.author = "XXTHIN";
global.pack = "jiraya x thin";
global.footer = "© Thin";
global.idch = "120363402305551203@newsletter";
global.namach = "— jiraya x thin";
global.thumb =
    "https://raw.githubusercontent.com/Rizkygamers/waifuim-img/main/uploads/image-1770038929156.jpg"; // gambar menu
global.audio = "https://files.catbox.moe/z4x5se.mp3"; // lagu pas di menu
global.ownme = "XXTHIN"; // nama owner
global.pair = "RIZKYDEV"; // bebas, harus 8 karakter kalau custom
global.thumbreply = "https://raw.githubusercontent.com/Rizkygamers/waifuim-img/main/uploads/image-1770038929156.jpg" // ukuran url gambar di sarankan kecil, kalau besar nnti lama loadnya
global.limitdef = 10 // default limit
global.limitres = 3 // hari reset limit

// >~~~~~~ Mess ~~~~~~~< //
global.mess = {
    wait: "⏳ Ehh tunggu bentar yaa~ Bot lagi prosesin 💕",
    error: "🚫 Aduu~ ada yang salah nih, coba lagi nanti ya onii-chan 🌸",
    admin: "❌️ Hmm~ fitur ini cuma bisa dipakai admin grup, gomen ne~",
    group: "❌️ Ehh~ fitur ini khusus di dalam grup aja loh~ 💬",
    owner: "❌️ Hyaa~ maaf ya, ini cuma buat ownerku tersayang ✨"
};

// >~~~~~~ Panel ~~~~~~~< //
global.egg = "15";
global.nestid = "5";
global.loc = "1";
global.domain = "https://domain.panelmu.my.id"; // harus ada https nya
global.apikey = ""; // API plta
global.capikey = ""; // API pltc

// >~~~~~~ Auto Sholat ~~~~~~~< //
export const JADWAL_SHOLAT = {
    Shubuh: "04:16",
    Dzuhur: "11:50",
    Ashr: "15:15",
    Maghrib: "18:06",
    Isya: "19:10"
};

export const SHOLAT_IMAGES = {
    subuh: "https://files.catbox.moe/g27j4g.jpg",
    dzuhur: "https://files.catbox.moe/8vq243.jpg",
    ashar: "https://files.catbox.moe/g27j4g.jpg",
    maghrib: "https://files.catbox.moe/l26yyh.jpg",
    isya: "https://files.catbox.moe/xh6q3w.jpg"
};

export const SHOLAT_AUDIOS = {
    subuh: "https://raw.githubusercontent.com/Rizkygamers/waifuim-img/main/uploads/audio-1769423046146.mp3",
    dzuhur: "https://raw.githubusercontent.com/Rizkygamers/waifuim-img/main/uploads/audio-1769423130539.mp3",
    ashar: "https://raw.githubusercontent.com/Rizkygamers/waifuim-img/main/uploads/audio-1769423130539.mp3",
    maghrib: "https://raw.githubusercontent.com/Rizkygamers/waifuim-img/main/uploads/audio-1769423130539.mp3",
    isya: "https://raw.githubusercontent.com/Rizkygamers/waifuim-img/main/uploads/audio-1769423130539.mp3"
};

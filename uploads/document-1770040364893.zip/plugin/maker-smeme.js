import axios from "axios";
import fs from "fs";
import { Sticker, StickerTypes } from "wa-sticker-formatter";
import { downloadContentFromMessage } from "baileys";
import UguuUpload from "../scrape/Uguu.js";
import CatboxMoe from "../scrape/CatBox.js";
import "../config.js";

export const command = ["smeme"];

async function getBuffer(message, type) {
    const stream = await downloadContentFromMessage(message, type);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

export default async function smeme(m, ctx) {
    const { riz, msg, reply, q } = ctx;

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (!quoted) return reply("❌ Reply gambar atau stiker!");

    const mediaMsg = quoted.imageMessage || quoted.stickerMessage;
    if (!mediaMsg) return reply("❌ Reply gambar atau stiker!");
    if (!q)
        return reply("contoh: .smeme atas|bawah\n.smeme atas\n.smeme bawah");

    const type = quoted.imageMessage ? "image" : "sticker";

    const buffer = await getBuffer(mediaMsg, type);

    // simpan temp
    const tmp = `./temp_${Date.now()}.jpg`;
    fs.writeFileSync(tmp, buffer);

    // upload (uguu -> catbox fallback)
    let upload;
    try {
        upload = await UguuUpload(tmp, "smeme.jpg");
    } catch {
        upload = await CatboxMoe(tmp);
    }

    fs.unlinkSync(tmp);

    const imageUrl = encodeURIComponent(upload.url);

    // parsing text
    const text = ctx.q || "";
    const [textT = "", textB = ""] = text.split("|").map(v => v.trim());

    let apiUrl = `https://api.nekolabs.web.id/canvas/meme?imageUrl=${imageUrl}`;
    if (textT) apiUrl += `&textT=${encodeURIComponent(textT)}`;
    if (textB) apiUrl += `&textB=${encodeURIComponent(textB)}`;

    const res = await axios.get(apiUrl, {
        responseType: "arraybuffer"
    });

    // kirim sebagai stiker
    const sticker = new Sticker(res.data, {
        pack: global.pack,
        author: global.author,
        type: StickerTypes.FULL,
        quality: 90
    });

    await riz.sendMessage(m.key.remoteJid, await sticker.toMessage(), {
        quoted: msg
    });
}

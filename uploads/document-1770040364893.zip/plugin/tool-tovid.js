import axios from "axios"
import fs from "fs"
import FormData from "form-data"
import * as cheerio from "cheerio"
import { downloadContentFromMessage } from "baileys"

export const command = ["tovid", "tovideo"]

async function webp2mp4File(path) {
  if (!fs.existsSync(path)) throw new Error("File tidak ditemukan")

  const form = new FormData()
  form.append("new-image-url", "")
  form.append("new-image", fs.createReadStream(path))

  const upload = await axios.post(
    "https://ezgif.com/webp-to-mp4",
    form,
    {
      headers: {
        ...form.getHeaders(),
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36"
      },
      maxRedirects: 5,
      timeout: 60000
    }
  )

  const $ = cheerio.load(upload.data)
  const file = $('input[name="file"]').attr("value")
  if (!file) throw new Error("Gagal upload ke ezgif")

  const form2 = new FormData()
  form2.append("file", file)
  form2.append("convert", "Convert WebP to MP4!")

  const convert = await axios.post(
    "https://ezgif.com/webp-to-mp4/" + file,
    form2,
    {
      headers: {
        ...form2.getHeaders(),
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36"
      },
      maxRedirects: 5,
      timeout: 60000
    }
  )

  const $$ = cheerio.load(convert.data)
  const src = $$("#output > p.outfile > video > source").attr("src")
  if (!src) throw new Error("Gagal ambil hasil convert")

  return "https:" + src
}

export default async function (m, { riz, reply, msg, qriz }) {
  try {

    const quoted =
      msg.message?.stickerMessage
        ? msg.message
        : msg.message?.extendedTextMessage?.contextInfo?.quotedMessage

    if (!quoted?.stickerMessage)
      return reply("Reply stickernya (animated) ya bang 🫡")

    const mime = quoted.stickerMessage.mimetype || ""
    if (!/webp/.test(mime))
      return reply("Sticker harus animated (webp)")

    reply("⏳ Converting...")

    const stream = await downloadContentFromMessage(
      quoted.stickerMessage,
      "sticker"
    )

    let buffer = Buffer.from([])
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk])
    }

    const tmp = `./temp_${Date.now()}.webp`
    fs.writeFileSync(tmp, buffer)

    const videoUrl = await webp2mp4File(tmp)

    await riz.sendMessage(
      m.chat,
      {
        video: { url: videoUrl },
        caption: "*Sticker → Video sukses*"
      },
      { quoted: qriz }
    )

    fs.unlinkSync(tmp)

  } catch (err) {
    console.error("TOVID ERROR:", err)
    reply("❌ Gagal convert sticker, coba lagi nanti")
  }
}
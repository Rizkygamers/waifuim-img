import "../config.js";
import axios from 'axios';

export const command = ["play"];

export default async (m, {
  reply, riz, isGroup, id, sender, q, qriz, isPremiumUser, getUserLimit, useUserLimit, DEFAULT_LIMIT, senderNum
}) => {
  if (!q) return reply(`Kasih judul nya dong Contoh:\n*.play Montagem Supersonic*`)

  if (!isPremiumUser) {
    const bisa = useUserLimit(senderNum, 1);
    if (!bisa) {
      return reply(
        `❌ Limit kamu sudah habis.\n\nSilakan hubungi owner untuk isi ulang premium / limit:\n${global.owner}`
      );
    }
    const sisa = getUserLimit(senderNum);
    reply(
      `🔢 Limit terpakai 1x.\nSisa limit kamu: *${sisa}* / ${DEFAULT_LIMIT}`
    );
  }

  reply(mess.wait);
  
  try {
    const apiUrl = `https://api.deline.web.id/downloader/ytplay?q=${encodeURIComponent(q)}`;
    const { data } = await axios.get(apiUrl);

    if (!data.status) return reply("❌ Gagal mencari lagu.");

    const result = data.result;
    const {
      title,
      url,
      thumbnail,
      pick,
      dlink
    } = result;

    const caption = `🎵 *${title}*\n🎵 Kualitas: ${pick.quality}\n💿 Format: ${pick.ext}\n📦 Ukuran: ${pick.size}\n🔗 [YouTube](${url})`;

    if (thumbnail) {
      await riz.sendMessage(id, {
        image: {
          url: thumbnail
        },
        caption
      }, {
        quoted: qriz
      });
    } else {
      reply(caption);
    }
    
    await riz.sendMessage(id, {
      audio: {
        url: dlink
      },
      mimetype: "audio/mpeg",
      fileName: `${title}.mp3`
    }, {
      quoted: qriz
    });

  } catch (err) {
    console.error("Error di .play:", err.message);
    reply("❌ Terjadi kesalahan saat memproses permintaan.");
  }
}
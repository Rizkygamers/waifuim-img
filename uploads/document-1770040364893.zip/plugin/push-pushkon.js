import fs from "fs"

export const command = ["pushkontak", "expushkontak"]

export default async function (m, {
  riz, id, isOwner, text, sender, reply, msg
}) {

  // ===========================
  // PUSHKONTAK (LIST GRUP)
  // ===========================
  if (msg.command === "pushkontak") {

    if (!isOwner) return reply("*Khusus Owner!*")
    if (!text) return reply("*Teksnya mana?*")

    global.textpushkontak = text

    const meta = await riz.groupFetchAllParticipating()
    const dom = Object.keys(meta)
    let list = []

    for (let i of dom) {
      list.push({
        title: meta[i].subject,
        id: `.expushkontak ${i}`,
        description: `${meta[i].participants.length} Member`
      })
    }

    return riz.sendMessage(id, {
      buttons: [{
        buttonId: 'action',
        buttonText: { displayText: 'Pilih Grup' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Pilih Grup Pushkontak',
            sections: [{
              title: 'Semua Grup',
              rows: [...list]
            }]
          })
        }
      }],
      footer: `Pushkontak Selector`,
      headerType: 1,
      viewOnce: true,
      text: "Pilih grup yang ingin dipush ⚡",
      contextInfo: {
        mentionedJid: [sender]
      }
    }, { quoted: msg })
  }


  // ===========================
  // EXPUSHKONTAK (AUTO VCF)
  // ===========================
  if (msg.command === "expushkontak") {

    if (!isOwner) return
    if (!text) return reply("Format salah!\n.expushkontak <id_grup>")
    if (!global.textpushkontak) return reply("Kamu belum mengisi teks pushkontak!")

    const idgc = text.trim()
    const pesan = global.textpushkontak

    // Ambil metadata grup
    let group
    try {
      group = await riz.groupMetadata(idgc)
    } catch {
      return reply("ID grup tidak valid!")
    }

    const members = group.participants
      .filter(m => m.id.endsWith(".net"))
      .map(m => m.id)

    reply(`🚀 *Memulai push ke grup:* ${group.subject}\n👥 Total Member: ${members.length}`)

    let kontakTerkirim = []

    for (let mem of members) {
      if (mem !== riz.user.id) {
        try {
          await riz.sendMessage(mem, { text: pesan })
          kontakTerkirim.push(mem)
          await delay(700) // biar aman
        } catch (err) {
          console.log("Gagal kirim:", mem, err)
        }
      }
    }

    // ===========================
    // Generate VCF
    // ===========================
    const unique = [...new Set(kontakTerkirim)]
    const vcf = unique.map(num => {
      let n = num.split("@")[0]
      return [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `FN:Kontak Buyer - ${n}`,
        `TEL;type=CELL;waid=${n}:+${n}`,
        "END:VCARD",
        ""
      ].join("\n")
    }).join("")

    // Simpan file
    const dir = "./database/pushkontak/"
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

    fs.writeFileSync(dir + "kontak.json", JSON.stringify(unique, null, 2))
    fs.writeFileSync(dir + "kontak.vcf", vcf, "utf8")

    // Kirim laporan
    await riz.sendMessage(id, {
      text: `✅ *Pushkontak Selesai!*\nBerhasil mengirim ke ${unique.length} member.`,
    })

    // Kirim file ke owner
    await riz.sendMessage(sender, {
      document: fs.readFileSync(dir + "kontak.vcf"),
      fileName: "kontak.vcf",
      caption: "Nih file VCF-nya bang",
      mimetype: "text/vcard"
    })

    await riz.sendMessage(sender, {
      document: fs.readFileSync(dir + "kontak.json"),
      fileName: "kontak.json",
      caption: "Nih daftar kontak-nya (JSON).",
      mimetype: "application/json"
    })

    delete global.textpushkontak
  }
}

// Delay function
const delay = ms => new Promise(res => setTimeout(res, ms))
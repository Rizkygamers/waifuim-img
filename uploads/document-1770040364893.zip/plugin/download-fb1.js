export const command = ["fb1"];

import axios from "axios";
import "../config.js";

async function fesnuk(u) {
    try {
        if (!/facebook\.com|fb\.watch/.test(u)) throw new Error("Invalid url");

        return await axios
            .post(
                "https://likeedownloader.com/process",
                new URLSearchParams({ id: u, locale: "en" }),
                {
                    headers: {
                        "User-Agent": "Mozilla/5.0 (Linux; Android 10)",
                        Accept: "application/json,text/javascript,*/*",
                        "x-requested-with": "XMLHttpRequest",
                        "Content-Type": "application/x-www-form-urlencoded",
                        origin: "https://likeedownloader.com",
                        referer:
                            "https://likeedownloader.com/facebook-video-downloader"
                    }
                }
            )
            .then(r => {
                if (!r?.data?.template) throw new Error("Fetch failed");

                function pick(re) {
                    const m = r.data.template.match(re);
                    return m ? m[1] : null;
                }

                const link = [];
                for (const m of r.data.template.matchAll(
                    /href="([^"]+)"[^>]*download/g
                )) {
                    link.push(m[1]);
                }

                return {
                    thumb: pick(/<img[^>]+src="([^"]+)"/),
                    sd: link[0] || null,
                    hd: link[1] || null
                };
            });
    } catch (e) {
        return { status: "error", msg: e.message };
    }
}

export default async (
    m,
    {
        q,
        reply,
        riz,
        id,
        msg,
        qriz,
        isPremiumUser,
        useUserLimit,
        getUserLimit,
        senderNum,
        DEFAULT_LIMIT
    }
) => {
    if (!q)
        return reply(
            "🔗 Masukkan URL Facebook!\nContoh:\n.fb1 https://www.facebook.com/reel/xxxxx"
        );

    if (!isPremiumUser) {
        const ok = useUserLimit(senderNum, 1);
        if (!ok) {
            return reply(
                `❌ Limit habis.\nHubungi owner untuk premium.\n${global.owner}`
            );
        }
        reply(
            `🔢 Limit terpakai 1x\nSisa: *${getUserLimit(
                senderNum
            )}* / ${DEFAULT_LIMIT}`
        );
    }

    await riz.sendMessage(id, {
        react: { text: "⏳", key: msg.key }
    });

    const res = await fesnuk(q);

    if (res.status === "error") {
        await riz.sendMessage(id, {
            react: { text: "❌", key: msg.key }
        });
        return reply("❌ Gagal mengambil video Facebook.");
    }

    const videoUrl = res.hd || res.sd;
    if (!videoUrl) {
        await riz.sendMessage(id, {
            react: { text: "❌", key: msg.key }
        });
        return reply("❌ Video tidak tersedia (HD & SD kosong).");
    }

    await riz.sendMessage(id, {
        video: { url: videoUrl },
        caption: `🎥 Facebook Video\nKualitas: *${res.hd ? "HD" : "SD"}*`,
        quoted: qriz
    });

    await riz.sendMessage(id, {
        react: { text: "✅", key: msg.key }
    });
};

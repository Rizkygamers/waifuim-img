export const command = ["tagme"];

export default async function pluginRun(msg, ctx) {
    const { riz, id, senderNum, reply, qriz } = ctx;
    
    reply(`@${senderNum} `)
}
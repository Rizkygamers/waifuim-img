export const command = ["sc", "script"];

export default async function (m, { riz, id, qriz }) {
    const teks = `
#WTS
 *Script Tsukasa Bot 🤖*
› *Price:* Rp 28.000

 *Information for users 💬*
- Harga di atas sudah mendapatkan Free update 1x
- Total fitur aktif 200+
- Type caseXplugins (ESM)
- Stabil
- No bad sesions 
- No Hasil rename
- Baileys: npm:wileys
- Support button

*⭐ Chek Fitur bot*
https://chat.whatsapp.com/KOeWjgYT2ks5sFGD0hbbY8
  `;

    const image = "https://i.ibb.co/S7nzBzSz/2f27b871c754.jpg";

    await riz.sendMessage(
        id,
        {
            image: { url: image },
            caption: teks,
            footer: "Tsukasa Bot © 2025",
            interactiveButtons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "💬 Chat via Telegram",
                        url: "https://t.me/RizkyoktavianCihuy"
                    })
                },
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "💬 Chat via Whatsapp",
                        url: "https://wa.me/62895417273523?text=Buy+sc+dong"
                    })
                }
            ]
        },
        {
            quoted: qriz
        }
    );
}

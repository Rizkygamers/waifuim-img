// jarr officiall.
// t.me/jarroffc2 


global.allmenu = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Other Menu\`\`\`
       ⌯ ${prfx}profile
       ⌯ ${prfx}ping
       ⌯ ${prfx}runtime
       ⌯ ${prfx}owner
       ⌯ ${prfx}tqto
       ⌯ ${prfx}script
       ⌯ ${prfx}totalfitur
       ⌯ ${prfx}info
       ⌯ ${prfx}report
       ⌯  ${prfx}cekidch 
   
     \`\`\`Maker Menu\`\`\`
       ⌯ ${prfx}sticker
       ⌯ ${prfx}smeme
       ⌯ ${prfx}brat
       ⌯ ${prfx}cewebrat
       ⌯ ${prfx}bratanime
       ⌯ ${prfx}bratvid
       ⌯ ${prfx}emojimix
       ⌯ ${prfx}qc
       ⌯ ${prfx}iqc
       ⌯ ${prfx}ytcoment
       ⌯ ${prfx}snapcode
       ⌯ ${prfx}fakestoryig
       ⌯ ${prfx}fakexnxx
       ⌯ ${prfx}fakeff
       ⌯ ${prfx}fbcoment
       ⌯ ${prfx}fakecall 
       ⌯ ${prfx}buatlogo
       ⌯ ${prfx}tempo 
   
     \`\`\`Store Menu\`\`\`
       ⌯ ${prfx}jpm 
       ⌯ ${prfx}jpmtesti 
       ⌯ ${prfx}stopjpm
       ⌯ ${prfx}bljpm
       ⌯ ${prfx}unbljpm
       ⌯ ${prfx}listbljpm 
       ⌯ ${prfx}addidch 
       ⌯ ${prfx}listidch
       ⌯ ${prfx}delidch
       ⌯ ${prfx}jpmch 
       ⌯ ${prfx}payment 
       ⌯ ${prfx}addlist
       ⌯ ${prfx}dellist
       ⌯ ${prfx}getlist
       ⌯ ${prfx}formatjp
       ⌯ ${prfx}formatneed
       ⌯ ${prfx}proses
       ⌯ ${prfx}done 
   
     \`\`\`AI Question\`\`\`
       ⌯ ${prfx}ai <question>
       ⌯ ${prfx}plxai <question>
       ⌯ ${prfx}shota <question>
       ⌯ ${prfx}copilot <question>
       ⌯ ${prfx}gemini <question>
       ⌯ ${prfx}gpt <question>
       ⌯ ${prfx}turboseek <question>
       ⌯ ${prfx}publicai <question>
       ⌯ ${prfx}ppxai <question>
       ⌯ ${prfx}groq <question> 
   
     \`\`\`AI Image\`\`\`
       ⌯ ${prfx}topromt
       ⌯ ${prfx}tofigure
       ⌯ ${prfx}tohitam
       ⌯ ${prfx}cinematic
       ⌯ ${prfx}editimg
       ⌯ ${prfx}genai
       ⌯ ${prfx}torealistis
       ⌯ ${prfx}toghibi 
       ⌯ ${prfx}toanime
       ⌯ ${prfx}txt2img 
    
     \`\`\`Domain Menu\`\`\`
       ⌯ ${prfx}domain 
       ⌯ ${prfx}listsubdo
       ⌯ ${prfx}delsubdo
       ⌯ ${prfx}celarsubdo 
   
     \`\`\`Panelv1 Menu\`\`\`
       ⌯ ${prfx}aksesgc 
       ⌯ ${prfx}delaksesgc
       ⌯ ${prfx}listaksesgc 
       ⌯ ${prfx}1gb unlimited 
       ⌯ ${prfx}listpanel
       ⌯ ${prfx}delpanel
       ⌯ ${prfx}cadmin
       ⌯ ${prfx}listadmin
       ⌯ ${prfx}deladmin 
       ⌯ ${prfx}clearserver
       ⌯ ${prfx}addserver
       ⌯ ${prfx}gantipwpanel 
   
     \`\`\`Panelv2 Menu\`\`\`
       ⌯ ${prfx}aksesgc2
       ⌯ ${prfx}delaksesgc2
       ⌯ ${prfx}listaksesgc2
       ⌯ ${prfx}1gb2 unlimited2
       ⌯ ${prfx}listpanel2
       ⌯ ${prfx}delpanel2
       ⌯ ${prfx}cadmin2
       ⌯ ${prfx}listadmin2
       ⌯ ${prfx}deladmin2
       ⌯ ${prfx}clearserver2
       ⌯ ${prfx}addserver2
       ⌯ ${prfx}gantipwpanel2 
   
     \`\`\`Tools Menu\`\`\`
       ⌯ ${prfx}unblur
       ⌯ ${prfx}kompresfoto
       ⌯ ${prfx}ocr
       ⌯ ${prfx}ssweb
       ⌯ ${prfx}toimg
       ⌯ ${prfx}toivid
       ⌯ ${prfx}tomp3
       ⌯ ${prfx}tovn
       ⌯ ${prfx}hd
       ⌯ ${prfx}removebg
       ⌯ ${prfx}rvo
       ⌯ ${prfx}tourl
       ⌯ ${prfx}swm
       ⌯ ${prfx}whatmusik
       ⌯ ${prfx}cariasci
       ⌯ ${prfx}toascii
       ⌯ ${prfx}translate  
       ⌯ ${prfx}upvidey  
       
     \`\`\`Download Menu\`\`\`
       ⌯ ${prfx}tiktok <url>
       ⌯ ${prfx}play <title>
       ⌯ ${prfx}douyin <url>
       ⌯ ${prfx}mediafire <title>
       ⌯ ${prfx}Instagram <url>
       ⌯ ${prfx}pindl <url>
       ⌯ ${prfx}twitter <title>
       ⌯ ${prfx}fbdl <url>
       ⌯ ${prfx}capcut <url>
       ⌯ ${prfx}spotify <url>
       ⌯ ${prfx}gitclone <url>
       ⌯ ${prfx}sfile <url>
       ⌯ ${prfx}ytmp3 <url>
       ⌯ ${prfx}ytmp4 <url>
       ⌯ ${prfx}apple <url>
       ⌯ ${prfx}spotify <url> 
   
     \`\`\`Search Menu\`\`\`
       ⌯ ${prfx}yst 
       ⌯ ${prfx}spotifys
       ⌯ ${prfx}wastalk
       ⌯ ${prfx}ttsearch
       ⌯ ${prfx}novel
       ⌯ ${prfx}lirik 
       ⌯ ${prfx}ttstalk
       ⌯ ${prfx}igstalk
       ⌯ ${prfx}ytstalk
       ⌯ ${prfx}stickerly
       ⌯ ${prfx}roblox
       ⌯ ${prfx}gitstalk
       ⌯ ${prfx}twstalk
       ⌯ ${prfx}mlstalk
       ⌯ ${prfx}ffstalk
       ⌯ ${prfx}pinterest
       ⌯ ${prfx}bstation
       ⌯ ${prfx}playstore
       ⌯ ${prfx}npm
       ⌯ ${prfx}applesearch
       ⌯ ${prfx}sfilesearch
   
     \`\`\`Sewa Menu\`\`\`
       ⌯ ${prfx}addsewa 
       ⌯ ${prfx}listsewa
       ⌯ ${prfx}delsewa
       ⌯ ${prfx}payment 
       ⌯ ${prfx}sewa 
   
     \`\`\`Grup Menu\`\`\`
       ⌯ ${prfx}add/kick 
       ⌯ ${prfx}acc/reject 
       ⌯ ${prfx}promote/demote
       ⌯ ${prfx}open/close
       ⌯ ${prfx}hidetag
       ⌯ ${prfx}tagall
       ⌯ ${prfx}totag
       ⌯ ${prfx}intro
       ⌯ ${prfx}afk
       ⌯ ${prfx}linkgc
       ⌯ ${prfx}resetlinkgc
       ⌯ ${prfx}editdesk
       ⌯ ${prfx}setnamagc
       ⌯ ${prfx}on
       ⌯ ${prfx}mute 62xx
       ⌯ ${prfx}unmute 62xx
       ⌯ ${prfx}listmute
       ⌯ ${prfx}autosholat (on/off)
       ⌯ ${prfx}antisticker (on/off)
       ⌯ ${prfx}welcome (on/off)
       ⌯ ${prfx}antitagsw (on/off)
       ⌯ ${prfx}antilinkch (on/off)
       ⌯ ${prfx}antilinkall (on/off)
       ⌯ ${prfx}antitoxic (on/off)
       ⌯ ${prfx}antipromosi (on/off)
       ⌯ ${prfx}antilinkgc (on/off)
   
     \`\`\`Setbot Menu\`\`\` 
       ⌯ ${prfx}setppbot
       ⌯ ${prfx}delppbot
       ⌯ ${prfx}banuser <nomornya>
       ⌯ ${prfx}setbot <cek status fitur>
       ⌯ ${prfx}anticall (on/off)
       ⌯ ${prfx}autoread (on/off)
       ⌯ ${prfx}autoreadsw (on/off)
       ⌯ ${prfx}autotyping (on/off)
       ⌯ ${prfx}gconly (on/off)
       ⌯ ${prfx}pconly (on/off)
       ⌯ ${prfx}mode private/public
       ⌯ ${prfx}mode
       ⌯ ${prfx}setprefix 
       ⌯ ${prfx}perfix 
       ⌯ ${prfx}delprefix 
   
     \`\`\`Owners Menu\`\`\` 
       ⌯ ${prfx}addplugin
       ⌯ ${prfx}saveplugin
       ⌯ ${prfx}listplugin
       ⌯ ${prfx}delplugin  
       ⌯ ${prfx}backupsc
       ⌯ ${prfx}restart
       ⌯ ${prfx}clearsesion 
       ⌯ ${prfx}addowner
       ⌯ ${prfx}listowner
       ⌯ ${prfx}delowner
       ⌯ ${prfx}banuser
       ⌯ ${prfx}unbanuser
       ⌯ ${prfx}listban  
       ⌯ ${prfx}upch <txt|img|vid|aud> 
       ⌯ ${prfx}playch <title>
       ⌯ ${prfx}toptv
       ⌯ ${prfx}block  
       ⌯ ${prfx}unblock 
       ⌯ ${prfx}buatgc
       ⌯ ${prfx}joinch 
       ⌯ ${prfx}delete <hps pesan>
       ⌯ ${prfx}get <url>
       ⌯ ${prfx}semat <reply pesan>
       ⌯ ${prfx}pol
       ⌯ ${prfx}upswgc
       ⌯ ${prfx}tolid
       ⌯ ${prfx}rch 
       ⌯ ${prfx}simulasi 
       ⌯ ${prfx}bangc 
       ⌯ ${prfx}unbangc 
       ⌯ ${prfx}listbangc 
       ⌯ ${prfx}getfile 
       ⌯ ${prfx}gantifile 
       ⌯ ${prfx}eval
       ⌯ ${prfx}q
       ⌯ ${prfx}$
       ⌯ ${prfx}>
   
     \`\`\`Scurity Menu\`\`\`
       ⌯ ${prfx}adddb <nomor nya>
       ⌯ ${prfx}deldb <nomor nya>
       ⌯ ${prfx}listdb (cek all nomor)
   
     \`\`\`Islam Menu\`\`\`
       ⌯ ${prfx}listsurah
       ⌯ ${prfx}alquranaudio
       ⌯ ${prfx}kisahnabi
       ⌯ ${prfx}jadwal-sholat
       ⌯ ${prfx}ayatkursi
       ⌯ ${prfx}doaharian
   
     \`\`\`Game Menu\`\`\`
       ⌯ ${prfx}bucin 
       ⌯ ${prfx}gombal 
       ⌯ ${prfx}katakata 
       ⌯ ${prfx}motivasi 
       ⌯ ${prfx}family100
       ⌯ ${prfx}caklontong 
       ⌯ ${prfx}tebakgambar
       ⌯ ${prfx}susunkata
       ⌯ ${prfx}siapaaku
       ⌯ ${prfx}tebakkata
       ⌯ ${prfx}lengkapikalimat
       ⌯ ${prfx}tebakkimia
       ⌯ ${prfx}tebaklirik
       ⌯ ${prfx}tebaktebakan
       ⌯ ${prfx}nyerah
   
     \`\`\`Asupan Menu\`\`\`
       ⌯ ${prfx}asupan
       ⌯ ${prfx}loli
       ⌯ ${prfx}bluearchive
       ⌯ ${prfx}cecan-korea
       ⌯ ${prfx}cecan-china
       ⌯ ${prfx}cecan-vietnam
       ⌯ ${prfx}cosplay
   
     \`\`\`RPG Menu\`\`\`
       ⌯ ${prfx}adventure 
       ⌯ ${prfx}bank 
       ⌯ ${prfx}berburu 
       ⌯ ${prfx}klaim 
       ⌯ ${prfx}inventory 
       ⌯ ${prfx}kerja
       ⌯ ${prfx}memancing 
       ⌯ ${prfx}menambang 
       ⌯ ${prfx}stats 
       ⌯ ${prfx}shop
       ⌯ ${prfx}judi 
       ⌯ ${prfx}begal 
       ⌯ ${prfx}transfer`
   }
// ===================================//
global.random= () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Other Menu\`\`\`
       ⌯ ${prfx}profile
       ⌯ ${prfx}ping
       ⌯ ${prfx}owner
       ⌯ ${prfx}tqto
       ⌯ ${prfx}script
       ⌯ ${prfx}totalfitur
       ⌯ ${prfx}info
       ⌯ ${prfx}report
       ⌯ ${prfx}cekidch`
   }
// ===================================//
global.store= () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Store Menu\`\`\`
       ⌯ ${prfx}jpm 
       ⌯ ${prfx}jpmtesti 
       ⌯ ${prfx}stopjpm
       ⌯ ${prfx}bljpm
       ⌯ ${prfx}unbljpm
       ⌯ ${prfx}listbljpm 
       ⌯ ${prfx}addidch 
       ⌯ ${prfx}listidch
       ⌯ ${prfx}delidch
       ⌯ ${prfx}jpmch 
       ⌯ ${prfx}payment 
       ⌯ ${prfx}addlist
       ⌯ ${prfx}dellist
       ⌯ ${prfx}getlist
       ⌯ ${prfx}formatjp
       ⌯ ${prfx}formatneed
       ⌯ ${prfx}proses
       ⌯ ${prfx}done`
   }
// ===================================//
global.aimenu = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`      \`\`\`AI Question\`\`\`
       ⌯ ${prfx}ai <question>
       ⌯ ${prfx}plxai <question>
       ⌯ ${prfx}shota <question>
       ⌯ ${prfx}copilot <question>
       ⌯ ${prfx}gemini <question>
       ⌯ ${prfx}gpt <question>
       ⌯ ${prfx}turboseek <question>
       ⌯ ${prfx}publicai <question>
       ⌯ ${prfx}ppxai <question>
       ⌯ ${prfx}groq <question>`
   }
// ===================================//
global.aiimg = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`       \`\`\`AI Image\`\`\`
       ⌯ ${prfx}topromt
       ⌯ ${prfx}tofigure
       ⌯ ${prfx}tohitam
       ⌯ ${prfx}cinematic
       ⌯ ${prfx}editimg
       ⌯ ${prfx}genai
       ⌯ ${prfx}torealistis
       ⌯ ${prfx}toghibi 
       ⌯ ${prfx}toanime
       ⌯ ${prfx}txt2img`
   }
// ===================================//
global.ownmenu = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Domain Menu\`\`\` 
       ⌯ ${prfx}domain 
       ⌯ ${prfx}listsubdo
       ⌯ ${prfx}delsubdo
       ⌯ ${prfx}celarsubdo
   
     \`\`\`Panelv1 Menu\`\`\` 
       ⌯ ${prfx}aksesgc 
       ⌯ ${prfx}delaksesgc
       ⌯ ${prfx}listaksesgc 
       ⌯ ${prfx}1gb - unlimited 
       ⌯ ${prfx}listpanel
       ⌯ ${prfx}delpanel
       ⌯ ${prfx}cadmin
       ⌯ ${prfx}listadmin
       ⌯ ${prfx}deladmin 
       ⌯ ${prfx}clearserver
       ⌯ ${prfx}addserver
       ⌯ ${prfx}gantipwpanel
   
     \`\`\`Panelv2 Menu\`\`\` 
       ⌯ ${prfx}aksesgc2
       ⌯ ${prfx}delaksesgc2
       ⌯ ${prfx}listaksesgc2
       ⌯ ${prfx}1gb2 unlimited2
       ⌯ ${prfx}listpanel2
       ⌯ ${prfx}delpanel2
       ⌯ ${prfx}cadmin2
       ⌯ ${prfx}listadmin2
       ⌯ ${prfx}deladmin2
       ⌯ ${prfx}clearserver2
       ⌯ ${prfx}addserver2
       ⌯ ${prfx}gantipwpanel2
   
     \`\`\`Setbot Menu\`\`\` 
       ⌯ ${prfx}setppbot
       ⌯ ${prfx}delppbot
       ⌯ ${prfx}banuser <nomornya>
       ⌯ ${prfx}setbot <cek status fitur>
       ⌯ ${prfx}anticall (on/off)
       ⌯ ${prfx}autoread (on/off)
       ⌯ ${prfx}autoreadsw (on/off)
       ⌯ ${prfx}autotyping (on/off)
       ⌯ ${prfx}gconly (on/off)
       ⌯ ${prfx}pconly (on/off)
       ⌯ ${prfx}mode private/public
       ⌯ ${prfx}mode
       ⌯ ${prfx}setprefix 
       ⌯ ${prfx}perfix 
       ⌯ ${prfx}delprefix 
   
     \`\`\`Owners Menu\`\`\` 
       ⌯ ${prfx}addplugin
       ⌯ ${prfx}saveplugin
       ⌯ ${prfx}listplugin
       ⌯ ${prfx}delplugin  
       ⌯ ${prfx}backupsc
       ⌯ ${prfx}restart
       ⌯ ${prfx}clearsesion 
       ⌯ ${prfx}addowner
       ⌯ ${prfx}listowner
       ⌯ ${prfx}delowner
       ⌯ ${prfx}banuser
       ⌯ ${prfx}unbanuser
       ⌯ ${prfx}listban  
       ⌯ ${prfx}upch <txt|img|vid|aud> 
       ⌯ ${prfx}playch <title>
       ⌯ ${prfx}toptv
       ⌯ ${prfx}block  
       ⌯ ${prfx}unblock 
       ⌯ ${prfx}buatgc
       ⌯ ${prfx}joinch 
       ⌯ ${prfx}delete <hps pesan>
       ⌯ ${prfx}get <url>
       ⌯ ${prfx}semat <reply pesan>
       ⌯ ${prfx}pol
       ⌯ ${prfx}upswgc
       ⌯ ${prfx}tolid
       ⌯ ${prfx}rch 
       ⌯ ${prfx}simulasi 
       ⌯ ${prfx}bangc 
       ⌯ ${prfx}unbangc 
       ⌯ ${prfx}listbangc 
       ⌯ ${prfx}getfile 
       ⌯ ${prfx}gantifile 
       ⌯ ${prfx}eval
       ⌯ ${prfx}q
       ⌯ ${prfx}$
       ⌯ ${prfx}>
   
     \`\`\`Scurity Menu\`\`\` 
       ⌯ ${prfx}adddb <nomor nya>
       ⌯ ${prfx}deldb <nomor nya>
       ⌯ ${prfx}listdb (cek all nomor)
   
     \`\`\`Sewa Menu\`\`\` 
       ⌯ ${prfx}addsewa 
       ⌯ ${prfx}listsewa
       ⌯ ${prfx}delsewa
       ⌯ ${prfx}payment 
       ⌯ ${prfx}sewa`
   }
// ===================================//
global.tools = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Tools Menu\`\`\`
       ⌯ ${prfx}unblur
       ⌯ ${prfx}kompresfoto
       ⌯ ${prfx}ocr
       ⌯ ${prfx}ssweb
       ⌯ ${prfx}toimg
       ⌯ ${prfx}toivid
       ⌯ ${prfx}tomp3
       ⌯ ${prfx}tovn
       ⌯ ${prfx}hd
       ⌯ ${prfx}removebg
       ⌯ ${prfx}rvo
       ⌯ ${prfx}tourl
       ⌯ ${prfx}swm
       ⌯ ${prfx}whatmusik
       ⌯ ${prfx}cariasci
       ⌯ ${prfx}toascii
       ⌯ ${prfx}translate  
       ⌯ ${prfx}upvidey  `
   }
// ===================================//
global.download = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Download Menu\`\`\` 
       ⌯ ${prfx}tiktok <url>
       ⌯ ${prfx}play <title>
       ⌯ ${prfx}douyin <title>
       ⌯ ${prfx}mediafire <title>
       ⌯ ${prfx}Instagram <url>
       ⌯ ${prfx}pindl <url>
       ⌯ ${prfx}twitter <title>
       ⌯ ${prfx}fbdl <url>
       ⌯ ${prfx}capcut <url>
       ⌯ ${prfx}spotify <url>
       ⌯ ${prfx}gitclone <url>
       ⌯ ${prfx}sfile <url>
       ⌯ ${prfx}ytmp3 <url>
       ⌯ ${prfx}ytmp4 <url>
       ⌯ ${prfx}apple <url>
       ⌯ ${prfx}spotify <url>`
   }
// ===================================//
global.search = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Search Menu\`\`\` 
       ⌯ ${prfx}yst 
       ⌯ ${prfx}randomquote
       ⌯ ${prfx}spotifys
       ⌯ ${prfx}puisirandom
       ⌯ ${prfx}wastalk
       ⌯ ${prfx}ttsearch
       ⌯ ${prfx}novel
       ⌯ ${prfx}lirik 
       ⌯ ${prfx}ttstalk
       ⌯ ${prfx}igstalk
       ⌯ ${prfx}ytstalk
       ⌯ ${prfx}stickerly
       ⌯ ${prfx}roblox
       ⌯ ${prfx}gitstalk
       ⌯ ${prfx}twstalk
       ⌯ ${prfx}mlstalk
       ⌯ ${prfx}ffstalk
       ⌯ ${prfx}pinterest
       ⌯ ${prfx}bstation
       ⌯ ${prfx}playstore
       ⌯ ${prfx}npm
       ⌯ ${prfx}applesearch
       ⌯ ${prfx}sfilesearch`
   }
// ===================================//
global.grup = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Grup Menu\`\`\` 
       ⌯ ${prfx}add/kick 
       ⌯ ${prfx}acc/reject 
       ⌯ ${prfx}promote/demote
       ⌯ ${prfx}open/close
       ⌯ ${prfx}hidetag
       ⌯ ${prfx}tagall
       ⌯ ${prfx}totag
       ⌯ ${prfx}intro
       ⌯ ${prfx}afk
       ⌯ ${prfx}linkgc
       ⌯ ${prfx}resetlinkgc
       ⌯ ${prfx}editdesk
       ⌯ ${prfx}setnamagc
       ⌯ ${prfx}on
       ⌯ ${prfx}mute 62xx
       ⌯ ${prfx}unmute 62xx
       ⌯ ${prfx}listmute
       ⌯ ${prfx}autosholat (on/off)
       ⌯ ${prfx}antisticker (on/off)
       ⌯ ${prfx}welcome (on/off)
       ⌯ ${prfx}antitagsw (on/off)
       ⌯ ${prfx}antilinkch (on/off)
       ⌯ ${prfx}antilinkall (on/off)
       ⌯ ${prfx}antitoxic (on/off)
       ⌯ ${prfx}antipromosi (on/off)
       ⌯ ${prfx}antilinkgc (on/off)`
   }
// ===================================//
global.islam = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Islam Menu\`\`\`
       ⌯ ${prfx}listsurah
       ⌯ ${prfx}alquranaudio
       ⌯ ${prfx}kisahnabi
       ⌯ ${prfx}jadwal-sholat
       ⌯ ${prfx}ayatkursi
       ⌯ ${prfx}doaharian`
   }
// ===================================//
global.fun = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Game Menu\`\`\`
       ⌯ ${prfx}bucin 
       ⌯ ${prfx}gombal 
       ⌯ ${prfx}katakata 
       ⌯ ${prfx}motivasi 
       ⌯ ${prfx}family100
       ⌯ ${prfx}caklontong 
       ⌯ ${prfx}tebakgambar
       ⌯ ${prfx}susunkata
       ⌯ ${prfx}siapaaku
       ⌯ ${prfx}tebakkata
       ⌯ ${prfx}lengkapikalimat
       ⌯ ${prfx}tebakkimia
       ⌯ ${prfx}tebaklirik
       ⌯ ${prfx}tebaktebakan
       ⌯ ${prfx}nyerah`
   }
// ===================================//
global.asupan = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Asupan Menu\`\`\`
       ⌯ ${prfx}asupan
       ⌯ ${prfx}loli
       ⌯ ${prfx}bluearchive
       ⌯ ${prfx}cecan-korea
       ⌯ ${prfx}cecan-china
       ⌯ ${prfx}cecan-vietnam
       ⌯ ${prfx}cosplay`
   }
// ===================================//
global.maker = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return`     \`\`\`Maker Menu\`\`\` 
       ⌯ ${prfx}sticker
       ⌯ ${prfx}smeme
       ⌯ ${prfx}brat
       ⌯ ${prfx}cewebrat
       ⌯ ${prfx}bratanime
       ⌯ ${prfx}bratvid
       ⌯ ${prfx}emojimix
       ⌯ ${prfx}qc
       ⌯ ${prfx}iqc
       ⌯ ${prfx}ytcoment
       ⌯ ${prfx}snapcode
       ⌯ ${prfx}fakestoryig
       ⌯ ${prfx}fbcoment
       ⌯ ${prfx}fakexnxx
       ⌯ ${prfx}fakeff
       ⌯ ${prfx}fakecall 
       ⌯ ${prfx}buatlogo
       ⌯ ${prfx}tempo`
   }
// ===================================//
global.rpg = () => {
    const prfx = global.multiprefix ? `${global.prefix || '.'}` : '';
    return `     \`\`\`RPG Menu\`\`\`
       ⌯ ${prfx}adventure 
       ⌯ ${prfx}bank 
       ⌯ ${prfx}berburu 
       ⌯ ${prfx}klaim 
       ⌯ ${prfx}inventory 
       ⌯ ${prfx}kerja
       ⌯ ${prfx}memancing 
       ⌯ ${prfx}menambang 
       ⌯ ${prfx}stats 
       ⌯ ${prfx}shop
       ⌯ ${prfx}judi 
       ⌯ ${prfx}begal 
       ⌯ ${prfx}transfer`
   }
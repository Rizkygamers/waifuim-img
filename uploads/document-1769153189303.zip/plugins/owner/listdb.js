import { scurityDB } from "../../control/scurity.js";

const handler = async (m, { sock, isBan, isOwner }) => {
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  if (!isOwner) return m.reply(mess.owner);

  const db = await scurityDB();
  if (!db.nomor.length)
    return m.reply("*Belum ada nomor disimpan di database*");

  const teks = db.nomor.map((n, i) => `${i + 1}. ${n}`).join("\n");

  m.reply(
`*L I S T - D A T A B A S E*

${teks}

> ⚠️ Jangan hapus nomor orang sembarangan!`
  );
};

handler.command = ["listdb", "listnomor", "lisdb"];

export default handler;
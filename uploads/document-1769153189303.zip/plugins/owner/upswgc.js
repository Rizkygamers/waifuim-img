import crypto from "crypto";
import fs from "fs";
import path from "path";

const handler = async (
  m,
  {
    sock,
    text,
    command,
    usedPrefix,
    isOwner,
    reply,
    generateWAMessageFromContent,
    generateWAMessageContent,
  }
) => {

  async function groupStatus(jid, content) {
    const inside = await generateWAMessageContent(content, {
      upload: sock.waUploadToServer,
    });

    const messageSecret = crypto.randomBytes(32);

    const msg = generateWAMessageFromContent(
      jid,
      {
        messageContextInfo: { messageSecret },
        groupStatusMessageV2: {
          message: {
            ...inside,
            messageContextInfo: { messageSecret },
          },
        },
      },
      {}
    );

    await sock.relayMessage(jid, msg.message, {
      messageId: msg.key.id,
    });

    return true;
  }

  if (!isOwner) return reply(mess.owner);
  const isQuoted = !!m.quoted;
  const mime = isQuoted ? (m.quoted.mimetype || m.quoted.mtype) : null;

  let caption = text?.trim() || "";
  let media;

  if (isQuoted) media = await m.quoted.download();

  if (command === "upswgc2") {
    const [gid, cap, filePath, mimetype] = text.split("|");

    if (!gid) return reply(`Ex: ${usedPrefix}upswgc2 idgc|text|file|mime`);

    const allgc = await sock.groupFetchAllParticipating();
    if (!allgc[gid]) return reply(`Bot belum join grup:\n${gid}`);

    let content = {};

    if (filePath && filePath !== "nomedia" && fs.existsSync(filePath)) {
      const mediaData = fs.readFileSync(filePath);

      if (/image/.test(mimetype))
        content = { image: mediaData, caption: cap };
      else if (/video/.test(mimetype))
        content = { video: mediaData, caption: cap };
      else if (/audio/.test(mimetype))
        content = { audio: mediaData, mimetype: "audio/mpeg" };
      else if (/sticker/.test(mimetype))
        content = { sticker: mediaData };
      else content = { text: cap };

      fs.unlinkSync(filePath); // hapus setelah dipakai
    } else {
      content = { text: cap };
    }

    await groupStatus(gid, content);

    return reply(
      `Status berhasil dikirim ke grup *${allgc[gid]?.subject || gid}*!`
    );
  }

  if (command === "upswgc" || command === "upswgroup") {
    if (!m.isGroup) {
      const groups = Object.values(await sock.groupFetchAllParticipating());
      if (!groups.length) return reply("Bot tidak ada di grup manapun.");

      if (!caption && !isQuoted)
        return reply(
          `*Cara pakai:*\n` +
            `› ${usedPrefix + command} text\n` +
            `› Bisa reply: foto, video, audio, sticker`
        );
      let tempPath = "nomedia";

      if (isQuoted && media) {
        const ext = mime.split("/")[1];
        if (!fs.existsSync("./temp")) fs.mkdirSync("./temp");

        tempPath = path.join("./temp", `upsw-${m.sender}.${ext}`);
        fs.writeFileSync(tempPath, media);
      }

      let capSend = caption || " ";

      let list = groups.map((g) => ({
        title: g.subject,
        rowId: `${usedPrefix}upswgc2 ${g.id}|${capSend}|${tempPath}|${mime || "notype"}`,
      }));

      return sock.sendMessage(
        m.chat,
        {
          text: "*Upload Status ke Grup*",
          footer: `© ${global.namaBot}`,
          buttonText: "Pilih Grup",
          sections: [
            {
              title: "List Semua Grup",
              rows: list,
            },
          ],
        },
        { quoted: m }
      );
    }

    let targetGc = m.chat;
    let content = {};

    if (isQuoted && media) {
      if (/image/.test(mime))
        content = caption ? { image: media, caption } : { image: media };
      else if (/video/.test(mime))
        content = caption ? { video: media, caption } : { video: media };
      else if (/audio/.test(mime))
        content = { audio: media, mimetype: "audio/mpeg", ptt: false };
      else if (/sticker/.test(mime)) content = { sticker: media };
      else return reply("Media tidak bisa dikirim.");
    } else {
      // text saja
      if (!caption)
        return reply(
          `*Cara pakai:*\n` +
            `› ${usedPrefix + command} text\n` +
            `› Bisa reply foto/video/audio/sticker`
        );
      content = { text: caption };
    }

    await groupStatus(targetGc, content);

    return sock.sendMessage(
      m.chat,
      { text: "Status grup berhasil diupload!" },
      { quoted: m }
    );
  }
};

handler.command = ["upswgc", "upswgroup", "upswgc2"];
export default handler;
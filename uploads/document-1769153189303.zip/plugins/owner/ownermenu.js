import fs from "fs"

const handler = async (m, { sock, isOwner, text, args, isCmd, mime, qmsg, command, qtxt, reply, owners, example, totalFitur, totalPlugin, isBan }) => {
switch (command) {
case "listowner": case "listown": { 
if (m.isBaileys) return m.reply("ngapain 😂?")
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
if (!isOwner) return m.reply(mess.owner);
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `List Owner Tambahan:\n\n`
for (let i of owners) {
teks += `* ${i.split("@")[0]} (@${i.split("@")[0]})\n`
}
sock.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

case "addowner": case "addown": { 
if (m.isBaileys) return m.reply("ngapain 😂?")
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner) return reply(mess.owner)
    let nomor = args[0]
        ? args[0].replace(/[^0-9]/g, '')
        : m.quoted
        ? m.quoted.sender.replace(/[^0-9]/g, '')
        : m.mentionedJid && m.mentionedJid[0]
        ? m.mentionedJid[0].replace(/[^0-9]/g, '')
        : null
    if (!nomor) return reply(example(`reply/tag`))
    nomor += "@s.whatsapp.net"
    let ceknya = await sock.onWhatsApp(nomor)
    if (ceknya.length == 0) return reply(`Masukkan nomor yang valid dan terdaftar di WhatsApp!`)
    if (owners.includes(nomor)) return reply("Nomor sudah ada di daftar owner.")
    owners.push(nomor)
    fs.writeFileSync("./data/owner.json", JSON.stringify(owners))
    reply(`Berhasil menambahkan ${nomor} ke daftar owner.`)
}
break

case "delowner": case "delown": { 
if (m.isBaileys) return m.reply("ngapain 😂?")
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner) return reply(mess.owner)
    let nomor = args[0]
        ? args[0].replace(/[^0-9]/g, '')
        : m.quoted
        ? m.quoted.sender.replace(/[^0-9]/g, '')
        : m.mentionedJid && m.mentionedJid[0]
        ? m.mentionedJid[0].replace(/[^0-9]/g, '')
        : null
    if (!nomor) return reply(example(`reply/tag`))
    nomor += "@s.whatsapp.net"
    if (!owners.includes(nomor)) return reply("Nomor tidak ditemukan di daftar owner.")
    owners.splice(owners.indexOf(nomor), 1)
    fs.writeFileSync("./data/owner.json", JSON.stringify(owners))
    reply(`Berhasil menghapus ${nomor} dari daftar owner.`)
}
break
}

}

handler.command = [
"addown", 
"listown", 
"delown",
"addowner", 
"listowner", 
"delowner"
]
export default handler;
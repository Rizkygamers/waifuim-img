import { scurityDB, upNumber } from "../../control/scurity.js";

const handler = async (m, { sock, example, isBan, isOwner, text }) => {
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  if (!isOwner) return m.reply(mess.owner);

  const nomorInput = text || m.quoted?.sender?.split("@")[0];
  if (!nomorInput) return m.reply(example("62xx atau reply pesan"));

  const db = await scurityDB();
  const nomor = nomorInput.replace(/[^0-9]/g, "");

  if (db.nomor.includes(nomor))
    return m.reply("*Nomor sudah ada dalam database!*");

  db.nomor.push(nomor);
  await upNumber(db);

  m.reply(
`*Successfully Added Security 💻*

- 💌 Number : *${nomor}*
- 🧾 Status : *Success*

*Info ⚠️*
- Pastikan nomor yang ditambahkan benar.
- Bila salah, ketik *.deldb 628xxxxx* untuk hapus.
- Gunakan fitur ini secara bijak.

© ${global.namaBot} - Security`
  );
};

handler.command = ["adddb", "addnomor"];

export default handler;
const handler = async (m, { sock, isBan, isOwner, text, reply, example }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!isOwner) return m.reply(mess.owner)
  if (!text) return reply(example("nama grup nya apa?"))

  const res = await sock.groupCreate(text, [])
  const urlGrup = "https://chat.whatsapp.com/" + await sock.groupInviteCode(res.id)

  const teks = `*Grup WhatsApp Berhasil Dibuat ✅*\n\n- Nama Grup: *${text}*\n- Link: ${urlGrup}`
  m.reply(teks)
}

handler.help = ["buatgc"]
handler.tags = ["owner"]
handler.command = ["buatgc", "cgc"]

export default handler
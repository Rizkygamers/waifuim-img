const handler = async (m, { sock, isBan, isOwner, text, reply, example, mess }) => {
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!isOwner) return m.reply(mess.owner)
  if (!text && !m.quoted) return reply(example("link ch nya??"))

  const chLink = text.includes("https://whatsapp.com/channel/") ? text : m.quoted?.text
  if (!chLink || !chLink.includes("https://whatsapp.com/channel/"))
    return m.reply("Link tautan tidak valid")

  const result = chLink.split("https://whatsapp.com/channel/")[1]
  const res = await sock.newsletterMetadata("invite", result)
  await sock.newsletterFollow(res.id)

  m.reply(`*Berhasil join channel WhatsApp 🌟*\n\n` +
    `*Nama channel:* ${res.name}\n` +
    `*Total pengikut:* ${res.subscribers + 1}`)
}

handler.help = ["joinch"]
handler.tags = ["owner"]
handler.command = ["joinch", "joinchannel"]

export default handler
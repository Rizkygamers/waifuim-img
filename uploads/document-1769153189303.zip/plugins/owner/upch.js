import fs from "fs"
import ffmpeg from "fluent-ffmpeg"
import path from "path"
import { fileURLToPath } from "url"
import decode from "audio-decode" 

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

async function generateWaveform(buffer) {
  try {
    const audioBuffer = await decode(buffer)
    const rawData = audioBuffer.getChannelData(0)
    const samples = 64
    const blockSize = Math.floor(rawData.length / samples)
    const waveform = new Uint8Array(samples)

    for (let i = 0; i < samples; i++) {
      const start = i * blockSize
      const end = start + blockSize
      let max = 0
      for (let j = start; j < end; j++) {
        const val = Math.abs(rawData[j])
        if (val > max) max = val
      }
      waveform[i] = Math.min(255, Math.floor(max * 255))
    }
    return waveform
  } catch (e) {
   // console.log("Gagal generate waveform:", e)
    return new Uint8Array(64).fill(0)
  }
}

const handler = async (m, { sock, reply, text, isOwner, example }) => {
  try {
    if (!isOwner) return reply(mess.owner)
    if (!global.idChannel) return reply("global.idChannel belum diisi!")

    const q = m.quoted ? m.quoted : m
    const mime = q.mimetype || ""

    const extAd = {
      externalAdReply: {
        title: `Latest message from ${global.namaOwner}`,
        body: `📅 ${global.tanggal(Date.now())}`,
        thumbnailUrl: global.fotoOwner,
        sourceUrl: "",
        mediaType: 1,
        showAdAttribution: false,
      }
    }

    if (!mime) {
      if (!text) return reply(example("pesannya (support audio/foto/video)"))
      await sock.sendMessage(
        global.idChannel,
        {
          text,
          mentions: [m.sender],
          contextInfo: extAd
        }
      )
      return reply("Succes send to channel!")
    }

    if (/image/.test(mime)) {
      reply("Wait...")
      const img = await q.download()

      await sock.sendMessage(
        global.idChannel,
        {
          image: img,
          caption: text || "",
          mentions: [m.sender],
          contextInfo: extAd
        }
      )

      return reply("Succes send to channel!")
    }

    if (/video/.test(mime)) {
      reply("Wait...")
      const vid = await q.download()

      await sock.sendMessage(
        global.idChannel,
        {
          video: vid,
          caption: text || "",
          mimetype: "video/mp4",
          mentions: [m.sender],
          contextInfo: extAd
        }
      )

      return reply("Succes send to channel!")
    }

    if (/audio/.test(mime)) {
      reply("Wait...")
      const media = await q.download()

      const waveformArray = await generateWaveform(media)

      const timestamp = Date.now()
      const tmpInput = path.join(__dirname, `temp_input_${timestamp}.mp3`)
      const tmpOutput = path.join(__dirname, `temp_output_${timestamp}.ogg`)

      fs.writeFileSync(tmpInput, media)

      await new Promise((resolve, reject) => {
        ffmpeg(tmpInput)
          .toFormat("ogg")
          .audioCodec("libopus")
          .on("end", resolve)
          .on("error", reject)
          .save(tmpOutput)
      })

      const converted = fs.readFileSync(tmpOutput)

      await sock.sendMessage(global.idChannel, {
        audio: converted,
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
        waveform: waveformArray, 
        contextInfo: extAd 
      })

      if (fs.existsSync(tmpInput)) fs.unlinkSync(tmpInput)
      if (fs.existsSync(tmpOutput)) fs.unlinkSync(tmpOutput)

      return reply("Succes send to channel!")
    }

    reply("⚠️ Jenis file tidak didukung.")

  } catch (err) {
    console.error(err)
    try {
        const files = fs.readdirSync(__dirname).filter(f => f.startsWith('temp_'))
        files.forEach(f => fs.unlinkSync(path.join(__dirname, f)))
    } catch(e) {}
    
    reply("❌ Gagal mengirim ke channel!")
  }
}

handler.command = ["upch"]
export default handler
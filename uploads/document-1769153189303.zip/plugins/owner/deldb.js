import { scurityDB, upNumber } from "../../control/scurity.js";

const handler = async (m, { sock, example, isBan, isOwner, text }) => {
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  if (!isOwner) return m.reply(mess.owner);

  const nomorInput = text || m.quoted?.sender?.split("@")[0];
  if (!nomorInput)
    return m.reply(example(`62xx\n\nKetik *${usedPrefix}listdb* untuk melihat semua nomor`));

  const db = await scurityDB();
  const nomor = nomorInput.replace(/[^0-9]/g, "");

  if (!db.nomor.includes(nomor))
    return m.reply("Nomor tidak ditemukan");

  db.nomor = db.nomor.filter(n => n !== nomor);
  await upNumber(db);

  m.reply(`Nomor *${nomor}* berhasil dihapus dari database!`);
};

handler.command = ["deldb", "delnomor"];

export default handler;
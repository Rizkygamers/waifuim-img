/*
 ** sumber https://whatsapp.com/channel/0029VbAbEkb5Ejy7jjjG7p3H **
*/

const handler = async (m, { sock, reply, isOwner, text, usedPrefix }) => {
    if (!isOwner) return reply(mess.owner)
    if (!text) return reply(`Contoh:\n${usedPrefix}pol judul,opsi 1,opsi 2, opsi 3, dst`)
    const args = text.split(',').map(v => v.trim());
    const title = args.shift();

    if (!title || args.length < 2) 
        return reply(`Masukkan minimal 2 opsi!\nContoh:\n.pol Pilih warna?,Merah,Biru,Hijau`);

    try {
        await sock.sendMessage(m.chat, {
            poll: {
                name: title,
                values: args,
                selectableCount: 1,
                toAnnouncementGroup: false 
            }
        });
    } catch (e) {
        console.error(e);
        reply('❌ Gagal mengirim polling! Pastikan versi Baileys-mu support fitur poll.');
    }
}

handler.command = ["pol2", "poll"];
export default handler;
import axios from "axios"

const githubToken = "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";
const owner = "jarroffc";
const repo = "fitur";
const branch = "main";
const baseApi = `https://api.github.com/repos/${owner}/${repo}/contents/codes`;

async function deleteFile(filename) {
  const apiUrl = `${baseApi}/${filename}`;
  const headers = { Authorization: `Bearer ${githubToken}` };

  // Ambil SHA file dulu
  const { data } = await axios.get(apiUrl, { headers });
  const sha = data.sha;

  // Hapus file
  await axios.delete(apiUrl, {
    headers,
    data: {
      message: `Delete file ${filename}`,
      sha,
      branch,
    },
  });

  return `https://github.com/${owner}/${repo}/blob/${branch}/codes/${filename}`;
}

const handler = async (m, { sock, args, reply, isOwner, isBan, usedPrefix }) => {
  try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner) return reply(mess.owner)

    if (!args[0]) return reply(`Masukkan nama file!\nContoh: *.delcode sticker.js*\n\n*${usedPrefix}listcode* untuk melihat all file di repostory`);
    const filename = args[0].trim();

    reply("Wait. . .");

    await deleteFile(filename);
    reply(`*Berhasil menghapus file dari GitHub!*

📁 Nama File: *${filename}*
🚀 Repo: ${owner}/${repo}`);
  } catch (err) {
    console.error("DeleteCode Error:", err.response?.data || err);
    if (err.response?.status === 404) {
      reply("❌ File tidak ditemukan di repository!");
    } else {
      reply("❌ Gagal menghapus file: " + err.message);
    }
  }
};

handler.command = ["delcode"];
export default handler;
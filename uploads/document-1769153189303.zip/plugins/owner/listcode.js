import axios from "axios"

const githubToken = "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";
const owner = "jarroffc";
const repo = "fitur";
const branch = "main";
const baseApi = `https://api.github.com/repos/${owner}/${repo}/contents/codes`;

const handler = async (m, { sock, reply, isOwner, isBan }) => {
  try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner) return reply(mess.owner)
    reply("Wait...");

    const res = await axios.get(baseApi, {
      headers: { Authorization: `Bearer ${githubToken}` },
    });

    if (!Array.isArray(res.data) || res.data.length === 0)
      return reply("Tidak ada file di repository.");

    const files = res.data.map((f, i) => `${i + 1}. ${f.name}`).join("\n");
    reply(`📁 *Daftar File di Repo:*\n\n${files}\n\nGunakan *.getcode <nama file>* untuk melihat isi.`);
  } catch (e) {
    console.error("ListCode Error:", e.response?.data || e);
    reply("❌ Gagal mengambil daftar file: " + e.message);
  }
};

handler.command = ["listcode"];
export default handler;
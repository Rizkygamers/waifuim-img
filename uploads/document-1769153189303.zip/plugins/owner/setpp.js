import fs from "fs"
import Jimp from "jimp"

const handler = async (m, { sock, isOwner, mime, qmsg, reply, example, S_WHATSAPP_NET }) => {

if (!isOwner) return m.reply(mess.owner)
if (!/image/.test(mime)) return reply(example("dengan mengirim foto"))
const buffer = await sock.downloadAndSaveMediaMessage(qmsg)
var { img } = await generateProfilePicture(buffer)
await sock.query({
tag: 'iq',
attrs: {
to: S_WHATSAPP_NET,
type: 'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
m.reply("*Berhasil mengganti profile bot*")
fs.unlinkSync(buffer)
}

handler.command = ["setppbot", "setpp"]

export default handler
import axios from "axios"
import fs from "fs"

const githubToken = "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";
const owner = "jarroffc";
const repo = "fitur";
const branch = "main";
const baseApi = `https://api.github.com/repos/${owner}/${repo}/contents/codes`;

const handler = async (m, { sock, args, reply, isOwner, isBan, usedPrefix }) => {
  try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner) return reply(mess.owner)
    if (!args[0]) return reply(`Ketik nama file!\nContoh: *.getcode sticker.js*\n\n*${usedPrefix}listcode* untuk melihat all file di repostory`);

    const filename = args[0].endsWith(".js") ? args[0] : `${args[0]}.js`;
    reply("Wait...");

    const res = await axios.get(`${baseApi}/${filename}`, {
      headers: { Authorization: `Bearer ${githubToken}` },
    });

    const content = Buffer.from(res.data.content, "base64").toString("utf-8");

    if (content.length > 4000) {
      const temp = `./${filename.replace(".js", "")}.txt`;
      fs.writeFileSync(temp, content);

      await sock.sendMessage(
        m.chat,
        {
          document: { url: temp },
          mimetype: "text/plain",
          fileName: filename,
        },
        { quoted: m }
      );

      fs.unlinkSync(temp);
    } else {
      reply(`${content}`);
    }
  } catch (e) {
    console.error("GetCode Error:", e.response?.data || e);
    reply("Gagal mengambil isi file: " + e.message);
  }
};

handler.command = ["getcode"];
export default handler;
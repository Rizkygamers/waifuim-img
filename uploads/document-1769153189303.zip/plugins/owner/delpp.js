const handler = async (m, { sock, isBan, isOwner, mess }) => {
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!isOwner) return m.reply(mess.owner)

  await sock.removeProfilePicture(sock.user.id)
  m.reply("*Berhasil menghapus profile bot*")
}

handler.help = ["delppbot"]
handler.tags = ["owner"]
handler.command = ["delppbot", "delpp"]

export default handler
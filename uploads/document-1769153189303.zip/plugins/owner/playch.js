import fs from "fs";
import path from "path";
import ffmpeg from "fluent-ffmpeg";
import ffmpegInstaller from "@ffmpeg-installer/ffmpeg";
import ytdl from "@vreden/youtube_scraper";
import yts from "yt-search";
import { fileURLToPath } from "url";
import fetch from "node-fetch";
import decode from "audio-decode"; 

ffmpeg.setFfmpegPath(ffmpegInstaller.path);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function generateWaveform(buffer) {
  try {
    const audioBuffer = await decode(buffer)
    const rawData = audioBuffer.getChannelData(0)
    const samples = 64
    const blockSize = Math.floor(rawData.length / samples)
    const waveform = new Uint8Array(samples)

    for (let i = 0; i < samples; i++) {
      const start = i * blockSize
      const end = start + blockSize
      let max = 0
      for (let j = start; j < end; j++) {
        const val = Math.abs(rawData[j])
        if (val > max) max = val
      }
      waveform[i] = Math.min(255, Math.floor(max * 255))
    }
    return waveform
  } catch (e) {
    console.log("Gagal generate waveform:", e)
    return new Uint8Array(64).fill(0)
  }
}

const handler = async (m, { sock, text, reply, usedPrefix, command, isOwner }) => {
  try {
    if (!isOwner) return m.reply(mess.owner);
    if (!text)
      return reply(`*How to use:*
› Ex: ${usedPrefix + command} judul lagu
› Ex: ${usedPrefix + command} idChannel|judul lagu`);

    let targetChannel = global.idChannel;
    let query = text;
    if (text.includes("|")) {
      const [chan, judul] = text.split("|");
      if (!chan.includes("@newsletter")) {
        return reply(`*ID* saluran tidak valid`);
      }

      targetChannel = chan.trim();
      query = judul.trim();
    }

    reply("Wait. . .");

    const res = await yts(query);
    const vid = res.videos[0];
    if (!vid) return reply("❌ Lagu tidak ditemukan.");

    const yt = await ytdl.ytmp3(vid.url);
    if (!yt.status) return reply("❌ Gagal mengambil audio.");

    const url = yt.download.url;

    const timestamp = Date.now();
    const input = path.join(__dirname, `temp_${timestamp}.mp3`);
    const output = path.join(__dirname, `temp_${timestamp}.opus`);

    const down = await fetch(url);
    const buff = Buffer.from(await down.arrayBuffer());
    
    const waveformArray = await generateWaveform(buff);

    fs.writeFileSync(input, buff);

    await new Promise((resolve, reject) => {
      ffmpeg(input)
        .audioCodec("libopus")
        .audioBitrate(64) 
        .audioChannels(1) 
        .format("opus")
        .save(output)
        .on("end", resolve)
        .on("error", reject);
    });

    const audio = fs.readFileSync(output);

    await sock.sendMessage(
      targetChannel,
      {
        audio,
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
        waveform: waveformArray, 
        contextInfo: {
          externalAdReply: {
            title: vid.title,
            body: `© ${global.namaBot} 🎧`,
            thumbnailUrl: vid.thumbnail,
            sourceUrl: vid.url,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    );

    reply(`Successfully send song to channel`);

    if (fs.existsSync(input)) fs.unlinkSync(input);
    if (fs.existsSync(output)) fs.unlinkSync(output);

  } catch (err) {
    console.error(err);
    reply("⚠️ Terjadi error saat memproses audio.");
  }
};

handler.command = ["playch", "songch"];
export default handler;
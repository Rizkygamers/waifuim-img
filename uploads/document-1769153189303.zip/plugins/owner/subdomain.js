import fs from "fs"
import chalk from "chalk"
import axios from "axios"

const handler = async (m, { sock, text, args, isOwner, command, reply, example, isSewa, usedPrefix }) => {

switch (command) {
case "subdo": case "subdomain": case "domain": {
if (!isOwner && !isSewa) return m.reply("Fitur hanya untuk owner & user premium");
if (!text) {
    const obj = Object.keys(subdomain);
    let teks = `\n`;
    obj.forEach((domain, index) => {
        teks += `*${index + 1}.* ${domain}\n`;
    });
    teks += `\nContoh :\n*${usedPrefix}domain* 2 host|ipvps\n`;
    return m.reply(teks);
}

if (!args[0] || isNaN(args[0])) return m.reply("Domain tidak ditemukan!");

const dom = Object.keys(subdomain);
const domainIndex = Number(args[0]) - 1;
if (domainIndex >= dom.length || domainIndex < 0) return m.reply("Domain tidak ditemukan!");
if (!args[1] || !args[1].includes("|")) return m.reply("Hostname/IP Tidak ditemukan!");
let tldnya = dom[domainIndex];
const [host, ip] = args[1].split("|").map(str => str.trim());
async function subDomain1(host, ip) {
    return new Promise((resolve) => {
        axios.post(
            `https://api.cloudflare.com/client/v4/zones/${subdomain[tldnya].zone}/dns_records`,
            {
                type: "A",
                name: `${host.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
                content: ip.replace(/[^0-9.]/gi, ""),
                ttl: 3600,
                priority: 10,
                proxied: false,
            },
            {
                headers: {
                    Authorization: `Bearer ${subdomain[tldnya].apitoken}`,
                    "Content-Type": "application/json",
                },
            }
        ).then(response => {
            let res = response.data;
            if (res.success) {
                resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
            } else {
                resolve({ success: false, error: "Gagal membuat subdomain." });
            }
        }).catch(error => {
            let errorMsg = error.response?.data?.errors?.[0]?.message || error.message || "Terjadi kesalahan!";
            resolve({ success: false, error: errorMsg });
        });
    });
}
let teks = `*Berhasil membuat subdomain ✅*\n\n> *IP Vps :* ${ip}\n`;
const domnode = `node${getRandom("")}.${host}`;
for (let i = 0; i < 2; i++) {
    let subHost = i === 0 ? host.toLowerCase() : domnode;
    try {
        let result = await subDomain1(subHost, ip);
        if (result.success) {
            teks += `- ${result.name}\n`;
        } else {
            return m.reply(result.error);
        }
    } catch (err) {
        return m.reply("Error: " + err.message);
    }
}
await m.reply(teks);
}
break;

case "listsubdomain":
case "listsubdo": {
    if (!isOwner) return m.reply(mess.owner);
    const domains = Object.keys(global.subdomain);
    if (!domains.length) return m.reply("Belum ada domain terdaftar.");

    const listButtons = [{
        buttonId: 'showdomain',
        buttonText: { displayText: 'Pilih Domain' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: 'Pilih Domain',
                sections: [
                    {
                        title: 'Daftar List Subdomain',
                        highlight_label: 'Pilih salah satu',
                        rows: domains.map((domain) => ({
                            title: `—Domain: ${domain}`,
                            description: `List subdomain ${domain}`,
                            id: `${usedPrefix}showsub ${domain}`
                        }))
                    }
                ]
            })
        }
    }];

    sock.sendMessage(m.chat, {
        text: "Select Domain",
        buttons: listButtons,
        headerType: 1,
        footer: `${namaBot} - Version${versiBot}`,
        viewOnce: true
    }, { quoted: m });
}
break;

case "showsub": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply(`Contoh: ${usedPrefix}showsub my.id\nLihat list domain: *${usedPrefix}listsubdo*`);
    const domain = text.trim();
    if (!global.subdomain[domain]) return m.reply(`Domain *${domain}* tidak ditemukan.`);
    let zone = global.subdomain[domain].zone;
    let token = global.subdomain[domain].apitoken;
    const records = await fetchSubDomains(zone, token);
    if (!records.length) return m.reply(`Tidak ada subdomain terdaftar di *${domain}*.`);
    let listData = `*List Subdomain ${domain}*\nCara Hapus: *.delsubdo subdomain*\n\n`;
    records.forEach((record, i) => {
        listData += `- *Subdo:* ${record.name}\n- *iPvps:* ${record.content}\n\n`;
    });
    m.reply(listData);
}
break;

case "delsubdomain":
case "delsubdo": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply(example("link nya examle.my.id\n.delsubdo all (hapus semua)"));
    let isDeleteAll = text.trim().toLowerCase() === "all"
    const dom = Object.keys(global.subdomain);
    async function deleteSubDomain(zone, id, token) {
        try {
            const res = await axios.delete(
                `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records/${id}`,
                {
                    headers: {
                        Authorization: "Bearer " + token,
                        "Content-Type": "application/json",
                    },
                }
            );
            if (res.data.success) {
                return { success: true };
            } else {
                return { success: false, error: res.data.errors?.[0]?.message || "Gagal menghapus subdomain." };
            }
        } catch (e) {
            return { success: false, error: e.response?.data?.errors?.[0]?.message || "Terjadi kesalahan." };
        }
    }
    (async () => {
        if (isDeleteAll) {
            let totalDeleted = 0;
            for (let tld of dom) {
                let zone = global.subdomain[tld].zone;
                let token = global.subdomain[tld].apitoken;
                const records = await fetchSubDomains(zone, token);
                for (let record of records) {
                    if (record.type === "A" || record.type === "CNAME") {
                        const result = await deleteSubDomain(zone, record.id, token);
                        if (result.success) totalDeleted++;
                    }
                }
            }
            return m.reply(`Berhasil menghapus *${totalDeleted}* subdomain dari semua domain.`);
        } else {
            if (/^https?:\/\//i.test(text.trim())) {
                return m.reply(`Jangan sertakan *https://* pada link subdomain\n- Contoh penggunaan: *${usedPrefix}delsubdo jarr.example.com*`);
            }

            let targetSubdomain = text.trim().toLowerCase();
            let found = false;

            for (let tld of dom) {
                let zone = global.subdomain[tld].zone;
                let token = global.subdomain[tld].apitoken;
                const records = await fetchSubDomains(zone, token);
                const subdomainToDelete = records.find((record) => record.name === targetSubdomain);
                if (subdomainToDelete) {
                    const result = await deleteSubDomain(zone, subdomainToDelete.id, token);
                    found = true;
                    if (result.success) {
                        return m.reply("Subdomain berhasil dihapus.");
                    } else {
                        return m.reply("❌ " + result.error);
                    }
                }
            }
            if (!found) return m.reply(`Subdomain tidak ditemukan!\nGunakan *${usedPrefix}listsubdomain* untuk melihat daftar.`);
        }
    })();
}
break;

case "clearsubdo": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply(example("example.com (pastikan subdomain udah ada di settings.js ya)"));
    let targetDomain = text.trim().toLowerCase();
    const dom = Object.keys(global.subdomain);
    async function deleteSubDomain(zone, id, token) {
        try {
            const res = await axios.delete(
                `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records/${id}`,
                {
                    headers: {
                        Authorization: "Bearer " + token,
                        "Content-Type": "application/json",
                    },
                }
            );
            if (res.data.success) {
                return { success: true };
            } else {
                return { success: false, error: res.data.errors?.[0]?.message || "Gagal menghapus subdomain." };
            }
        } catch (e) {
            return { success: false, error: e.response?.data?.errors?.[0]?.message || "Terjadi kesalahan." };
        }
    }

    (async () => {
        if (!global.subdomain[targetDomain]) {
            return m.reply(`Domain ${targetDomain} tidak ada di  *settings.js*`);
        }

        let zone = global.subdomain[targetDomain].zone;
        let token = global.subdomain[targetDomain].apitoken;
        const records = await fetchSubDomains(zone, token);

        let totalDeleted = 0;
        for (let record of records) {
            if (record.type === "A" || record.type === "CNAME") {
                const result = await deleteSubDomain(zone, record.id, token);
                if (result.success) totalDeleted++;
            }
        }

        if (totalDeleted > 0) {
            return m.reply(`*Berhasil menghapus ✅*
- Domain Utama : ${targetDomain}
- Total Subdomain : ${totalDeleted} dihapus!`);
        } else {
            return m.reply(`⚠ Tidak ada subdomain ditemukan di *${targetDomain}*`);
        }
    })();
}
break;

} 
}

handler.command = ["domain","subdomain","subdo","listsubdomain","listsubdo","showsub","delsubdomain","delsubdo","clearsubdo"]
export default handler;
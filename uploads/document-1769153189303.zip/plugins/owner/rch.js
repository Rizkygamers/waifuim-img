import fetch from "node-fetch"

const handler = async (m, { sock, text, command, reply, usedPrefix, isOwner }) => {
  try {
    if (!isOwner) return reply(mess.owner)
    if (!text) return reply(`Ex: ${usedPrefix}${command} https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09/285 🤍,🥰,🥳`)
    m.reply("Wait. . .")
    const args = text.trim().split(" ")
    const link = args.shift()
    let emotes = args.join(" ")

    if (!link || !emotes) {
      return reply(`Ex: ${usedPrefix}${command} https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09/285 🤍,🥰,🥳`)
    }

    emotes = emotes.replace(/\s+/g, "")

    const url = `https://react.whyux-xec.my.id/api/rch?link=${encodeURIComponent(link)}&emoji=${encodeURIComponent(emotes)}`

    const res = await fetch(url, {
      method: "GET",
      headers: {
        "x-api-key": global.apikeyRch
      }
    })

    if (!res.ok) return reply(`Gagal fetch API: ${res.status}`)

    const json = await res.json()

    await sock.sendMessage(m.chat, {
      text:
`*Succes send reaction! 🎉*

› *Target:* ${link}
› *Emoji:* ${emotes}
› *Status:* Succes ✓`
    })

  } catch (e) {
    console.error(e)
    reply("Error saat fetch API.")
  }
}

handler.command = ["rch", "reactch"]
export default handler
import "../../fitur/listmenu.js"

import fs from "fs"
import speed from 'performance-now'

const handler = async (m, { sock, isOwner, text, reply, getPluginStats, isSewa, isBan, usedPrefix, totalBan, qtxt }) => {

  const prfx = global.multiprefix ? `${global.prefix || '.'}` : 'no prefix';
  const info = getPluginStats();
  const timestamp = speed();

  if (isBan) return reply(`Kamu dibanned, hubungi owner: *.owner* untuk unban`);

  let sub = (text || "").trim().toLowerCase();  
  let teks;

  switch (sub) {
    case "all":
      teks = 
`   *Script Information*
     ╭ ⌯ Name: ${global.namaBot}
     │ ⌯ Version: ${global.versiBot}
     │ ⌯ Developer: ${global.namaOwner}
     │ ⌯ Prefix : *${prfx}*
     ╰ ⌯ Type: *plugins (ESM)*
   
   *User Information*
     ╭ ⌯ User Banned : ${totalBan} user
     │ ⌯ User Name : ${m.pushName}
     ╰ ⌯ Your Status : ${isOwner ? "owner" : isSewa ? "premium user" : "free user"}
   
${global.allmenu()}`;
    break;


    case "owner": 
    teks = `Hello *${m.pushName}* 👋

${global.ownmenu()}`; 
    break;

    case "tools": 
    teks = `Hello *${m.pushName}* 👋

${global.tools()}`; 
    break;

    case "store": 
    teks = `Hello *${m.pushName}* 👋

${global.store()}`; 
    break;

    case "ai": 
    teks = `Hello *${m.pushName}* 👋

${global.aimenu()}`; 
    break;

    case "download": 
    teks = `Hello *${m.pushName}* 👋

${global.download()}`; 
    break;

    case "search": 
    teks = `Hello *${m.pushName}* 👋

${global.search()}`; 
    break;

    case "grup": 
    teks = `Hello *${m.pushName}* 👋

${global.grup()}`; 
    break;

    case "islam": 
    teks = `Hello *${m.pushName}* 👋

${global.islam()}`; 
    break;

    case "game": 
    teks = `Hello *${m.pushName}* 👋

${global.fun()}`; 
    break;

    case "asupan": 
    teks = `Hello *${m.pushName}* 👋

${global.asupan()}`; 
    break;

    case "maker": 
    teks = `Hello *${m.pushName}* 👋

${global.maker()}`; 
    break;

    case "rpg": 
    teks = `Hello *${m.pushName}* 👋

${global.rpg()}`; 
    break;
 
    case "imageai": teks = `*メ Category AI Image* \n${global.aiimg()}`; 
    break;

    default:
          teks = `Hello *${m.pushName}* 👋
Nice to meet you, I *${global.namaBot}*

   *Script Information* 
     ╭ ⌯ Name: ${global.namaBot}
     │ ⌯ Version: ${global.versiBot}
     │ ⌯ Developer: ${global.namaOwner}
     │ ⌯ Prefix : *${prfx}*
     ╰ ⌯ Type: *plugins (ESM)*

   *Others Information* 
     ╭ ⌯ User Banned : ${totalBan} user
     │ ⌯ User Name : ${m.pushName}
     ╰ ⌯ Your Status : ${isOwner ? "owner" : isSewa ? "premium user" : "free user"}
   
   *Menu List*
      ⌯ ${usedPrefix}menu all
      ⌯ ${usedPrefix}menu owner
      ⌯ ${usedPrefix}menu tools
      ⌯ ${usedPrefix}menu ai
      ⌯ ${usedPrefix}menu imageai
      ⌯ ${usedPrefix}menu store
      ⌯ ${usedPrefix}menu search
      ⌯ ${usedPrefix}menu download
      ⌯ ${usedPrefix}menu maker
      ⌯ ${usedPrefix}menu rpg
      ⌯ ${usedPrefix}menu grup
      ⌯ ${usedPrefix}menu asupan
      ⌯ ${usedPrefix}menu islam`;
  } 

    await sock.sendMessage(m.chat, {
          text: teks,
          contextInfo: {
            mentionedJid: [m.sender],
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
              newsletterJid: global.idChannel,
              newsletterName: `hello im ${global.namaBot}`, 
              },
              externalAdReply: {
                  title: `Hii welcome to bot menu!`,
                  body: `⌯ ${global.namaBot} ⌯`,
                  thumbnailUrl: global.fotoBot,
                  sourceUrl: "https://me.jarr.biz.id",
                  mediaType: 1,
                  renderLargerThumbnail: true
              }
          }
      }, { quoted: m });
}

handler.command = ["menu"];
export default handler;
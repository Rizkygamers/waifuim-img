// plugins/grup/intro.js
const handler = async (m, { sock, reply }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);

  reply(`╭─〔 🐼 𝐈𝐧𝐭𝐫𝐨𝐝𝐮𝐜𝐞 𝐘𝐨𝐮𝐫𝐬𝐞𝐥𝐟 〕
│ ✦ 𝐍𝐚𝐦𝐚      : 
│ ✦ 𝐔𝐦𝐮𝐫      : 
│ ✦ 𝐆𝐞𝐧𝐝𝐞𝐫    : 
│ ✦ 𝐇𝐨𝐛𝐢      : 
│ ✦ 𝐊𝐞𝐚𝐡𝐥𝐢𝐚𝐧  : 
╰───────────────────────
_📌 Jangan lupa baca deskripsi grup_`)
};

handler.command = ["intro"];
export default handler;
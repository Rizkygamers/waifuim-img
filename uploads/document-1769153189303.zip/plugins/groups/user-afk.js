
const handler = async (m, { sock, text, reply, getUser, db, isBan }) => {
  if (isBan) return 
  const user = await getUser(m.sender);

  if (user.banned) return; 
  if (user.afk_time > -1) {
    return reply('Kamu kan sudah AFK! 💤');
  }

  const reason = text?.trim() || `Tanpa alasan`;
  const now = Date.now();

  await db('users', m.sender, 'afk_time', now);
  await db('users', m.sender, 'afk_reason', reason);

  await sock.sendMessage(
    m.chat,
    {
      text: `💤 Kini @${m.sender.split('@')[0]} dalam mode *AFK!*
      
- 💬 *Alasan:* ${reason}
- 💌 Jangan diganggu dulu ya!`,
      mentions: [m.sender],
    },
    { quoted: m }
  );
};

handler.command = ['afk'];
export default handler;
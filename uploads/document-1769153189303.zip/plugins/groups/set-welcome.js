
const handler = async (m, { sock, isAdmin, isOwner, isBotAdmin, text, command, reply, usedPrefix, db }) => {

  if (!m.isGroup) return reply(global.mess?.group || 'Khusus Grup!');
  if (!isAdmin && !isOwner) return reply(global.mess?.ownadmin || 'Khusus Admin/Owner!');
  if (!isBotAdmin) return reply(global.mess?.botAdmin || 'Jadikan Bot Admin dulu!');

  const input = text?.toLowerCase();
  if (!['on', 'off'].includes(input)) {
    return reply(`Contoh: ${usedPrefix + command} on/off`);
  }

  const dbValue = input === 'on' ? 1 : 0;

  try {
    await db('groups', m.chat, 'welcome', dbValue);

    reply(`Fitur *welcome* berhasil di *${input === 'on' ? 'aktifkan' : 'matikan'}*`);
  } catch (e) {
    console.error(e);
    reply('Gagal menyimpan ke database.');
  }
}

handler.command = ['welcome'];
export default handler;
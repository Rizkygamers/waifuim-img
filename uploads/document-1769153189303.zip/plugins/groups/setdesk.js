// plugins/grup/setdesk.js
const handler = async (m, { sock, isAdmin, isOwner, isBotAdmin, reply, text, usedPrefix, example }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin);
  if (!isBotAdmin) return reply(mess.botAdmin);

  if (!text) return reply(example(`his description`));

  try {
    await sock.groupUpdateDescription(m.chat, text);
    reply("Deskripsi grup berhasil diubah.");
  } catch (err) {
    reply("Gagal mengubah deskripsi.");
  }
};

handler.command = ["setdesk"];
export default handler;
// plugins/grup/setnamagc.js
const handler = async (m, { sock, isAdmin, isOwner, reply, text, usedPrefix }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin);

  if (!text) return reply(`Contoh: ${usedPrefix+command} Nama baru grup`);

  try {
    await sock.groupUpdateSubject(m.chat, text);
    reply(`Succes!`);
  } catch (e) {
    reply("Gagal mengganti nama grup.");
  }
};

handler.command = ["setnamagc", "gantinamgc"];
export default handler;
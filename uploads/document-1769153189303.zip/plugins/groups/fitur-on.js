
const handler = async (m, { sock, isOwner, isAdmin, args, command, reply, usedPrefix, chatDb, db }) => {

  if (!m.isGroup) return reply(global.mess?.group || 'Khusus Grup!');
  if (!isAdmin && !isOwner) return reply(global.mess?.ownadmin || 'Khusus Admin/Owner!');

  const featureList = [
  "welcome",
  "antilinkgc",
  "antilinkch",
  "antilinkall",
  "antipromosi",
  "antisticker",
  "antitoxic",
  "antitagsw",
  "autosholat"
  ];

  if (!args.length) {
    let teks = `*GROUP SETTINGS*\n\n`;

    featureList.forEach((key, i) => {
      const status = chatDb[key] === 1 ? 'ON' : 'OFF';
      teks += `[${i + 1}] ${key} : *${status}*\n`;
    });

    teks += `\n› Cara: ${usedPrefix + command} <nomor>`;
    teks += `\n› Contoh: ${usedPrefix + command} 1 3 5`;

    return reply(teks);
  }

  const indexes = args
    .map(a => parseInt(a))
    .filter(n => !isNaN(n));

  if (!indexes.length)
    return reply("Masukkan nomor fitur yang valid. Contoh: *.on 1*");

  const targetValue = command === 'on' ? 1 : 0;
  const updated = [];
  const failed = [];

  for (const i of indexes) {
    const key = featureList[i - 1];
    
    if (!key) {
        continue; 
    }

    try {
        await db('groups', m.chat, key, targetValue);
        updated.push(key);
    } catch (e) {
        console.error(e);
        failed.push(key);
    }
  }

  let msg = `Fitur berhasil di-*${command === 'on' ? 'aktifkan' : 'matikan'}*:\n`;
  if (updated.length > 0) msg += `- [✓] ${updated.join('\n- [✓] ')}`;
  
  if (failed.length > 0) msg += `\n\nGagal update: ${failed.join(', ')}`;

  return reply(msg);
}

handler.command = ['on', 'off'];
export default handler;
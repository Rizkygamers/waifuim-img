// plugins/grup/linkgc.js
const handler = async (m, { sock, isBotAdmin, isGroup, reply }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: "❌", key: m.key });

  if (!m.isGroup) return reply(mess.group);
  if (!isBotAdmin) return reply(mess.botAdmin);

  const code = await sock.groupInviteCode(m.chat);
  const meta = await sock.groupMetadata(m.chat);

  await sock.sendMessage(m.chat, {
    text: `- 🍀 Name : *${meta.subject}*
- 🌳 Url Link : https://chat.whatsapp.com/${code}`,
    detectLink: true
  });
};

handler.command = ["linkgc", "linkgroup", "linkgrup"];
export default handler;
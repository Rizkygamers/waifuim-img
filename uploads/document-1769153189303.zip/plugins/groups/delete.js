// plugins/grup/delete.js
const handler = async (m, { sock, isOwner, isAdmin, isBotAdmin, reply, example }) => {
  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) {
    if (!isOwner) return reply(mess.owner);
    if (!m.quoted) return reply(example("reply pesannya"));
    return sock.sendMessage(m.chat, { 
      delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender }
    });
  }

  if (!isOwner && !isAdmin) return reply(mess.admin);
  if (!m.quoted) return reply(example("reply pesannya"));

  if (m.quoted.fromMe) {
    return sock.sendMessage(m.chat, { 
      delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender }
    });
  } else {
    if (!isBotAdmin) return reply(mess.botAdmin);
    return sock.sendMessage(m.chat, { 
      delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender }
    });
  }
};

handler.command = ["delete", "del", "d"];
export default handler;
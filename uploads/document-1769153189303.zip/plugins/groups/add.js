// plugins/grup/add.js
const handler = async (m, { sock, isOwner, isAdmin, isBotAdmin, text, command, reply, usedPrefix }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin);
  if (!isBotAdmin) return reply(mess.botAdmin);

  let nomor = text?.replace(/[^0-9]/g, "");

  if (m.mentionedJid?.[0]) nomor = m.mentionedJid[0].split("@")[0];
  else if (m.quoted?.sender) nomor = m.quoted.sender.split("@")[0];

  if (!nomor) return reply(`Contoh: ${usedPrefix}${command} 628xxxx`);
  if (nomor.length < 8) return reply("Nomor tidak valid!");

  const target = nomor + "@s.whatsapp.net";

  try {
    await sock.groupParticipantsUpdate(m.chat, [target], "add");
    await sock.sendMessage(m.chat, {
      text: `Berhasil menambahkan @${nomor}`,
      mentions: [target]
    }, { quoted: m });
  } catch (err) {
    console.error(err);
    reply("Gagal menambahkan. Nomor mungkin privat / tidak aktif / sudah di grup.");
  }
};

handler.command = ["add"];
export default handler;
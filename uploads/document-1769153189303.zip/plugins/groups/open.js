// plugins/grup/openclose.js
const handler = async (m, { sock, isOwner, isAdmin, isBotAdmin, reply, command }) => {
  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin);
  if (!isBotAdmin) return reply(mess.botAdmin);

  if (command === "open" || command === "buka") {
    await sock.groupSettingUpdate(m.chat, "not_announcement");
    return reply("*Grup Open* semua member sekarang bisa kirim pesan!");
  }

  if (command === "close" || command === "tutup") {
    await sock.groupSettingUpdate(m.chat, "announcement");
    return reply("*Group Close* hanya admin yang dapat mengirim pesan!");
  }
};

handler.command = ["open", "buka", "close", "tutup"];
export default handler;
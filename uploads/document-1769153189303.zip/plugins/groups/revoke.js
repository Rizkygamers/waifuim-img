// plugins/grup/revoke.js
const handler = async (m, { sock, isAdmin, isOwner, isBotAdmin, reply }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: "❌", key: m.key });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin);
  if (!isBotAdmin) return reply(mess.botAdmin);

  try {
    await sock.groupRevokeInvite(m.chat);
    const newLink = await sock.groupInviteCode(m.chat);
    const meta = await sock.groupMetadata(m.chat);

    reply(`*Tautan undangan berhasil direset*

- *Nama Grup:* ${meta.subject}
- *Link Baru:* https://chat.whatsapp.com/${newLink}`);
  } catch (e) {
    reply("Error saat reset link.");
  }
};

handler.command = ["revoke", "resetlinkgc", "rstgc"];
export default handler;
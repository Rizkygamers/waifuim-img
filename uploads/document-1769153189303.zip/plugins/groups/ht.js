// plugins/grup/hidetag.js
const handler = async (m, { sock, isAdmin, isOwner, reply, text, usedPrefix, example, command }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin);
  if (!text) return reply(example(`pesan`));

  try {
    const metadata = await sock.groupMetadata(m.chat);
    const members = metadata.participants.map(m => m.id);

    await sock.sendMessage(
      m.chat,
      {
        text: text,
        mentions: members
      },
      { quoted: m }
    );
  } catch (e) {
    console.error(e);
    reply("Gagal mengirim pesan hidetag.");
  }
};

handler.command = ["hidetag", "ht", "h"];
export default handler;
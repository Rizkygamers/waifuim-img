// plugins/grup/tagall.js
const handler = async (m, { sock, isAdmin, isOwner, reply, args, usedPrefix }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin);

  const message = args.join(" ") || "nothing";

  let teks = `*Tagall Message:*\n> ${message}\n\n`;

  const metadata = await sock.groupMetadata(m.chat);
  const members = metadata.participants;

  for (let mem of members) {
    teks += `@${mem.id.split("@")[0]}\n`;
  }

  await sock.sendMessage(
    m.chat,
    {
      text: teks,
      mentions: members.map(m => m.id)
    },
    { quoted: m }
  );
};

handler.command = ["tagall"];
export default handler;
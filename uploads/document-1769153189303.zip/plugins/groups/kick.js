// plugins/grup/kick.js
const handler = async (m, { sock, isAdmin, isOwner, isBotAdmin, text, command, reply, usedPrefix }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin)
  if (!isBotAdmin) return reply(mess.botAdmin);

  let target;

  if (m.mentionedJid?.[0]) target = m.mentionedJid[0];
  else if (m.quoted?.sender) target = m.quoted.sender;
  else if (text) {
    let clean = text.replace(/[^0-9]/g, "");
    if (clean.length < 5) return reply("Nomor tidak valid!");
    target = clean + "@s.whatsapp.net";
  }

  if (!target) return reply(`Contoh: ${usedPrefix+command} tag/reply/nomor`);

  try {
    await sock.groupParticipantsUpdate(m.chat, [target], "remove");
  } catch (err) {
    console.error(err);
    reply("Gagal mengeluarkan anggota!");
  }
};

handler.command = ["kick", "kik", "k"];
export default handler;
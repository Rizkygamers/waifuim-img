const handler = async (m, { sock, isOwner, isAdmin, reply, example }) => {

  if (m.isBan)
    return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

  if (!m.isGroup) return reply(mess.group);
  if (!isAdmin && !isOwner) return reply(mess.ownadmin);

  // --- FIX UTAMA (Ambil member dari metadata) ---
  const meta = await sock.groupMetadata(m.chat);
  const participants = meta.participants;

  let users = participants
    .map(p => p.id)
    .filter(id => id !== sock.user.jid);

  if (!m.quoted) return reply(example("reply pesan yang mau di tag"));

  await sock.sendMessage(m.chat, {
    forward: m.quoted.fakeObj,
    mentions: users,
  });
};

handler.command = ["totag"];
export default handler;
import fetch from "node-fetch"

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Contoh:\n${usedPrefix}${command} mau tanya ap`
    )
  }

  try {
    await m.reply("Thinking...")

    const api = `https://velyn.mom/api/ai/groq?apikey=jarrxz&prompt=${encodeURIComponent(text)}`

    const res = await fetch(api)
    const json = await res.json()

    if (!res.ok || json.status !== 200 || !json.data?.result) {
      return m.reply("❌ Gagal mendapatkan jawaban")
    }

    await m.reply(
      `${json.data.result}`
    )

  } catch (err) {
    console.error(err)
    m.reply("⚠️ Terjadi error saat memproses pertanyaan")
  }
}

handler.help = ["groq <pertanyaan>"]
handler.tags = ["ai"]
handler.command = ["groq"]

export default handler
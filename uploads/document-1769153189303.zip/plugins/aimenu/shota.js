import fetch from "node-fetch"

const handler = async (m, { sock, text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply(mess.owner)
  if (!text) {
    return m.reply(`Contoh: ${usedPrefix}${command} gambar apa ini`)
  }

  let mediaType = "teks"
  let quoted = m.quoted || null

  if (quoted) {
    const mime = quoted.mimetype || ""

    if (/image/.test(mime)) mediaType = "gambar"
    else if (/video/.test(mime)) mediaType = "video"
    else if (/audio/.test(mime)) mediaType = "audio"
    else if (/sticker/.test(mime)) mediaType = "stiker"
    else mediaType = "file"
  }

  try {
    const system = `Namamu adalah Shota AI, saat menjawab kamu harus menjawab dengan tengil, kalo perlu gunakan emoji agar lebih hidup`

    const prompt = quoted
      ? `User mereply ${mediaType} dan bertanya: ${text}`
      : text

    const url = `https://velyn.mom/api/ai/customai?apikey=jarrxz&prompt=${encodeURIComponent(prompt)}&system=${encodeURIComponent(system)}`
    const res = await fetch(url)
    const json = await res.json()

    if (!json?.data?.result) {
      return m.reply("❌ AI tidak memberikan jawaban")
    }

    await sock.sendMessage(
      m.chat,
      { text: json.data.result },
      { quoted: m }
    )

  } catch (err) {
    console.error(err)
    m.reply("❌ Error saat memproses Shota AI")
  }
}

handler.command = ["shota"]
export default handler
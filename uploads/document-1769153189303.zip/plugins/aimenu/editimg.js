import axios from "axios";
import fs from "fs";

async function gptImageEdit(prompt, buffer) {
  try {
    if (!prompt) throw new Error("Prompt diperlukan.");
    if (!Buffer.isBuffer(buffer)) throw new Error("Gambar harus buffer.");

    const { data } = await axios.post(
      "https://ghibli-proxy.netlify.app/.netlify/functions/ghibli-proxy",
      {
        image: "data:image/png;base64," + buffer.toString("base64"),
        prompt: prompt,
        model: "gpt-image-1",
        n: 1,
        size: "auto",
        quality: "low",
      },
      {
        headers: {
          origin: "https://overchat.ai",
          referer: "https://overchat.ai/",
          "user-agent":
            "Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36",
        },
      }
    );

    const result = data?.data?.[0]?.b64_json;
    if (!result) throw new Error("Tidak ada hasil edit.");

    return Buffer.from(result, "base64");
  } catch (err) {
    throw new Error(err.message);
  }
}

const handler = async (m, { sock, text, reply, usedPrefix, command, isOwner, isSewa }) => {
  try {
    if (!isOwner && !isSewa) return m.reply(mess.vip)
    if (!text)
      return reply(`*How to use:*
› Ex: ${usedPrefix + command} editimg buat wajah lebih cerah (reply atau kirim fotonya)`
);

    const q = m.quoted ? m.quoted : m;

    const mime = (q.msg || q).mimetype || "";
    if (!mime.startsWith("image/"))
      return reply("Harus reply gambar yang mau diedit.");

    reply("Wait...");

    const imgBuffer = await q.download();
    const edited = await gptImageEdit(text, imgBuffer);

    await sock.sendMessage(
      m.chat,
      { image: edited, caption: "✓ Image finished editing" },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    reply("⚠️ Error: " + err.message);
  }
};

handler.command = ["editimg", "editimage", "imgedit"];
export default handler;
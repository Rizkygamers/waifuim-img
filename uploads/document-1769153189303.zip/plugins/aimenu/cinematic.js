import axios from "axios";

async function gptImageFigure(buffer) {
  const fixedPrompt = "Cinematic over head shot of me standing still on a brick city side walk, wearing a dark oversize sweater. motion blured crowd rushes past around me.moody lightning 35mm film look shallow depth of field, Sharp focus on me ration potrait 4:3";
  try {
    if (!Buffer.isBuffer(buffer)) throw new Error("Gambar harus buffer.");

    const { data } = await axios.post(
      "https://ghibli-proxy.netlify.app/.netlify/functions/ghibli-proxy",
      {
        image: "data:image/png;base64," + buffer.toString("base64"),
        prompt: fixedPrompt,
        model: "gpt-image-1",
        n: 1,
        size: "auto",
        quality: "low",
      },
      {
        headers: {
          origin: "https://overchat.ai",
          referer: "https://overchat.ai/",
          "user-agent":
            "Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36",
        },
      }
    );

    const result = data?.data?.[0]?.b64_json;
    if (!result) throw new Error("Tidak ada hasil edit.");

    return Buffer.from(result, "base64");
  } catch (err) {
    throw new Error(err.message);
  }
}

const handler = async (m, { sock, reply, isOwner, isSewa }) => {
  try {
    if (!isOwner && !isSewa) return reply(mess.vip);

    if (!m.quoted) return reply("Reply foto yang ingin diubah menjadi figure.");

    const q = m.quoted;
    const mime = (q.msg || q).mimetype || "";
    if (!mime.startsWith("image/")) return reply("Harus reply gambar.");

    reply("Sabar...");

    const imgBuffer = await q.download();
    const edited = await gptImageFigure(imgBuffer);

    await sock.sendMessage(
      m.chat,
      { image: edited, caption: "*This is the result*" },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    reply("⚠️ Error: " + err.message);
  }
};

handler.command = ["cinematic", "tocm", "tocinematik"];
export default handler;
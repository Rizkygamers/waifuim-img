import axios from "axios";

async function perplexed(question) {
    try {
        if (!question) throw new Error('Question is required.');

        const { data } = await axios.post(
            'https://d21l5c617zttgr.cloudfront.net/stream_search',
            { user_prompt: question },
            {
                headers: {
                    origin: 'https://d21l5c617zttgr.cloudfront.net',
                    referer: 'https://d21l5c617zttgr.cloudfront.net/',
                    'user-agent':
                        'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36'
                }
            }
        );

        if (!data || typeof data !== 'string') throw new Error('No result found.');

        const allSteps = data
            .split('[/PERPLEXED-SEPARATOR]')
            .filter(text => text.trim() !== '')
            .map(part => {
                try {
                    return JSON.parse(part);
                } catch (err) {
                    return null;
                }
            })
            .filter(item => item !== null);

        const result = allSteps.length > 0 ? allSteps[allSteps.length - 1] : null;
        if (!result) throw new Error('No result found.');

        return {
            answer: result.answer,
            sources: result.websearch_docs || []
        };
    } catch (error) {
        throw new Error(error.message);
    }
}

const handler = async (m, { sock, command, isBan }) => {
    try {
        if (isBan)
            return sock.sendMessage(m.chat, {
                react: { text: "❌", key: m.key }
            });

        const query = m.body.trim().split(/ +/).slice(1).join(" ");
        if (!query) return m.reply("Mau tanya apa?");

        const result = await perplexed(query);

        let teks = `${result.answer}`;
        m.reply(teks);

    } catch (e) {
        m.reply("Error: " + e.message);
    }
};

handler.command = ["perplexed", "ppx", "ppxai"];
export default handler;
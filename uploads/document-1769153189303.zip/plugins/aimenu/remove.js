import axios from "axios";
import fs from "fs";
import FormData from "form-data";
import fetch from "node-fetch";
import { fileTypeFromBuffer } from "file-type";

const handler = async (m, { sock, reply, isOwner, isSewa }) => {

    const mime = (
        m.quoted?.mimetype ||
        m.quoted?.msg?.mimetype ||
        m?.message?.imageMessage?.mimetype ||
        ""
    );

    const qmsg = m?.quoted ? m.quoted : m;

    if (!isOwner && !isSewa) return reply(mess.vip);
    if (!/image/.test(mime)) return reply("Reply gambar atau kirim gambar!");

    reply("Wait...");

    async function uploadToCatbox(buffer) {
        let { ext } = await fileTypeFromBuffer(buffer);

        const form = new FormData();
        form.append("fileToUpload", buffer, `file.${ext}`);
        form.append("reqtype", "fileupload");

        const res = await fetch("https://catbox.moe/user/api.php", {
            method: "POST",
            body: form
        });

        return await res.text();
    }

    try {
        let mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
        let buffer = fs.readFileSync(mediaPath);

        let imageUrl = await uploadToCatbox(buffer);

        let json;
        let success = false;
        let attempts = 2;

        while (attempts-- && !success) {
            const apiRes = await fetch(
                `https://velyn.mom/api/tools/remove?apikey=jarrxz&url=${encodeURIComponent(imageUrl)}`
            );

            json = await apiRes.json();

            if (json?.status && json?.result?.url) {
                success = true;
                break;
            }
        }

        if (!success) {
            fs.unlinkSync(mediaPath);
            return reply("Gagal mendapatkan hasil dari API Remove. Coba lagi.");
        }

        await sock.sendMessage(
            m.chat,
            {
                image: { url: json.result.url },
                caption: "Berhasil To Remove ✨"
            },
            { quoted: m }
        );

        fs.unlinkSync(mediaPath);

    } catch (err) {
        console.error(err);
        reply("⚠️ Terjadi kesalahan!\n" + err.message);
    }
};

handler.command = ["rm", "clothes", "remove"];
export default handler;
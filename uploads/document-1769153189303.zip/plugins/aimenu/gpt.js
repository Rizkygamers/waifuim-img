import axios from 'axios'

const handler = async (m, { sock,command, example, text, isBan }) => {
    try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        if (!text) return m.reply(example('mau tanya apa?'))
        let { data } = await axios.post(
            'https://mpzxsmlptc4kfw5qw2h6nat6iu0hvxiw.lambda-url.us-east-2.on.aws/process',
            {
                messages: [
                    { content: "Hello, how can i assist you today?", role: "system" },
                    { content: text, role: "user" }
                ],
                model: "gpt-3.5-turbo-0125",
                temperature: 0.9
            },
            {
                headers: {
                    'User-Agent': 'okhttp/3.14.9',
                    'Connection': 'Keep-Alive',
                    'Accept-Encoding': 'gzip',
                    'Authorization': 'Bearer sk-proj-6WaGz0cNPN5ILBClacpFhlW-7UOnknRtuEoPoV0rgMM7y50hvnZsMjrApOFN8r9vnIa-IOwTwvT3BlbkFJA93BY4mqTbjUGMQC_rkb5YJNcIsYnfjvFMxjVKU0bsEDNCciyzCCI4GuhNAwp',
                    'Content-Type': 'application/json'
                }
            }
        )
        m.reply(data.choices[0].message.content)
    } catch (e) {
        m.reply(e.message)
    }
}

handler.command = ["gpt", "ai"]
export default handler;
import fetch from "node-fetch"

const handler = async (m, { sock, text, usedPrefix, command, isOwner, isSewa }) => {

  if (!isOwner && !isSewa) return m.reply(mess.vip)
  if (!text) {
    return m.reply(
      `Ex: ${usedPrefix}${command} promt nya`
    )
  }

  try {
    await m.reply("Wait...")

    const api = `https://velyn.mom/api/ai/art?apikey=jarrxz&prompt=${encodeURIComponent(text)}`
    const res = await fetch(api)
    const json = await res.json()

    if (!res.ok || json.status !== 200) {
      return m.reply("❌ Gagal generate gambar")
    }

    const { imageUrl, prompt } = json.data

    await sock.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: `✨ *Text to Image*\n\n- 🖊 Prompt: ${prompt}`
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply("⚠️ Terjadi error saat generate image")
  }
}

handler.command = ["txt2img", "txtimg"]

export default handler
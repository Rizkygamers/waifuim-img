const handler = async (m, { sock, isBan }) => {
  try {
    if (isBan) return m.reply("mls lu di ban");

    const targetJid = m.quoted ? m.quoted.sender : m.sender;
    const targetNumber = targetJid.split("@")[0];

    let ppUrl;
    try {
      ppUrl = await sock.profilePictureUrl(targetJid, "image");
    } catch {
      ppUrl = "https://telegra.ph/file/265c672094dfa87caea19.jpg";
    }

    const pushName =
      sock.contacts?.[targetJid]?.name ||       
      sock.contacts?.[targetJid]?.notify ||
      m.quoted?.pushName ||
      m.pushName ||
      targetNumber;

    await sock.sendMessage(
      m.chat,
      {
        image: { url: ppUrl },
        caption: `*This is you*

› 👤 *name :* ${pushName}
› 📞 *number :* ${targetNumber}

_~Tetap hidup walau ga berguna yaa ∆_∆_`
      },
      { quoted: m }
    );
  } catch (err) {
    console.error("Error profile:", err);
    await m.reply("Terjadi kesalahan saat mengambil profil.");
  }
};

handler.command = ["pp", "im", "profile"];
export default handler;
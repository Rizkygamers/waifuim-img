const handler = async (m, { sock, getPluginStats, isBan, text }) => {

const info = getPluginStats();

if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
const jarrdev =`*Total Features Active 👀*
- Total fitur : (${info.totalFiles}) 
- Folder category : (${info.totalCategory}) folders 

*Info This Script ⭐*
- Name : ${namaBot}
- Creator : Jarr
- Version : ${versiBot}
- Type : Plugins (ESM)
- Library : Baileys`

m.reply(jarrdev)
}
handler.command = ["totalfitur","total","info"]
export default handler;
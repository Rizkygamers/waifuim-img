const handler = async (m, { sock, getPluginStats, isBan, text }) => {

if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
const teks =`*Hello 👋*
Here is some information about this script!

*Script Info 🤖*
- Name: ${namaBot}
- Version: ${versiBot}
- Type: plugin (ESM)
- Database: SQLite
- Library: baileys 

*Benefit 💰*
- Status script? berbayar!
- Harga Script Rp35.000
- Free updated — end version 
- Total fitur 200++
- Menggunakan database security 
- Script simpel & memiliki performa maksimal 
- Cocok untuk dijadikan bot pribadi 
- Support button & support all wa
- Desain simpel & elegan 
- Dukungan API's & Scrape 
- Fast respon 
- Bisa di jual ulang
- Masuk groups informasi update 
- dll

*💬 Berminat?*
- t.me/jarroffc2`
    await sock.sendMessage(m.chat, {
         document: { url: global.fotoBot },
          mimetype: "application/pdf", 
          fileName: `Hii ${m.pushName}`,
          fileLength: 9, 
          caption: teks,
          contextInfo: {
            mentionedJid: [m.sender],
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
              newsletterJid: global.idChannel,
              newsletterName: ``, 
              },
              externalAdReply: {
                  title: `Nice to meet you!`,
                  body: `⌯ ${global.namaBot} ⌯`,
                  thumbnailUrl: global.fotoBot,
                  sourceUrl: "https://me.jarr.biz.id",
                  mediaType: 1,
                  renderLargerThumbnail: true
              }
          }
      }, { quoted: m });
}
handler.command = ["sc", "scrip", "script"];
export default handler;
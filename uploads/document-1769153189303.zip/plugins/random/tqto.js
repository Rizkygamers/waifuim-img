const handler = async (m) => {
let tq =`*Thanks To 🌟*

- Allah SWT
- Nabi Muhammad SAW
- Orang Tua Saya
- Keluarga Saya
- Developer (Jarr Officiall)
- All penyedia api 
- Pembuat scrape 
- Para pembeli script 
- All creator script`
m.reply(tq)
}
handler.command = [
 "tqto"
] 
export default handler;
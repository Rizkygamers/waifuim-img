import fetch from "node-fetch";

const handler = async (m, { sock, isOwner, isSewa, isBan, usedPrefix }) => {
  try {
    if (isBan) return;
    if (!isOwner && !isSewa) return m.reply(mess.vip)

    const image = "https://api.deline.web.id/random/asupan";
    
    let caption = `📌 *Result*`;

    await sock.sendMessage(m.chat, {
      video: { url: image },
      caption
      },
      { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply("❌ Terjadi kesalahan saat mengambil data Blue Archive.");
  }
};

handler.command = ["as","asupan"];
export default handler;
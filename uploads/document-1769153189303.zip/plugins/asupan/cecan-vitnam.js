import fetch from "node-fetch";

const handler = async (m, { sock, isOwner, isSewa, isBan, usedPrefix }) => {
  try {
    if (isBan) return;
    if (!isOwner && !isSewa) return m.reply(mess.vip)

    const image = "https://api.nekolabs.web.id/random/girl/vietnam";
    
    let caption = `📌 *Result*`;

    await sock.sendMessage(m.chat, {
      image: { url: image },
      caption,
      footer: `© ${namaBot} 2025`,
        buttons: [
          {
            buttonId: `${usedPrefix}cecan-vietnam`,
            buttonText: { displayText: "Next" },
            type: 1
          }
        ],
        headerType: 1
      },
      { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply("❌ Terjadi kesalahan saat mengambil data Blue Archive.");
  }
};

handler.command = ["cecan-vietnam","vietnam","vi"];
export default handler;
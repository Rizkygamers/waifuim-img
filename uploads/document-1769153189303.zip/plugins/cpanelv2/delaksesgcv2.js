import fs from "fs"

const handler = async (m, { sock, isBan, isOwner, datagc2, text, reply }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!isOwner) return reply(mess.owner)
  if (datagc2.length < 1) return reply("Tidak ada grup reseller panel")
  if (!m.isGroup) return reply(mess.group)

  let input = text ? text : m.chat
  if (input == "all") {
    datagc2.length = 0
    await fs.writeFileSync("./data/premiumV2.json", JSON.stringify(datagc2, null, 2))
    return reply(`Berhasil menghapus semua grup reseller panel ✅`)
  }
  if (!datagc2.includes(input)) return reply(`Grup ini bukan grup reseller panel!`)
  let posi = datagc2.indexOf(input)
  await datagc2.splice(posi, 1)
  await fs.writeFileSync("./data/premiumV2.json", JSON.stringify(datagc2, null, 2))
  reply(`Berhasil menghapus grup reseller panel ✅`)
}

handler.command = ["delpremiumgc2", "delaksesgc2"]

export default handler
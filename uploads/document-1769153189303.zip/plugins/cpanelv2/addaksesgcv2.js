import fs from "fs"

const handler = async (m, { sock, isBan, isOwner, datagc2, reply }) => {

  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!isOwner) return reply(mess.owner)
  if (!m.isGroup) return reply(mess.group)

  const input = m.chat
  if (datagc2.includes(input))
    return reply(`Grup ini sudah di beri akses reseller panel!`)
  datagc2.push(input)
  await fs.writeFileSync("./data/premiumV2.json", JSON.stringify(datagc2, null, 2))
  reply(`Berhasil menambah grup reseller panel ✅`)
}

handler.command = ["aksesgc2", "addaksesgc2", "addpremiumgc2"]

export default handler
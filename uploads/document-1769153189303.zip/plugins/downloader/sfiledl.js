import axios from 'axios';

let handler = async (m, { sock, reply, usedPrefix, command, text, isBan }) => {
    if (isBan) return reply("lu di ban");
    if (!text) return reply(`Ex: ${usedPrefix}${command} https://sfile.mobi/xxxxx`);

    const url = encodeURIComponent(text.trim().split(/\s+/)[0]);
    if (!/(sfile\.mobi)/i.test(text)) return reply('Tautan yang diberikan bukan link sfile.mobi yang valid.');

    reply('Wait...');

    try {
        const api = `https://api.deline.web.id/downloader/sfile?url=${url}`;

        const { data } = await axios.get(api, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "application/json,text/html,*/*",
                "Referer": "https://api.deline.web.id/",
                "Origin": "https://api.deline.web.id",
            }
        });

        if (!data.status) return reply('Gagal mengambil data dari API Deline.');

        const dl = data.download;
        const meta = data.metadata;

        if (!dl) return reply("Link download kosong.");

        // Ambil buffer file
        const fileBuffer = (await axios.get(dl, {
            responseType: 'arraybuffer',
            headers: {
                "User-Agent": "Mozilla/5.0"
            }
        })).data;

        const fileName = meta.file_name || "file";
        const mimetype = meta.mimetype || "application/octet-stream";

        let caption = `*Downloader Succes!*`;

        await sock.sendMessage(m.chat, {
            document: fileBuffer,
            fileName,
            mimetype,
            caption
        }, { quoted: m });

    } catch (e) {
        console.log(e.response?.data || e);
        reply('❌ Error: ' + e.message);
    }
};

handler.command = ['sfilemobi', 'sfile'];
export default handler;
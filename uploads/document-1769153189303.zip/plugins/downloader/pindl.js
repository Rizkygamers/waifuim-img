import axios from "axios"

async function anakbaik(url) {
  try {
    let { data } = await axios.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile Safari/604.1"
      },
      maxRedirects: 5
    })
    let video = data.match(/"contentUrl":"(https:\/\/v1\.pinimg\.com\/videos\/[^\"]+\.mp4)"/)
    let image = data.match(/"imageSpec_736x":\{"url":"(https:\/\/i\.pinimg\.com\/736x\/[^\"]+\.(?:jpg|jpeg|png|webp))"/) || data.match(/"imageSpec_564x":\{"url":"(https:\/\/i\.pinimg\.com\/564x\/[^\"]+\.(?:jpg|jpeg|png|webp))"/)
    let thumb = data.match(/"thumbnail":"(https:\/\/i\.pinimg\.com\/videos\/thumbnails\/originals\/[^\"]+\.jpg)"/)
    let title = data.match(/"name":"([^"]+)"/)
    let author = data.match(/"fullName":"([^"]+)".+?"username":"([^"]+)"/)
    let date = data.match(/"uploadDate":"([^"]+)"/)
    let keyword = data.match(/"keywords":"([^"]+)"/)
    return {
      type: video ? "video" : "image",
      title: title ? title[1] : "-",
      author: author ? author[1] : "-",
      username: author ? author[2] : "-",
      media: video ? video[1] : image ? image[1] : "-",
      thumbnail: thumb ? thumb[1] : "-",
      uploadDate: date ? date[1] : "-",
      keywords: keyword ? keyword[1].split(",").map(x => x.trim()) : []
    }
  } catch (e) {
    return { error: e.message }
  }
}

const handler = async (m, { sock, text, reply, command, isBan, args, usedPrefix }) => {
  try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    let url = args[0]
    if (!url) return m.reply(`*Example :* ${usedPrefix}pindl https://pin.it/57IghwKl0`)
    reply("Wait. .  ")
    let res = await anakbaik(url)
    if (res.error) return m.reply(res.error)
    if (res.type === 'video') await sock.sendMessage(m.chat, { video: { url: res.media } }, { quoted: m })
    else await sock.sendMessage(m.chat, { image: { url: res.media } }, { quoted: m })
  } catch (e) {
    m.reply(e.message)
  }
}

handler.command = ["pindl", "pinterest"];
export default handler;
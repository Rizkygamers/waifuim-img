import axios from 'axios'
import * as cheerio from "cheerio";
import qs from 'qs'

const handler = async (m, { sock, reply, example, args, isBan }) => {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
  if (!args[0]) return m.reply(example('mana linknya'))
  m.reply('Wait . . .')
  try {
    const url = args[0]
    const payload = qs.stringify({ fb_url: url })
    const res = await axios.post('https://saveas.co/smart_download.php', payload, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0'
      }
    })
    const $ = cheerio.load(res.data)
    const hd = $('#hdLink').attr('href') || null
    const sd = $('#sdLink').attr('href') || null
    const video = hd || sd
    if (!video) return m.reply('gagal ambil link')
    await sock.sendMessage(m.chat, { video: { url: video } }, { quoted: m })
  } catch (e) {
    m.reply(`Eror kak : ${e.message}`)
  }
}

handler.command = ["fbdl", "fb"]
export default handler;
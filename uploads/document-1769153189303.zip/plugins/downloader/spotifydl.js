import fetch from "node-fetch";

if (!global.spotifySearch) global.spotifySearch = {};

const handler = async (m, { text, usedPrefix, command, sock, isBan }) => {
  
  if (isBan) return m.reply("lu di ban paok");
  if (!text) return m.reply(`Ex: ${usedPrefix + command} url`);

  let input = text.trim();
  let spotifyUrl;

  if (/^\d+$/.test(input)) {
    let list = global.spotifySearch[m.sender];
    if (!list) return m.reply(`Belum ada data pencarian.\nCari dulu pakai *${usedPrefix}spos <lagu>*`);

    let index = parseInt(input) - 1;
    if (!list[index]) return m.reply("Nomor tidak valid.");

    spotifyUrl = list[index].spotify_url;

  } else {
    if (!input.startsWith("https://open.spotify.com/track"))
      return m.reply("url tidak valid.");
    spotifyUrl = input;
  }

  m.reply("Wait...");

  try {
    const API = `https://ytdlpyton.nvlgroup.my.id/spotify/download/audio?url=${encodeURIComponent(spotifyUrl)}&mode=url`;

    const res = await fetch(API, {
      headers: {
        "accept": "application/json",
        "X-API-Key": "jarr"
      }
    });

    if (!res.ok) throw await res.text();

    const json = await res.json();

    if (!json.download_url)
      return m.reply("Gagal mendapatkan audio dari server.");

    await sock.sendMessage(
      m.chat,
      {
        audio: { url: json.download_url },
        mimetype: "audio/mpeg",
        contextInfo: {
          externalAdReply: {
            title: json.title,
            body: json.artist,
            thumbnailUrl: json.thumbnail,
            mediaType: 1,
            renderLargerThumbnail: true,
            sourceUrl: spotifyUrl
          }
        }
      },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    m.reply("❌ Terjadi kesalahan.\n" + e);
  }
};

handler.command = ["spotify", "spodl", "spo"];
export default handler;
import fetch from 'node-fetch'

let handler = async (m, { sock, args, usedPrefix, command, isBan }) => {
     
    if (isBan) return 
    if (!args[0]) return m.reply(`*Contoh:* ${usedPrefix + command} https://www.instagram.com/reel/xyz`)

    await m.reply('Wait. . .')

    try {
        let api = await fetch(`https://velyn.mom/api/downloader/instagram?apikey=jarrxz&url=${args[0]}`)
        let json = await api.json()

        if (json.status !== 200 || !json.data) {
            return m.reply('❌ Gagal mengambil data. Pastikan API Key valid atau link tidak private.')
        }

        let data = json.data
        let meta = data.metadata
        let mediaUrls = data.url 
        let captionText = `*Instagram Downloader*`
        if (meta.isVideo || mediaUrls[0].includes('.mp4')) {

            for (let vid of mediaUrls) {
                await sock.sendMessage(m.chat, { 
                    video: { url: vid }, 
                    caption: captionText 
                }, { quoted: m })
            }

        } else {

            if (mediaUrls.length > 1) {
                await sock.sendMessage(m.chat, { 
                    image: { url: mediaUrls[0] }, 
                    caption: captionText 
                }, { quoted: m })

                for (let i = 1; i < mediaUrls.length; i++) {
                    await sock.sendMessage(m.chat, { 
                        image: { url: mediaUrls[i] }
                    }, { quoted: m })
                }

            } else {
                await sock.sendMessage(m.chat, { 
                    image: { url: mediaUrls[0] }, 
                    caption: captionText 
                }, { quoted: m })
            }
        }

    } catch (e) {
        console.error(e)
        m.reply(`❌ Terjadi kesalahan: ${e}`)
    }
}

handler.command = ["instagram", "ig", "igdl", "reel", "reels"]
export default handler
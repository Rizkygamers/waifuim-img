import axios from "axios";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function download(url) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await axios.get(url, { responseType: "arraybuffer" });
      return Buffer.from(res.data);
    } catch (e) {
      console.log(`Download gagal (attempt ${attempt})`);
      await sleep(500);
    }
  }
  return null;
}

async function safeSend(sock, m, msg) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      await sock.sendMessage(m.chat, msg, { quoted: m });
      return true;
    } catch (e) {
      console.log(`Send gagal (attempt ${attempt})`);
      await sleep(800);
    }
  }
  return false;
}

const handler = async (m, { sock, text, reply, command, usedPrefix }) => {
  if (!text) return reply(`Ex: ${usedPrefix}${command} url`);

  reply("Wait…");

  try {
    const api = `https://chocomilk.amira.us.kg/v1/download/tiktok?url=${encodeURIComponent(text)}`;
    const { data } = await axios.get(api);

    if (!data?.success) return reply("Gagal ambil data");

    const res = data.data;

    if (res.type === "image" && res.media.images?.length) {
      
      for (let i = 0; i < res.media.images.length; i++) {
        const img = res.media.images[i];

        const buffer = await download(img);
        if (!buffer) continue;

        await safeSend(sock, m, { image: buffer });

        await sleep(1200);
      }

      if (res.media.audio) {
        await safeSend(sock, m, {
          audio: { url: res.media.audio },
          mimetype: "audio/mp4",
        });
      }

      return;
    }

    if (res.type === "video" && res.media.video) {

      const videoBuf = await download(res.media.video);
      if (!videoBuf) return reply("Gagal download videonya.");

      await safeSend(sock, m, {
        video: videoBuf,
        mimetype: "video/mp4",
        caption: "*TikTok* download results 🍟"
      });

      // audio opsional
      if (res.media.audio) {
        await safeSend(sock, m, {
          audio: { url: res.media.audio },
          mimetype: "audio/mp4"
        });
      }

      return;
    }

    reply("Tidak ada media.");

  } catch (e) {
    console.log(e);
    reply("Error!");
  }
};

handler.command = ["tt", "tiktok", "tiktokdl"];

export default handler;
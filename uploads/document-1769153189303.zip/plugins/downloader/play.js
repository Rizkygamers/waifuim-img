import yts from "yt-search"
import ytdl from '@vreden/youtube_scraper'
import decode from "audio-decode" 
import fetch from "node-fetch" 
import fs from "fs"
import { exec } from "child_process"
import path from "path"

async function generateWaveform(buffer) {
  try {
    const audioBuffer = await decode(buffer)
    const rawData = audioBuffer.getChannelData(0)
    const samples = 64
    const blockSize = Math.floor(rawData.length / samples)
    const waveform = new Uint8Array(samples)

    for (let i = 0; i < samples; i++) {
      const start = i * blockSize
      const end = start + blockSize
      let max = 0
      for (let j = start; j < end; j++) {
        const val = Math.abs(rawData[j])
        if (val > max) max = val
      }
      waveform[i] = Math.min(255, Math.floor(max * 255))
    }
    return waveform
  } catch (e) {
    console.log("Gagal generate waveform:", e)
    return new Uint8Array(64).fill(0)
  }
}

const handler = async (m, { sock, isBan, text, reply, example }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!text) return reply(example("judul lagunya?"))
  
  m.reply("Wait...")

  const filename = Math.floor(Math.random() * 10000)
  const mp3Path = path.join(process.cwd(), `temp_${filename}.mp3`)
  const oggPath = path.join(process.cwd(), `temp_${filename}.ogg`)

  try {
      let ytsSearchh = await yts(text)
      const rees = ytsSearchh.all[0]
      if (!rees) return m.reply("Lagu tidak ditemukan.")

      const anu = await ytdl.ytmp3(rees.url)

      if (anu.status) {
        let urlMp3 = anu.download.url

        const response = await fetch(urlMp3)
        const buffer = await response.buffer()

        fs.writeFileSync(mp3Path, buffer)

        const waveformArray = await generateWaveform(buffer)

        await new Promise((resolve, reject) => {
            exec(`ffmpeg -y -i "${mp3Path}" -c:a libopus -b:a 128k -vbr on -compression_level 10 "${oggPath}"`, (err) => {
                if (err) reject(err)
                else resolve()
            })
        })

        const oggBuffer = fs.readFileSync(oggPath)

        await sock.sendMessage(
          m.chat,
          {
            audio: oggBuffer, 
            mimetype: "audio/ogg; codecs=opus", 
            ptt: true, 
            waveform: waveformArray,
            contextInfo: {
              externalAdReply: {
                title: rees.title,
                body: rees.author.name,
                thumbnailUrl: rees.thumbnail,
                sourceUrl: rees.url,
                mediaType: 1,
                renderLargerThumbnail: true,
              },
            },
          },
          { quoted: m }
        )

        if (fs.existsSync(mp3Path)) fs.unlinkSync(mp3Path)
        if (fs.existsSync(oggPath)) fs.unlinkSync(oggPath)

      } else {
        return m.reply("Error! Gagal mengambil link download.")
      }

  } catch (e) {
      console.error(e)
      if (fs.existsSync(mp3Path)) fs.unlinkSync(mp3Path)
      if (fs.existsSync(oggPath)) fs.unlinkSync(oggPath)
      m.reply("Terjadi kesalahan, pastikan FFmpeg terinstall di server.")
  }
}

handler.command = ["play", "song"]

export default handler
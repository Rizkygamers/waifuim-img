/*

  Scrape ORI by Wolep 
  Edit by jarr

*/
import fetch from "node-fetch";

const yt = {
    url: Object.freeze({
        audio128: 'https://api.apiapi.lat',
        video: 'https://api5.apiapi.lat',
        else: 'https://api3.apiapi.lat',
        referrer: 'https://ogmp3.pro/'
    }),

    encUrl: (string) => string.split('').map(c => c.charCodeAt()).reverse().join(';'),
    xor: (string) => string.split('').map(s => String.fromCharCode(s.charCodeAt() ^ 1)).join(''),
    genRandomHex: () => {
        const hex = '0123456789abcdef'.split('')
        return Array.from({ length: 32 }, _ => hex[Math.floor(Math.random() * hex.length)]).join('')
    },

    init: async function (rpObj) {
        const { apiOrigin, payload } = rpObj
        const { data } = payload
        const api = apiOrigin + '/' + this.genRandomHex() + '/init/' + this.encUrl(this.xor(data)) + '/' + this.genRandomHex() + '/'
        
        try {
            let resp = await fetch(api, {
                method: 'post',
                body: JSON.stringify(payload),
                headers: { 'Content-Type': 'application/json' }
            })
            if (!resp.ok) throw Error(`${resp.status} ${resp.statusText}`)
            return await resp.json()
        } catch (e) {
            throw e
        }
    },

    genFileUrl: function (i, pk, rpObj) {
        const { apiOrigin } = rpObj
        const pk_value = pk ? pk + "/" : "";
        const downloadUrl = apiOrigin + "/" + this.genRandomHex() + "/download/" + i + "/" + this.genRandomHex() + "/" + pk_value;
        return { downloadUrl }
    },

    statusCheck: async function (i, pk, rpObj) {
        const { apiOrigin } = rpObj
        let json = {}
        let counter = 0
        do {
            await new Promise(resolve => setTimeout(resolve, 3000)) 
            counter++
            const pk_value = pk ? pk + '/' : ''
            let api = apiOrigin + '/' + this.genRandomHex() + '/status/' + i + '/' + this.genRandomHex() + '/' + pk_value
            
            const resp = await fetch(api, {
                method: 'post',
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ data: i })
            })
            
            if (!resp.ok) throw Error("Gagal cek status konversi")
            json = await resp.json()
            
            if(counter >= 30) throw Error("Time out! Proses terlalu lama.")
        } while (json.s === "P") 

        if (json.s === "E") throw Error('Server Error: Gagal mengkonversi file.')
        
        return this.genFileUrl(i, pk, rpObj)
    },

    download: async function (ytUrl, userFormat = '128k') {
        const rpObj = this.resolvePayload(ytUrl, userFormat)
        const initObj = await this.init(rpObj)
        const { i, pk, s } = initObj
        
        let result = { userFormat }
        if (s === 'C') { 
            const res = this.genFileUrl(i, pk, rpObj)
            Object.assign(result, res)
        } else {
            const res = await this.statusCheck(i, pk, rpObj)
            Object.assign(result, res)
        }
        return result
    },

    resolvePayload: function (ytUrl, userFormat) {
        // Logic default scraper
        let apiOrigin = this.url.audio128 
        let data = this.xor(ytUrl) 
        let referer = this.url.referrer
        let format = '0' // 0=audio
        let mp3Quality = '128' 
        let mp4Quality = '720' 

        if (userFormat === '128k') {
            apiOrigin = this.url.audio128
        } else if (/^\d+p$/.test(userFormat)) { // Video
            apiOrigin = this.url.video
            mp4Quality = userFormat.match(/\d+/g)[0]
            format = '1'
        } else {
            apiOrigin = this.url.else
            mp3Quality = userFormat.match(/\d+/g)[0]
        }
        
        const payload = {
            data, format, referer, mp3Quality, mp4Quality,
            "userTimeZone": "-480"
        }
        return { apiOrigin, payload }
    }
}

const handler = async (m, { sock, command, usedPrefix, text, isBan }) => {

  if (isBan) return m.reply("lu di ban paok");
  if (!text) return m.reply(`Ex: ${usedPrefix + command} url`);

  const url = text.trim();
  const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtube\.com\/shorts\/|youtu\.be\/)[\w-]{6,}/i;

  if (!ytRegex.test(url)) {
    return m.reply("Harap masukkan link YouTube yang benar.");
  }

  await m.reply("Wait. . .")

  try {
    let isAudio = command === "ytmp3"; 
    let format = isAudio ? "128k" : "720p"; 

    const data = await yt.download(url, format);

    if (!data.downloadUrl) return m.reply("Gagal mendapatkan URL download.");
    
    const stream = await fetch(data.downloadUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
            'Referer': 'https://ogmp3.pro/'
        }
    });

    if (!stream.ok) throw new Error(`Gagal download file: ${stream.statusText}`);
    
    const buffer = await stream.buffer();

    if (isAudio) {
      await sock.sendMessage(
        m.chat,
        {
          audio: buffer, // Gunakan buffer, bukan URL
          mimetype: "audio/mpeg",
          ptt: false, 
        },
        { quoted: m }
      );
    } else {
      await sock.sendMessage(
        m.chat,
        {
          video: buffer, // Gunakan buffer
          caption: `\`YOUTUBE DOWNLOADER\`\n\n- *Link:* ${url}\n- *Quality:* ${format}`,
          mimetype: "video/mp4"
        },
        { quoted: m }
      );
    }

  } catch (e) {
    console.error(e);
    m.reply("❌ Gagal Download.\n" + e.message);
  }
};

handler.command = ["ytmp3", "ytmp4"];
export default handler;
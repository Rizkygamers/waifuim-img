import fs from "fs"

const handler = async (m, { sock, isBan, isOwner, datagc1, reply }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!isOwner) return reply(mess.owner)
  if (!m.isGroup) return reply(mess.group)

  const input = m.chat
  if (datagc1.includes(input))
    return reply(`Grup ini sudah di beri akses reseller panel!`)
  datagc1.push(input)
  await fs.writeFileSync("./data/premiumV1.json", JSON.stringify(datagc1, null, 2))
  reply(`Berhasil menambah grup reseller panel ✅`)
}

handler.command = ["aksesgc", "addaksesgc", "addpremiumgc"]

export default handler
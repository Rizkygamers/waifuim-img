import fs from "fs"

const handler = async (m, { sock, isBan, isOwner, datagc1, reply }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!isOwner) return reply(mess.owner)
  if (datagc1.length < 1) return m.reply("Tidak ada group reseller di data!")

  let teks = `*—List All Grup Premium :*\n`
  for (let i of datagc1) {
    let name = (await sock.groupMetadata(i)).subject || "Tidak ditemukan"
    teks += `\n* ${i}\n* *Nama :* ${name}\n\n`
  }

  sock.sendMessage(m.chat, { text: teks, mentions: [] }, { quoted: m })
}

handler.command = ["listpremiumgc", "listaksesgc"]

export default handler
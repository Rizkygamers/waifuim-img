import fs from "fs"

const handler = async (m, { sock, isBan, isOwner, datagc1, text, reply }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!isOwner) return reply(mess.owner)
  if (datagc1.length < 1) return reply("Tidak ada grup reseller panel")
  if (!m.isGroup) return reply(mess.group)

  let input = text ? text : m.chat
  if (input == "all") {
    datagc1.length = 0
    await fs.writeFileSync("./data/premiumV1.json", JSON.stringify(datagc1, null, 2))
    return reply(`Berhasil menghapus semua grup reseller panel ✅`)
  }
  if (!datagc1.includes(input)) return reply(`Grup ini bukan grup reseller panel!`)
  let posi = datagc1.indexOf(input)
  await datagc1.splice(posi, 1)
  await fs.writeFileSync("./data/premiumV1.json", JSON.stringify(datagc1, null, 2))
  reply(`Berhasil menghapus grup reseller panel ✅`)
}

handler.command = ["delpremiumgc", "delaksesgc"]

export default handler
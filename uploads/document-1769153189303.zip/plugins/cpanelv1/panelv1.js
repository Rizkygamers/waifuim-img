const handler = async (m, { sock, text, args, isOwner, command, qtxt, reply, example, isPremGrupV1, usedPrefix }) => {

switch (command) {
case 'gantipwpanel': case 'ubahpw': {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply(example(`password baru,id user\nContoh: *${usedPrefix}gantipwpanel* jarr123,1\n\n*.listpanel2* untuk melihat id user`));
    const [newPassword, userId] = text.split(",").map(v => v?.trim());
    if (!newPassword || !userId) {
        return m.reply(example(`password baru,id user\nContoh: *.gantipwpanel* jarr123,1\n\n*${usedPrefix}listpanel2* untuk melihat id user`));
    }

    if (newPassword.length < 3 || /\s/.test(newPassword)) {
        return m.reply(`Password minimal 3 karakter dan tidak boleh mengandung spasi!`);
    }

    try {
        // Ambil data user lama
        const getRes = await fetch(`${global.domain}/api/application/users/${userId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${global.apikey}`,
                'Accept': 'application/json'
            }
        });

        const getData = await getRes.json();
        if (!getRes.ok) {
            return m.reply(`Gagal mengambil data user: ${getData.errors?.[0]?.detail || 'Unknown error'}`);
        }

        const user = getData.attributes;

        // Kirim patch lengkap + password baru
        const response = await fetch(`${global.domain}/api/application/users/${userId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${global.apikey}`,
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                email: user.email,
                username: user.username,
                first_name: user.first_name,
                last_name: user.last_name,
                language: user.language || 'en',
                root_admin: user.root_admin,
                password: newPassword
            })
        });

        const result = await response.json();
        if (!response.ok) {
            return m.reply(`Gagal mengganti password: ${result.errors?.[0]?.detail || 'Unknown error'}`);
        }

        m.reply(`*Berhasil Ganti Password ✅*
        
- User Id : ${userId}
- New Password : ${newPassword}
- Login : ${global.domain}

*⚠️ Jaga sebaik mungkin!*`);
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan: ${err.message}`);
    }
}
break;

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isOwner && !isPremGrupV1) return m.reply('Only owner dan grup dengan akses premium')
if (!text && !m.quoted && !m.mentionedJid[0])
  return m.reply(m.isGroup ? `Cara Pengguna:\n*${usedPrefix}1gb2 username,62xxx* atau reply pesan!` : `Cara Pengguna:\n*${usedPrefix}1gb2 username*`)
let usernameInput, nomorTujuan

if (m.isGroup) {
  if (text.includes(",")) {
    [usernameInput, nomorTujuan] = text.split(",")
    nomorTujuan = nomorTujuan.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
  } else if (m.quoted) {
    usernameInput = text.trim()
    nomorTujuan = m.quoted.sender
  } else if (m.mentionedJid[0]) {
    usernameInput = text.trim()
    nomorTujuan = m.mentionedJid[0]
  } else return m.reply(`Format: *${usedPrefix}1gb username,62xxx* atau reply pesan!`)
} else {
  usernameInput = text.trim()
  nomorTujuan = m.sender
}
    global.panel = usernameInput.trim()
    var ram, disknya, cpu
    if (command == "1gb") { ram = "1000"; disknya = "1000"; cpu = "40" }
    else if (command == "2gb") { ram = "2000"; disknya = "1000"; cpu = "60" }
    else if (command == "3gb") { ram = "3000"; disknya = "2000"; cpu = "80" }
    else if (command == "4gb") { ram = "4000"; disknya = "2000"; cpu = "100" }
    else if (command == "5gb") { ram = "5000"; disknya = "3000"; cpu = "120" }
    else if (command == "6gb") { ram = "6000"; disknya = "3000"; cpu = "140" }
    else if (command == "7gb") { ram = "7000"; disknya = "4000"; cpu = "160" }
    else if (command == "8gb") { ram = "8000"; disknya = "4000"; cpu = "180" }
    else if (command == "9gb") { ram = "9000"; disknya = "5000"; cpu = "200" }
    else if (command == "10gb") { ram = "10000"; disknya = "5000"; cpu = "220" }
    else { ram = "0"; disknya = "0"; cpu = "0" }

    let username = global.panel.toLowerCase()
    let email = username + "@jarr.com"
    let name = capital(username) + " Server"
    let password = username + "01"

    let f = await fetch(global.domain + "/api/application/users", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
        },
        body: JSON.stringify({
            email, username: username.toLowerCase(),
            first_name: name, last_name: "Server",
            language: "en", password
        })
    })
    let data = await f.json()
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
    let user = data.attributes
    let desc = tanggal(Date.now())
    let usr_id = user.id

    let f1 = await fetch(global.domain + `/api/application/nests/${nestid}/eggs/` + egg, {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
        }
    })
    let data2 = await f1.json()
    let startup_cmd = data2.attributes.startup

    let f2 = await fetch(global.domain + "/api/application/servers", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey,
        },
        body: JSON.stringify({
            name, description: desc, user: usr_id, egg: parseInt(egg),
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
            startup: startup_cmd,
            environment: {
                INST: "npm", USER_UPLOAD: "0",
                AUTO_UPDATE: "0", CMD_RUN: "npm start"
            },
            limits: {
                memory: ram, swap: 0, disk: disknya, io: 500, cpu
            },
            feature_limits: { databases: 5, backups: 5, allocations: 5 },
            deploy: {
                locations: [parseInt(loc)],
                dedicated_ip: false,
                port_range: [],
            },
        })
    })
    let result = await f2.json()
    if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
    let server = result.attributes

    let teks = `*Data Panel Anda 📦*
- *Nama Server :* ${name}
- *Username :* ${user.username}
- *Password :* ${password}
- *Login :* ${global.domain}

*Spesifikasi Server Panel ⚙️*
- *ID Server :* ${server.id}
- *Ram :* ${ram == "0" ? "unlimited" : ram.length > 4 ? ram.slice(0, 2) + "GB" : ram.charAt(0) + "GB"}
- *Cpu :* ${cpu == "0" ? "unlimited" : cpu + "%"}
- *Disk :* ${disknya == "0" ? "unlimited" : disknya.length > 4 ? disknya.slice(0, 2) + "GB" : disknya.charAt(0) + "GB"}

*⚠️ Jaga baik baik*`
// Kirim pesan tombol
await sock.sendMessage(nomorTujuan, {
  text: teks,
  contextInfo: { isForwarded: true }
}, { quoted: qtxt });
return await sock.sendMessage(m.key.remoteJid, { react: { text: "✅", key: m.key }});
    delete global.panel
}
break

case "listpanel": case "listp": case "listserver": {
if (!isOwner) return m.reply(mess.owner)
if (!global.apikey) return m.reply("Apikey Tidak Ditemukan!")
let page = 1
let allServers = []
  while (true) {
    let res = await fetch(`${global.domain}/api/application/servers?page=${page}`, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${global.apikey}`
      }
    })

    let data = await res.json()
    if (!data.data || data.data.length === 0) break

    allServers.push(...data.data)

    if (!data.meta?.pagination || page >= data.meta.pagination.total_pages) break
    page++
  }

  if (!allServers.length) return m.reply("Tidak ada server panel.")

  let teks = `*List All Server Panel 🖥️*\n> #Total: *${allServers.length} Server*\n\n`
  let no = 1

  for (let srv of allServers) {
    let s = srv.attributes
    let uuid = s.uuid.split("-")[0]
    let status = "unknown"

    try {
      let res = await fetch(`${global.domain}/api/client/servers/${uuid}/resources`, {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${global.capikey}`
        }
      })
      let json = await res.json()
      status = json.attributes?.current_state?.toUpperCase() || "unknown"
    } catch (e) {
      status = "unknown"
    }

    teks += `  • ID Server : *${s.id}*\n`
    teks += `  • ID User : *${s.user}*\n`
    teks += `  • Nama : *${s.name}*\n`
    teks += `  • RAM : *${s.limits.memory == 0 ? "Unlimited" : (s.limits.memory / 1000) + "GB"}*\n`
    teks += `  • Status : *${status}*\n\n`
  }
  return sock.sendMessage(m.chat, { text: teks }, { quoted: qtxt })
}
break

case "delpanel":
case "delp": {
  if (!isOwner) return m.reply(mess.owner)
  if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
  if (!args[0]) return m.reply(example(`id servernya\n\nuntuk melihat id server ketik *${usedPrefix}listpanel2*`))

  let f = await fetch(global.domain + "/api/application/servers?page=1", {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + global.apikey
    }
  })
  let result = await f.json()
  let servers = result.data
  let deletedUserId = null
  let deletedServerName = null

  for (let server of servers) {
    let s = server.attributes
    if (args[0] == s.id.toString()) {
      deletedUserId = s.user // <-- ambil user ID dari server
      deletedServerName = s.name

      // Hapus server
      await fetch(global.domain + `/api/application/servers/${s.id}`, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + global.apikey
        }
      })
      break
    }
  }
  if (!deletedUserId) return m.reply("*ID Server* Tidak Ditemukan")
  // Hapus user berdasarkan user ID
  await fetch(global.domain + `/api/application/users/${deletedUserId}`, {
    method: "DELETE",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + global.apikey
    }
  })
  m.reply(`Berhasil Menghapus Akun Panel *${capital(deletedServerName)}* (Server & User)`)
}
break

case "cadmin": case "cadp": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@jarrr.com"
let name = capital(args[0])
let password = username+"001"
let f = await fetch(global.domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + global.apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (!m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `*Yours Admin Panel 📦*
* *ID User :* ${user.id}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling Script
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* No rusuh`
await sock.sendMessage(orang, {
  text: teks,
  contextInfo: { isForwarded: true }
}, { quoted: qtxt });
}
break

case "deladmin": case "deladp": {
if (!isOwner) return m.reply(mess.owner)
if (!args[0]) return m.reply(example("id nya\n\nuntuk melihat id admin ketik *.listadmin*"))
let cek = await fetch(global.domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + global.apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(global.domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + global.apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("ID Admin Tidak Ditemukan!")
m.reply(`Berhasil Menghapus Admin Panel *${capital(getid)}*`)
}
break

case "listadmin": case "listadp": {
if (!isOwner) return m.reply(mess.owner)
let cek = await fetch(global.domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + global.apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak Ada Admin Panel")
var teks = "*List All Admin Panel 💻*\n\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `   ◦ ID User : *${i.attributes.id}*
   ◦ Nama : *${i.attributes.first_name}*\n\n`
})
m.reply(teks)
}
break

case "hpsallserver": case "delallsrv": case "clearserver": { 
if (!isOwner) return reply(mess.owner)
await reply(`*Memproses penghapusan semua user & server panel ⚠️*`)
try {
const headers = {
  "Authorization": "Bearer " + global.apikey,
  "Content-Type": "application/json",
  "Accept": "application/json",
};

async function getUsers() {
  try {
    const res = await axios.get(`${global.domain}/api/application/users`, { headers });
    return res.data.data;
  } catch (error) {
    reply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}

async function getServers() {
  try {
    const res = await axios.get(`${global.domain}/api/application/servers`, { headers });
    return res.data.data;
  } catch (error) {
    reply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}
async function deleteServer(serverUUID) {
  try {
    await axios.delete(`${global.domain}/api/application/servers/${serverUUID}`, { headers });
    console.log(`Server ${serverUUID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus server ${serverUUID}:`, error.response?.data || error.message);
  }
}
async function deleteUser(userID) {
  try {
    await axios.delete(`${global.domain}/api/application/users/${userID}`, { headers });
    console.log(`User ${userID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus user ${userID}:`, error.response?.data || error.message);
  }
}
async function deleteNonAdminUsersAndServers() {
  const users = await getUsers();
  const servers = await getServers();
  let totalSrv = 0
  for (const user of users) {
    if (user.attributes.root_admin) {
      console.log(`Lewati admin: ${user.attributes.username}`);
      continue; // Lewati admin
    }
    const userID = user.attributes.id;
    const userEmail = user.attributes.email;
    console.log(`Menghapus user: ${user.attributes.username} (${userEmail})`);
    // Cari server yang dimiliki user ini
    const userServers = servers.filter(srv => srv.attributes.user === userID);
    // Hapus semua server user ini
    for (const server of userServers) {
      await deleteServer(server.attributes.id);
      totalSrv += 1
    }
    // Hapus user setelah semua servernya terhapus
    await deleteUser(userID);
  }
await reply(`*Finished Cleaning the Panel ✅*

- Total *${totalSrv}* (user & server) panel dihapus 

*⚠️ Server yang dihapus bukan admin panel*`)
}
// Jalankan fungsi
return deleteNonAdminUsersAndServers();
} catch (err) {
return reply(`${JSON.stringify(err, null, 2)}`)
}
}
break

case "addserver": case "addsrv": { 
  if (!isOwner) return m.reply(mess.owner)
  if (!text) return m.reply(example(`id,nama,ram\nKetik: *${usedPrefix}listpanel2* untuk melihat id`));
  let [usr_id, nama, ramInput] = text.split(",");
  if (!usr_id || !nama || !ramInput) return m.reply(example(`id,nama,ram\nKetik: *${usedPrefix}listpanel2* untuk melihat id`));
  usr_id = usr_id.trim();
  nama = nama.trim();
  ramInput = ramInput.trim().toLowerCase();

  let ram, disknya, cpu;

  if (["unli", "unlimited"].includes(ramInput)) {
    ram = disknya = cpu = 0;
  } else if (/^\d+gb$/.test(ramInput)) {
    const gb = parseInt(ramInput.replace("gb", ""));
    if (gb < 1 || gb > 10) return reply("RAM hanya boleh dari 1GB sampai 10GB atau 'unli'");
    ram = gb * 1000;
    disknya = gb * 1000;
    cpu = 20 + (gb * 20); // contoh: 1gb = 40%, 2gb = 60%, dst
  } else {
    return reply("Format RAM salah. Gunakan seperti: 1gb - unli");
  }

  const desc = tanggal(Date.now());

  const getEgg = await fetch(`${global.domain}/api/application/nests/${nestid}/eggs/${egg}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${global.apikey}`
    }
  });

  const eggData = await getEgg.json();
  const startup_cmd = eggData.attributes.startup;

  const createServer = await fetch(`${global.domain}/api/application/servers`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${global.apikey}`
    },
    body: JSON.stringify({
      name: nama,
      description: desc,
      user: parseInt(usr_id),
      egg: parseInt(egg),
      docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
      startup: startup_cmd,
      environment: {
        INST: "npm", USER_UPLOAD: "0",
        AUTO_UPDATE: "0", CMD_RUN: "npm start"
      },
      limits: {
        memory: parseInt(ram),
        swap: 0,
        disk: parseInt(disknya),
        io: 500,
        cpu: parseInt(cpu)
      },
      feature_limits: { databases: 5, backups: 5, allocations: 5 },
      deploy: {
        locations: [parseInt(loc)],
        dedicated_ip: false,
        port_range: [],
      },
    })
  });

  const result = await createServer.json();

  if (result.errors) return reply("Gagal menambah server:\n" + JSON.stringify(result.errors[0], null, 2));
  const server = result.attributes;

  let teks = `*Succes Create New Server ✅*
- User ID : ${usr_id}
- Server ID : ${server.id}
- Nama Server : ${nama}

*Server Specifications 🖥️*
- Ram : ${ram == 0 ? "Unlimited" : `${ram / 1000}GB`}
- Disk : ${disknya == 0 ? "Unlimited" : `${disknya / 1000}GB`}
- CPU : ${cpu == 0 ? "Unlimited" : cpu + "%"}`;

  await sock.sendMessage(m.chat, { text: teks, contextInfo: { isForwarded: true } }, { quoted: qtxt });
}
break;

}}
handler.command = [
  "1gb","2gb","3gb","4gb","5gb",
  "6gb","7gb","8gb","9gb","10gb",
  "unli","unlimited",
  "listserver","listp","listpanel",
  "delp","delpanel",
  "cadp","cadmin","deladp","deladmin",
  "listadp","listadmin",
  "clearserver","delallsrv","hpsallserver",
  "addsrv","addserver",
  "ubahpw","gantipwpanel"
]
export default handler;
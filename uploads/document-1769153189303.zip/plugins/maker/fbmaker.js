import { upload } from '../../control/uploader.js'

const handler = async (m, { sock, text, command, reply, owners, example, args, isSewa, isOwner, isBan }) => {
    try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner && !isSewa) return reply(mess.vip)
        if (!args[0]) {
            return m.reply(example(`nama|komentarnya (dengan kirim foto atau reply foto yaa!)`))
        }

        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';
        if (!mime || !/image\/(jpeg|png)/.test(mime)) {
            return m.reply(example(`nama|komentarnya (dengan kirim foto atau reply foto yaa!)`))
        }

        let media = await q.download();
        let up = await upload(media).catch(() => null);
        if (!up) {
            return m.reply('*Gagal mengunggah ke server. Coba lagi nanti yaa!*');
        }

        let [name, comment] = args.join(' ').split('|');
        if (!name || !comment) {
            return m.reply(example(`nama|komentarnya (dengan kirim foto atau reply foto yaa!)`))
        }
    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        let apiUrl = `https://api.zenzxz.my.id/maker/fakefb?name=${encodeURIComponent(
            name
        )}&comment=${encodeURIComponent(comment)}&ppurl=${encodeURIComponent(up)}`;
        let buffer = Buffer.from(await (await fetch(apiUrl)).arrayBuffer());

        await sock.sendMessage(m.chat, {
        image: buffer,
        caption: `Sukses Kak ✨`
        }, { quoted: m })
    } catch (e) {
        console.error(e);
        m.reply('*Yaaah, gagal buat fake Facebook-nya!*');
    } finally {
        await sock.sendMessage(m.chat, { react: { text: '', key: m.key } });
    }
};

handler.command = ["fakefb","fbcoment"]
export default handler;
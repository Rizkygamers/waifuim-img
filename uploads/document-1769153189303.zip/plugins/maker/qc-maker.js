import axios from "axios"

const handler = async (m, { sock, text, isBan, reply, command, usedPrefix }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })

  if (!text)
    return reply(`Example: *${usedPrefix}${command}* teksnya`)

  const avatarUrl = await sock.profilePictureUrl(m.sender, "image")
    .catch(() => "https://telegra.ph/file/6880771a42bad09dd6087.jpg")

  const url = `https://api.deline.web.id/maker/qc?text=${encodeURIComponent(text)}&color=white&avatar=${encodeURIComponent(avatarUrl)}&nama=${encodeURIComponent(m.pushName)}`

  try {
    const res = await axios.get(url, {
      responseType: "arraybuffer"
    })

    const buffer = Buffer.from(res.data)

    await sock.sendImageAsSticker(
      m.chat,
      buffer,
      m,
      { author: "jarr where are you?" }
    )

  } catch (e) {
    console.error(e)
    reply("❌ Gagal membuat QC sticker")
  }
}

handler.command = ["qc"]
export default handler
import axios from "axios"

const handler = async (m, { sock, text, isBan, example }) => {
  try {
    if (isBan)
      return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })

    if (!text || !text.includes("+"))
      return m.reply(example("😀+😍"))

    const [e1, e2] = text.split("+")
    const url = `https://api.jarroffc.my.id/tools/emojimix?apikey=jarroffc&emoji1=${encodeURIComponent(e1)}&emoji2=${encodeURIComponent(e2)}`

    const res = await axios.get(url, { responseType: "arraybuffer" })
    const buffer = Buffer.from(res.data)

    await sock.sendImageAsSticker(m.chat, buffer, m, {
      packname: "EmojiMix",
      author: "jarr where are you?"
    })
  } catch (err) {
    console.error("❌ EmojiMix Error:", err)
    m.reply("⚠️ Gagal membuat emojimix, coba emoji lain!")
  }
}

handler.command = ["emojimix","mojimix","mix"]
export default handler
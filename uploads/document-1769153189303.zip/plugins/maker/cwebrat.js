import axios from "axios"

const handler = async (m, { sock, text, isBan, reply, command, usedPrefix }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!text)
    return reply(`Example: *${usedPrefix}${command}* teksnya`)

  const media = `https://api.deline.web.id/maker/cewekbrat?text=${encodeURIComponent(text)}`
  await sock.sendImageAsSticker(m.chat, media, m, { author: "jarr where are you?" })
}

handler.command = ["cwbrat", "cwb", "bratcewe", "cewebrat"]
export default handler
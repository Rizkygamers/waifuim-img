// plugins/fakeff.js
import axios from "axios";

const handler = async (m, { sock, text, command, reply, isBan, usedPrefix }) => {
  try {
    if (isBan) return reply("lu di ban")
    if (!text) return reply(`Example:\n${usedPrefix}${command} username`);
    reply ("Wait...")
    const url = `https://api.deline.web.id/maker/lobbyffmax?text=${encodeURIComponent(
      text
    )}`;

    const buffer = (await axios.get(url, { responseType: "arraybuffer" })).data;

    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `Result ✓`
      },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    reply("Error bang, API nya mungkin lagi error!");
  }
};

handler.command = ["fakeff", "fff", "fakeloby"]
export default handler;
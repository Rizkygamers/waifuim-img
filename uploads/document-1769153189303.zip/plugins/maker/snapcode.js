import fetch from "node-fetch"

const handler = async (m, { sock, isBan, isOwner, isSewa, text, reply, mess, example }) => {
  
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })

  if (!text)
    return m.reply(example(`*console.log("hello world")*`))

  try {
    // React loading
    await m.reply("Wait. . .")

    // API Carbonara
    const apiUrl = "https://carbonara.solopov.dev/api/cook"
    const res = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: text })
    })

    if (!res.ok) throw new Error("🚨 API Error")

    const imageBuffer = await res.arrayBuffer()
    await sock.sendMessage(
      m.chat,
      {
        image: Buffer.from(imageBuffer),
        caption: `This is the *Result!*`
      },
      { quoted: m }
    )
  } catch (err) {
    console.error("❌ Snapcode Error:", err)
    m.reply("*Gagal membuat gambar code!*")
  } finally {
    // Hapus reaksi (kosongkan)
    await sock.sendMessage(m.chat, { react: { text: "", key: m.key } })
  }
}

handler.command = ["snapcode"]

export default handler
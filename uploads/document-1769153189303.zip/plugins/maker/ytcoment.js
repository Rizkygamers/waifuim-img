import { upload } from "../../control/uploader.js";

const handler = async (m, { sock, text, command, reply, owners, example, args, isSewa, isOwner, isBan }) => {
  try {
    if (isBan) return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    if (!isOwner && !isSewa) return reply(mess.vip);

    if (!args[0]) return reply(example("username|komen nya (kirim foto atau reply foto)"));

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";

    if (!mime.match(/image\/(jpe?g|png)/))
      return reply(example("username|komen nya (kirim foto atau reply foto)"));

    reply("Wait. . .")

    const media = await q.download();
    const up = await upload(media).catch(() => null);
    if (!up) return reply("⚠️ *Gagal mengunggah ke server. Coba lagi nanti ya!*");

    const [username, comment] = args.join(" ").split("|");
    if (!username || !comment) return reply(example("username|komen nya (kirim foto atau reply foto)"));

    const apiUrl = `https://api.zenzxz.my.id/maker/ytcomment?text=${encodeURIComponent(comment)}&avatar=${encodeURIComponent(up)}&username=${encodeURIComponent(username)}`;
    const res = await fetch(apiUrl);
    const buffer = Buffer.from(await res.arrayBuffer());

    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: "Sukses membuat fake YouTube comment!",
      },
      { quoted: m }
    );
  } catch (e) {
    console.error(e);
    reply("*Yaaah, gagal buat fake YouTube comment-nya!*");
  }
};

handler.command = ["ytcoment", "fakeyt"];
export default handler;
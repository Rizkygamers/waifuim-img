import { upload } from '../../control/uploader.js'

const handler = async (m, { sock, text, command, reply, example, args, isSewa, isOwner, isBan }) => {
    try {
        if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        if (!isOwner && !isSewa) return reply(mess.vip)
        if (!args[0]) {
            return m.reply(example(`nama|durasi call (dengan kirim foto atau reply foto ya!)`))
        }

        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';
        if (!mime || !/image\/(jpeg|png)/.test(mime)) {
            return m.reply(example(`nama|durasi call (dengan kirim foto atau reply foto ya!)`))
        }

        let media = await q.download();
        let up = await upload(media).catch(() => null);
        if (!up) return m.reply('*Gagal mengunggah ke server. Coba lagi nanti*');

        let [nama, durasi] = args.join(' ').split('|');
        if (!nama || !durasi) {
            return m.reply(example(`nama|durasi call (dengan kirim foto atau reply foto ya!)`))
        }
        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        let apiUrl = `https://api.zenzxz.my.id/maker/fakecall?nama=${encodeURIComponent(
            nama
        )}&durasi=${encodeURIComponent(durasi)}&avatar=${encodeURIComponent(up)}`;
        let buffer = Buffer.from(await (await fetch(apiUrl)).arrayBuffer());

        await sock.sendMessage(m.chat, {
        image: buffer,
        caption: `Sukses Kak ✨`
        }, { quoted: m })
    } catch (e) {
        console.error(e);
        m.reply('*Gagal buat fakecall-nya!*');
    } finally {
        await sock.sendMessage(m.chat, { react: { text: '', key: m.key } });
    }
};


handler.command = ["fakecall","fc"]
export default handler;
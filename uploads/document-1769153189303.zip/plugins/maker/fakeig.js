import { upload } from '../../control/uploader.js'

const handler = async (m, { sock, text, command, reply, owners, example, args, isSewa, isOwner, isBan }) => {
    try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner && !isSewa) return reply(mess.vip)
        if (!args[0]) {
            return m.reply(example(`Username|Caption (dengan reply foto atau kirim foto)`))
        }
        
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || ''
        if (!mime || !/image\/(jpeg|png|jpg)/.test(mime)) {
            return m.reply(example(`Username|Caption (dengan reply foto atau kirim foto)`))
        }
        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        let media = await q.download().catch(() => null)
        if (!media) return m.reply('*Gagal mengunduh foto profil!*')

        let uploaded = await upload(media).catch(() => null)
        if (!uploaded) return m.reply('*Upload gagal! Coba lagi nanti~*')

        let [username, caption] = args.join(' ').split('|')
        if (!username || !caption) {
            return m.reply(example(`Username|Caption`))
        }

        let apiUrl = `https://api.zenzxz.my.id/maker/fakestory?username=${encodeURIComponent(
            username
        )}&caption=${encodeURIComponent(caption)}&ppurl=${encodeURIComponent(uploaded)}`

        let response = await fetch(apiUrl)
        if (!response.ok) return m.reply('*Gagal menghubungi API Fake Story!*')

        let buffer = Buffer.from(await response.arrayBuffer())

        await sock.sendMessage(m.chat, {
        image: buffer,
        caption: `Sukses Kak ✨`
        }, { quoted: m })
    } catch (e) {
        console.error(e)
        m.reply(`*Ups, error*\nDetail: ${e.message || e}`)
    } finally {
        await sock.sendMessage(m.chat, { react: { text: '', key: m.key } });
    }
}

handler.command = ["fakestoryig","fakeig"]
export default handler;
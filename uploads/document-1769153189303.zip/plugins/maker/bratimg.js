import axios from "axios"

const handler = async (m, { sock, text, isBan, reply, command, usedPrefix }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
  if (!text)
    return reply(`Example: *${usedPrefix}${command}* teksnya`)

  const media = `https://api.nekolabs.web.id/canvas/brat/v1?text=${encodeURIComponent(text)}`
  await sock.sendImageAsSticker(m.chat, media, m, { author: "jarr where are you?" })
}

handler.command = ["brat"]
export default handler
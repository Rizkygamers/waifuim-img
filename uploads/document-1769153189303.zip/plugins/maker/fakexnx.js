// plugins/fakenx.js
import axios from "axios";

const handler = async (m, { sock, text, command, reply, usedPrefix, isBan }) => {
  try {
    if (isBan) return reply ("lu di ban")
    if (!text) {
      return reply(`Example: ${usedPrefix}${command} agas|anjir emak teman gua|99|0`);
    }
    reply("Wait...")
    const [name, quote, likes, dislikes] = text.split("|");

    if (!name || !quote || !likes || !dislikes) {
      return reply(`Format salah!\nContoh:\n.${command} someone|anjir emak teman gua|99|0`);
    }

    const url = `https://api.deline.web.id/maker/fake-xnxx?name=${encodeURIComponent(
      name
    )}&quote=${encodeURIComponent(quote)}&likes=${likes}&dislikes=${dislikes}`;

    const buffer = (await axios.get(url, { responseType: "arraybuffer" })).data;

    await sock.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `Succes 🗿`
      },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    reply("Error bang, API nya mungkin lagi down!");
  }
};

handler.command = ["fakenx", "fnxn", "fakexnxx"]
export default handler;
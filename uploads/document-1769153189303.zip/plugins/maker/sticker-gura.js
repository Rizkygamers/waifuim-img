import fs from "fs"
import FormData from "form-data"
import fetch from "node-fetch"
import { fileTypeFromBuffer } from "file-type"

const handler = async (m, { sock, isBan, example }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })

  const qmsg = m.quoted ? m.quoted : m
  const mime = (qmsg.msg || qmsg).mimetype || ''
  if (!/image/.test(mime))
    return m.reply(example("reply gambar atau kirim gambar"))

  m.reply("Wait. . .")

  async function uploadToCatbox(buffer) {
    const typeInfo = await fileTypeFromBuffer(buffer)
    const ext = typeInfo?.ext || "bin"
    const form = new FormData()
    form.append("fileToUpload", buffer, "file." + ext)
    form.append("reqtype", "fileupload")
    const res = await fetch("https://catbox.moe/user/api.php", { method: "POST", body: form })
    const url = await res.text()
    return url.trim()
  }

  try {
    const mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)
    const buffer = fs.readFileSync(mediaPath)
    const imageUrl = await uploadToCatbox(buffer)
    const apiRes = await fetch(`https://api.nekolabs.my.id/canvas/gura?imageUrl=${encodeURIComponent(imageUrl)}`)
    if (!apiRes.ok) throw new Error(`API error: ${apiRes.status}`)
    const resultBuffer = await apiRes.buffer()

    await sock.sendImageAsSticker(m.chat, resultBuffer, m, { author: "jarr where are you?" })
    fs.unlinkSync(mediaPath)
  } catch (err) {
    console.error("❌ Gura Error:", err)
    m.reply("Terjadi kesalahan!\n" + err.message)
  }
}

handler.command = ["gura", "sgura", "stiker-gura"]
export default handler
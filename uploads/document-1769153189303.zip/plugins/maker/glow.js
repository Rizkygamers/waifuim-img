import fetch from "node-fetch";

const handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Ex: ${usedPrefix}${command} jarr sigma`);

  try {
    const api = `https://api.nekolabs.web.id/ephoto/advanced-glow?text=${encodeURIComponent(text)}`;
    const res = await fetch(api);

    if (!res.ok) throw await res.text();

    const buffer = await res.arrayBuffer();
    await sock.sendMessage(m.chat, { image: Buffer.from(buffer), caption: `Results\n› Text: ${text}` }, { quoted: m });

  } catch (e) {
    console.error(e);
    m.reply("Error bang, API nya mungkin down.");
  }
};


handler.command = ["ephoto", "glow", "ephotoglow"];
export default handler;
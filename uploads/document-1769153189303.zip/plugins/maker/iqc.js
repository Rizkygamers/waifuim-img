import axios from "axios"

const handler = async (m, { sock, isBan, text, reply, example }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })

  if (!text)
    return reply(example("teks ny"))
  const pad = n => String(n).padStart(2, "0")
  const now = new Date()
  const nowTime = `${pad(now.getHours())}.${pad(now.getMinutes())}`

  try {
    const url = `https://api.zenzxz.my.id/maker/fakechatiphone?text=${encodeURIComponent(text)}&chatime=${nowTime}&statusbartime=${nowTime}`
    const { data } = await axios.get(url, { responseType: "arraybuffer" })

    await sock.sendMessage(
      m.chat,
      {
        image: Buffer.from(data),
        caption: `*Fake Chat iPhone ✅*`
      },
      { quoted: m }
    )
  } catch (err) {
    console.error("❌ IQC Error:", err)
    reply("Gagal membuat fake chat!")
  }
}

handler.command = ["iqc"]

export default handler
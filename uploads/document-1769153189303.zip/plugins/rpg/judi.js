
let handler = async (m, { args, reply, getUser, incrementData, isBan, usedPrefix, command }) => {
    if (isBan) return 
    let user = await getUser(m.sender, m.pushName);
    let count = args[0];

    if (!count) return reply(`Penggunan: ${usedPrefix+command} <jumlah>\nContoh: ${usedPrefix+command} 1000`);
    
    if (count === 'all') count = user.balance;
    count = parseInt(count);

    if (user.balance < count) return reply(`Not enough money!\n- Saldo: ${user.balance})`);
    if (count < 100) return reply('Minimal taruhan 100 perak.');

    let menang = Math.random() < 0.5; 

    if (menang) {
        let hadiah = count; 
        await incrementData('users', m.sender, 'balance', hadiah);
        reply(`*JACKPOT 🎉* 
        
- 💬 Kamu menang Rp ${hadiah}
- 💰 Saldo sekarang: ${user.balance + hadiah}`);
    } else {
        await incrementData('users', m.sender, 'balance', -count);
        reply(`*RUNGKAD 📉* 
- 💬 Kamu kalah Rp ${count}
- 💰 Saldo sekarang: ${user.balance - count}`);
    }
}

handler.command = ["casino", "judi", "slot"]
export default handler;
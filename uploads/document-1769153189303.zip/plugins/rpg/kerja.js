
const cooldowns = new Map();

const handler = async (m, { sock, getUser, incrementData, isBan }) => {
    if (isBan) return 
    const user = await getUser(m.sender);
    const timeout = 300000; 
    const now = Date.now();

    if (cooldowns.has(m.sender)) {
        const expirationTime = cooldowns.get(m.sender) + timeout;
        
        if (now < expirationTime) {
            const timeLeft = expirationTime - now;
            return m.reply(`⏳ Kamu lelah bekerja!\nIstirahat dulu selama *${clockString(timeLeft)}*`);
        }
    }

    const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

    const uang = rand(1000, 4000);   
    const exp = rand(100, 400);      
    const bonusGold = Math.random() < 0.1 ? 1 : 0;
    
    const jobList = [
        "⛏️ Penambang", "🧹 Tukang Bersih-bersih", "👷 Kuli Bangunan",
        "📦 Kurir Paket", "🍕 Pengantar Makanan", "🚕 Supir Taksi",
        "💻 Programmer", "🧪 Ilmuwan", "🎨 Seniman", "🐮 Peternak",
        "👨‍🏫 Guru Honorer", "👨‍🍳 Koki", "👨‍🔧 Montir"
    ];
    const job = jobList[Math.floor(Math.random() * jobList.length)];

    try {
        await incrementData('users', m.sender, 'balance', uang);
        await incrementData('users', m.sender, 'exp', exp);
        
        if (bonusGold > 0) {
            await incrementData('users', m.sender, 'gold', bonusGold);
        }

        cooldowns.set(m.sender, now);

        const text = `💼 *LAPORAN KERJA*
Profesi: *${job}*

💰 Gaji: *+${uang}*
✨ Exp: *+${exp}*
${bonusGold > 0 ? '🪙 Bonus: *+1 Gold*' : ''}

_Kerja bagus! Lanjutkan semangatmu._ 🛠️
`.trim();

        await m.reply(text);

    } catch (e) {
        console.error(e);
        m.reply("❌ Gagal menyimpan data pekerjaan.");
    }
}

handler.help = ["work"];
handler.tags = ["rpg"];
handler.command = ["kerja", "carikerja", "work"];
export default handler;

// ======================
function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, "0")).join(':');
}
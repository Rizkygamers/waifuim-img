
const cooldowns = new Map();

const handler = async (m, { getUser, incrementData, isBan }) => {
    if (isBan) return 
    const user = await getUser(m.sender);

    const cooldownTime = 180000;
    const now = Date.now();
    
    if (cooldowns.has(m.sender)) {
        const lastTime = cooldowns.get(m.sender);
        const remaining = (lastTime + cooldownTime) - now;
        
        if (remaining > 0) {
            return m.reply(`🎣 Ikan sudah habis! Tunggu sebentar.\nBisa mancing lagi dalam: *${clockString(remaining)}*`);
        }
    }

    if (user.health < 40) {
        return m.reply(`❤️ *Kamu terlalu lelah! (${user.health} HP)*\nMinimal 40 HP untuk memancing.\nIstirahat atau beli potion dulu.`);
    }

    const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

    const ikanDapat = rand(1, 6);        
    const hargaIkan = 500;               
    const totalUang = ikanDapat * hargaIkan;

    const dapatCrate = Math.random() < 0.1 ? 1 : 0;
    const damage = rand(5, 15);
    try {
        await incrementData('users', m.sender, 'health', -damage);
        await incrementData('users', m.sender, 'balance', totalUang);
        if (dapatCrate > 0) {
            await incrementData('users', m.sender, 'common_crate', 1);
        }
        cooldowns.set(m.sender, now);
        let msg = `🎣 *HASIL MEMANCING*

🐟 Tangkapan: ${ikanDapat} Ekor
💰 Terjual: +${totalUang} (Balance)
${dapatCrate > 0 ? '🎁 *LUCKY!* Dapat +1 Common Crate' : ''}

❤️ Tenaga berkurang: -${damage} HP
`.trim();

        m.reply(msg);

    } catch (e) {
        console.error(e);
        m.reply('Error saat menyimpan data fishing.');
    }
}

handler.command = ["fish", "mancing", "pancing"];
export default handler;

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s]
        .map(v => v.toString().padStart(2, "0"))
        .join(":");
}
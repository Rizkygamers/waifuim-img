
let handler = async (m, { args, sock, reply, usedPrefix, command, getUser, incrementData, isBan }) => {
    if (isBan) return 
    if (!m.mentionedJid[0]) return reply(`Tag orang yang mau dikirim uang!\nContoh: ${usedPrefix + command} @tag 1000`);
    
    let target = m.mentionedJid[0];
    let amount = parseInt(args[1]);
    let senderData = await getUser(m.sender, m.pushName);

    if (!amount || amount < 100) return reply('Minimal transfer 100 perak.');
    if (senderData.balance < amount) return reply(`Uang Anda kurang! (Saldo: ${senderData.balance})`);

    await getUser(target, "User"); 

    await incrementData('users', m.sender, 'balance', -amount);
    await incrementData('users', target, 'balance', amount);

    reply(`*TRANSFER SUKSES ✅*\n\n` +
          `💸 Nominal: Rp ${amount}\n` +
          `➡️ Penerima: @${target.split('@')[0]}\n` +
          `💰 Sisa Saldo: ${senderData.balance - amount}`);
}

handler.command = ["transfer", "tf", "kirim"];
export default handler;
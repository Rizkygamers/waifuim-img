
const advCooldown = new Map();

const handler = async (m, { sock, usedPrefix, getUser, incrementData, isBan }) => {
    try {
        if (isBan) return 
        const user = await getUser(m.sender);
        const cooldownTime = 3600000;
        const now = Date.now();

        if (advCooldown.has(m.sender)) {
            const lastTime = advCooldown.get(m.sender);
            const remaining = (lastTime + cooldownTime) - now;

            if (remaining > 0) {
                return m.reply(`⏳ Kamu masih lelah berpetualang.\nIstirahat dulu: *${clockString(remaining)}*`);
            }
        }

        if (user.health < 80) {
            return m.reply(
                `❤️ *Nyawamu Sekarat! (${user.health} HP)*\n` +
                `Minimal *80 HP* untuk adventure.\n\n` +
                `Beli potion:\n*${usedPrefix}shop potion 1*\n` +
                `Pakai potion:\n*${usedPrefix}use potion 1*`
            );
        }

        const lokasi = pickRandom([
            "Jepang 🇯🇵", "Korea 🇰🇷", "Bali 🇮🇩", "Amerika 🇺🇸", "Arab 🇸🇦",
            "Jerman 🇩🇪", "Mars 🪐", "Hutan Amazon 🌴", "Atlantis 🌊",
            "Gunung Everest 🏔️", "Mesir 🇪🇬", "Ujung Dunia 🌌"
        ]);

        const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

        const lostHealth = rand(10, 40);
        const exp = rand(1000, 10000);
        const money = rand(1000, 50000); 
        
        const potion = rand(0, 3);
        const diamond = rand(0, 3);
        const iron = rand(1, 15);
        const gold = rand(0, 5);  
        const crate = rand(0, 2); 
        
        await incrementData('users', m.sender, 'health', -lostHealth);
        await incrementData('users', m.sender, 'exp', exp);
        await incrementData('users', m.sender, 'balance', money);
        
        if (potion > 0) await incrementData('users', m.sender, 'potion', potion);
        if (diamond > 0) await incrementData('users', m.sender, 'diamond', diamond);
        if (iron > 0) await incrementData('users', m.sender, 'iron', iron);
        if (gold > 0) await incrementData('users', m.sender, 'gold', gold);
        if (crate > 0) await incrementData('users', m.sender, 'common_crate', crate);

        advCooldown.set(m.sender, now);

        const text = `🌍 *ADVENTURE LOG*
Tujuan: *${lokasi}*

❤️ Nyawa: -${lostHealth}
✨ Exp: +${exp}
💰 Uang: +${money}

🎁 *Barang Ditemukan:*
⛓️ Iron: +${iron}
🧪 Potion: +${potion}
💎 Diamond: +${diamond}
🪙 Gold: +${gold}
📦 Crate: +${crate}
`.trim();

        await sock.sendMessage(m.chat, { text }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply("❌ Error fitur adventure (Database).");
    }
}

handler.help = ["adventure"];
handler.tags = ["rpg"];
handler.command = ["adventure", "adv", "petualang"];

export default handler;

// =============== UTIL ===============
function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, "0")).join(':');
}
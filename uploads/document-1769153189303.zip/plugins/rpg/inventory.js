
const handler = async (m, { getUser, isBan }) => {
    if (isBan) return 
    const user = await getUser(m.sender);
    const text = `🎒 *INVENTORY POCKET*
👤 User: ${user.name}

❤️ *Status*
› Health: ${user.health}
› Stamina: ${user.stamina}

🧪 *Consumables*
› Potion: ${user.potion}
› Diamond: ${user.diamond}

📦 *Crates*
› Common Crate: ${user.common_crate}

⛏️ *Materials*
› Iron: ${user.iron}
› Gold: ${user.gold}

⚔️ *Equipment*
› Sword: ${user.sword}

_Note: Item sampah/ikan dikonversi otomatis ke Balance/Uang._
`.trim();

    m.reply(text);
}

handler.command = ["inv", "inventory", "bag"];
export default handler;
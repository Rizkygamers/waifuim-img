
const cooldowns = new Map();

const handler = async (m, { usedPrefix, getUser, incrementData, isBan }) => {
    if (isBan) return 
    const user = await getUser(m.sender);
    const cooldownTime = 300000; // 5 menit
    const now = Date.now();
    
    if (cooldowns.has(m.sender)) {
        const lastTime = cooldowns.get(m.sender);
        const remaining = (lastTime + cooldownTime) - now;
        
        if (remaining > 0) {
            return m.reply(`⛏️ Kamu lelah! Istirahat dulu.\nBisa nambang lagi dalam: *${clockString(remaining)}*`);
        }
    }

    if (user.health < 50) {
        return m.reply(`❤️ *Darah kamu sekarat! (${user.health})*\nMinimal 50 HP buat nambang.\nBeli potion dulu ketik *${usedPrefix}shop potion 1*`);
    }

    const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

    const iron = rand(1, 5);
    const gold = rand(0, 2);          
    const diamond = rand(0, 1) > 0.8 ? 1 : 0; 
    const damage = rand(10, 30);
    const expDapat = rand(50, 200);   
    
    try {
        await incrementData('users', m.sender, 'health', -damage);
        await incrementData('users', m.sender, 'iron', iron);
        await incrementData('users', m.sender, 'gold', gold);
        await incrementData('users', m.sender, 'diamond', diamond);
        await incrementData('users', m.sender, 'exp', expDapat);

        cooldowns.set(m.sender, now);

        m.reply(`
⛏️ *HASIL MENAMBANG*

⛓️ Iron: +${iron}
🥇 Gold: +${gold}
💎 Diamond: +${diamond}
✨ Exp: +${expDapat}

❤️ Darah berkurang: -${damage}
`.trim());

    } catch (e) {
        console.error(e);
        m.reply('Gagal menyimpan hasil tambang ke database.');
    }
}

handler.command = ["mine", "nambang", "tambang"];
export default handler;

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s]
        .map(v => v.toString().padStart(2, "0"))
        .join(":");
}
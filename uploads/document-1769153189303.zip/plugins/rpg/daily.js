
const dailyCooldown = new Map();

const handler = async (m, { sock, getUser, incrementData, isBan }) => {
    try {
        if (isBan) return 
        const user = await getUser(m.sender);

        const cooldown = 86400000; // 24 Jam
        const now = Date.now();
        
        if (dailyCooldown.has(m.sender)) {
            const last = dailyCooldown.get(m.sender);
            const timer = cooldown - (now - last);
            
            if (timer > 0) {
                return m.reply(`⏳ Kamu sudah klaim hari ini.\nKembali lagi dalam: *${clockString(timer)}*`);
            }
        }

        const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

        const uang = rand(5000, 20000);   
        const exp = rand(2000, 8000);     
        const potion = rand(0, 3);
        const diamond = rand(0, 2);       
        
        const crate = Math.random() < 0.5 ? 1 : 0; 

        await incrementData('users', m.sender, 'balance', uang);
        await incrementData('users', m.sender, 'exp', exp);
        
        if (potion > 0) await incrementData('users', m.sender, 'potion', potion);
        if (diamond > 0) await incrementData('users', m.sender, 'diamond', diamond);
        if (crate > 0) await incrementData('users', m.sender, 'common_crate', crate);

        dailyCooldown.set(m.sender, now);

        const text = `🎁 *DAILY REWARD*
_Berhasil diklaim!_

💰 Balance: *+${uang}*
✨ Exp: *+${exp}*
🧪 Potion: *+${potion}*
💎 Diamond: *+${diamond}*
📦 Crate: *+${crate}*

_Jangan lupa klaim lagi besok ya!_ ✅
`.trim();

        await sock.sendMessage(m.chat, { text }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply("❌ Gagal menyimpan data daily.");
    }
}

handler.help = ["daily"];
handler.tags = ["rpg"];
handler.command = ["daily", "claim", "klaim"];

export default handler;

// ======================
function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, "0")).join(':');
}
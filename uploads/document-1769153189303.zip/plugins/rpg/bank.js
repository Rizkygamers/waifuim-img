
const handler = async (m, { args, command, usedPrefix, getUser, incrementData, isBan }) => {
    if (isBan) return 
    const user = await getUser(m.sender);

    const balance = user.balance || 0;
    const bank = user.bank || 0;

    if (command === 'bank' && !args[0]) {
        return m.reply(`
🏦 *BANK NUSANTARA*
👤 Nasabah: ${user.name}

💵 Dompet: ${balance.toLocaleString()}
💳 Bank: ${bank.toLocaleString()}

*Cara Transaksi:*
› ${usedPrefix}deposit <jumlah>
› ${usedPrefix}withdraw <jumlah>
        `.trim());
    }

    const total = Math.floor(isNumber(args[0]) ? Math.min(Math.max(parseInt(args[0]), 1), Number.MAX_SAFE_INTEGER) : 1) * 1;
    
    if (!args[0] || total < 1) return m.reply(`Masukan jumlah yang valid!\nContoh: *${usedPrefix + command} 1000*`);

    if (command === 'deposit' || command === 'depo') {
        if (balance < total) return m.reply(`💸 Uang di dompet kurang!\nPunya: ${balance}\nMau Depo: ${total}`);

        try {
            await incrementData('users', m.sender, 'balance', -total);
            await incrementData('users', m.sender, 'bank', total);
            
            m.reply(`Berhasil deposit *${total}* ke bank.`);
        } catch (e) {
            console.error(e);
            m.reply('Gagal transaksi database.');
        }
    }

    if (command === 'withdraw' || command === 'tarik') {
        if (bank < total) return m.reply(`💳 Saldo bank kurang!\nDi Bank: ${bank}\nMau Tarik: ${total}`);

        try {
            await incrementData('users', m.sender, 'bank', -total);
            await incrementData('users', m.sender, 'balance', total);
            
            m.reply(`Berhasil menarik *${total}* dari bank.`);
        } catch (e) {
            console.error(e);
            m.reply('Gagal transaksi database.');
        }
    }
}

handler.help = ['bank', 'deposit', 'withdraw'];
handler.tags = ['rpg'];
handler.command = ["bank", "deposit", "depo", "withdraw", "tarik"];

export default handler;

function isNumber(x) {
    return !isNaN(x);
}
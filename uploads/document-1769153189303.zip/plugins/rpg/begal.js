
let handler = async (m, { sock, reply, usedPrefix, command, getUser, incrementData, isBan }) => {
    if (isBan) return 
    let user = await getUser(m.sender, m.pushName);
    
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : false);
    if (!who) return reply(`Tag atau reply target yang mau dibegal!\nContoh: ${usedPrefix + command} @tag`);
    if (who === m.sender) return reply('Gak bisa begal diri sendiri.');

    // Cek data target
    let target = await getUser(who, "Target");
    if (target.balance < 1000) return reply('Target miskin, gak ada duit buat dibegal.');

    // Logic Begal (40% Sukses, 60% Gagal)
    let sukses = Math.random() < 0.4;

    if (sukses) {
        let dapat = Math.floor(Math.random() * 5000) + 1000; // Dapat 1k-6k
        if (dapat > target.balance) dapat = target.balance; // Max duit target

        await incrementData('users', who, 'balance', -dapat);
        await incrementData('users', m.sender, 'balance', dapat);
        
        reply(`🔫 *BEGAL SUKSES!*\n\nAnda berhasil merampok @${who.split('@')[0]}\n💰 Dapat: Rp ${dapat}`);
    } else {
        // Gagal = Denda atau Darah berkurang
        let denda = 2000;
        let dmg = 20;
        
        await incrementData('users', m.sender, 'balance', -denda);
        await incrementData('users', m.sender, 'health', -dmg);

        reply(`👮 *BEGAL GAGAL!*\n\nAnda ditangkap warga!\n💰 Denda: -Rp ${denda}\n🩸 Dipukuli: -${dmg} HP`);
    }
}

handler.command = ["rob", "begal", "maling"];
export default handler;
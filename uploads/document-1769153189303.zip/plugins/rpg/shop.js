const handler = async (m, { args, usedPrefix, command, getUser, incrementData, isBan }) => {
    if (isBan) return 
    const user = await getUser(m.sender);

    const listHarga = {
        potion: 1000,
        diamond: 5000,
        iron: 2000, 
        gold: 3000,
        common_crate: 10000
    };

    const itemInput = args[0] ? args[0].toLowerCase() : '';
    const jumlah = parseInt(args[1]) || 1;

    if (!itemInput || !listHarga[itemInput]) {
        return m.reply(`
🛒 *SHOP LIST*
Uangmu: ${user.balance}

💎 *Diamond*: 5000
🧪 *Potion*: 1000
⛓️ *Iron*: 2000
🪙 *Gold*: 3000
📦 *Common Crate*: 10000

*Cara Beli:*
${usedPrefix}shop <nama_item> <jumlah>
Contoh: *${usedPrefix}shop potion 5*
        `.trim());
    }

    const hargaPerItem = listHarga[itemInput];
    const totalHarga = hargaPerItem * jumlah;

    if (user.balance < totalHarga) {
        return m.reply(`💰 *Uang tidak cukup!*
Butuh: ${totalHarga}
Punya: ${user.balance}
Kurang: ${totalHarga - user.balance}`);
    }

    try {
        await incrementData('users', m.sender, 'balance', -totalHarga);
        
        await incrementData('users', m.sender, itemInput, jumlah);

        m.reply(`Sukses membeli *${jumlah} ${itemInput}* seharga *${totalHarga}*`);
    } catch (e) {
        console.error(e);
        m.reply('Terjadi kesalahan saat transaksi database.');
    }
}

handler.command = ["shop", "beli"];
export default handler;
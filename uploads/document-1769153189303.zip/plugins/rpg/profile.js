
const handler = async (m, { getUser, isBan }) => {
    if (isBan) return 
    const user = await getUser(m.sender, m.pushName);
    const text = `
📌 *PROFILE USER*

👤 *Info Dasar*
› Nama: ${user.name}
› Role: ${user.role}
› Level: ${user.level}
› Exp: ${user.exp}
› Limit: ${user.limit_val}/${user.premium ? '∞' : 20}

❤️ *Status Fisik*
› Health: ${user.health}
› Stamina: ${user.stamina}

💰 *Aset & Kekayaan*
› Balance: ${user.balance.toLocaleString()}
› Diamond: ${user.diamond}
› Gold: ${user.gold}

🎒 *Inventory RPG*
› Potion: ${user.potion}
› Iron: ${user.iron}
› Sword: ${user.sword}
› Common Crate: ${user.common_crate}
`.trim();

    m.reply(text);
}

handler.command = ["stats"];
export default handler;
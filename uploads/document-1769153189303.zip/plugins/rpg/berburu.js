
const huntCooldown = new Map();

const handler = async (m, { sock, usedPrefix, getUser, incrementData, isBan }) => {
    try {
        if (isBan) return 
        const user = await getUser(m.sender);

        const cooldownTime = 300000;
        const now = Date.now();

        if (huntCooldown.has(m.sender)) {
            const lastTime = huntCooldown.get(m.sender);
            const remaining = (lastTime + cooldownTime) - now;

            if (remaining > 0) {
                return m.reply(`⏳ Nafas dulu bang!\nBerburu lagi dalam: *${clockString(remaining)}*`);
            }
        }

        if (user.health < 50) {
            return m.reply(
                `❤️ *Darah Sekarat! (${user.health} HP)*\n` +
                `Minimal 50 HP buat lawan monster.\n\n` +
                `Beli potion dulu ketik:\n*${usedPrefix}shop potion 1*\n` +
                `Lalu pakai:\n*${usedPrefix}use potion 1*`
            );
        }

        const monsters = [
            "🐺 Serigala Hitam", "🐯 Harimau Api", "👹 Goblin Hijau", 
            "👺 Orc Besar", "🐉 Naga Mini", "🧟 Zombie", 
            "👻 Iblis Bayangan", "🐂 Minotaur"
        ];
        const monster = monsters[Math.floor(Math.random() * monsters.length)];
        
        const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

        const gagal = Math.random() < 0.15; 

        if (gagal) {
            const damage = rand(20, 50);
            
            await incrementData('users', m.sender, 'health', -damage);
            
            huntCooldown.set(m.sender, now);

            return m.reply(`❌ Sial! Kamu diserang balik oleh *${monster}*!\n❤️ Nyawa berkurang: *-${damage} HP*`);
        }

        const exp = rand(500, 4000);
        const money = rand(1000, 10000); 
        const damage = rand(10, 30);
        
        const diamond = rand(0, 1);
        const potion = rand(0, 1);
        const iron = rand(1, 5); 
        
        await incrementData('users', m.sender, 'health', -damage);
        await incrementData('users', m.sender, 'exp', exp);
        await incrementData('users', m.sender, 'balance', money);
        
        if (diamond > 0) await incrementData('users', m.sender, 'diamond', diamond);
        if (potion > 0) await incrementData('users', m.sender, 'potion', potion);
        if (iron > 0) await incrementData('users', m.sender, 'iron', iron);

        huntCooldown.set(m.sender, now);

        const hasil = `🎯 *HASIL BERBURU*
Lawan: *${monster}*

❤️ HP Berkurang: *-${damage}*
✨ Exp: *+${exp}*
💰 Uang: *+${money}*

🎁 *Loot Drop:*
💎 Diamond: *+${diamond}*
🧪 Potion: *+${potion}*
⛓️ Iron: *+${iron}*
`.trim();

        await m.reply(hasil);

    } catch (e) {
        console.error(e);
        m.reply("❌ Error fitur hunt (Database issue).");
    }
}

handler.help = ["hunt"];
handler.tags = ["rpg"];
handler.command = ["berburu", "buru", "hunt"];

export default handler;

// ======================
function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, "0")).join(':');
}
import fs from "fs"
import { exec } from "child_process"
import path from "path"
import { fileURLToPath } from "url"
import decode from "audio-decode" 

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

async function generateWaveform(buffer) {
  try {
    const audioBuffer = await decode(buffer)
    const rawData = audioBuffer.getChannelData(0) 
    const samples = 64 
    const blockSize = Math.floor(rawData.length / samples)
    const waveform = new Uint8Array(samples)

    for (let i = 0; i < samples; i++) {
      const start = i * blockSize
      const end = start + blockSize
      let max = 0

      for (let j = start; j < end; j++) {
        const val = Math.abs(rawData[j])
        if (val > max) max = val
      }

      waveform[i] = Math.min(255, Math.floor(max * 255))
    }
    return waveform
  } catch (e) {
    console.log("Gagal generate waveform:", e)
    return new Uint8Array(64).fill(0) 
  }
}

const handler = async (m, { sock, reply, example, isBan }) => {
  
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
  
  const quoted = m.quoted ? m.quoted : m
  const mime = (quoted.msg || quoted).mimetype || ""
  
  if (!/audio|video/.test(mime))
    return reply(example("reply ke video atau audio yang ingin dijadikan VN"))

  reply("Wait...")

  try {
    const mediaPath = await sock.downloadAndSaveMediaMessage(quoted)
    const outPath = path.join(__dirname, `temp_${Date.now()}.ogg`) 

    await new Promise((resolve, reject) => {
      exec(
        `ffmpeg -y -i "${mediaPath}" -vn -c:a libopus -b:a 64k -ac 1 -ar 48000 -map_metadata -1 "${outPath}"`,
        (err, stdout, stderr) => {
          if (err) return reject(err)
          resolve()
        }
      )
    })

    const fileBuffer = fs.readFileSync(outPath)

    const waveformArray = await generateWaveform(fileBuffer)

    await sock.sendMessage(
      m.chat,
      {
        audio: { url: outPath },
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
        waveform: waveformArray 
      },
      { quoted: m }
    )

    if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath)
    if (fs.existsSync(outPath)) fs.unlinkSync(outPath)
    
  } catch (err) {
    console.error(err)
    const mediaPath = await sock.downloadAndSaveMediaMessage(quoted).catch(() => null)
    if (mediaPath && fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath)
    
    reply("Gagal mengonversi ke VN.")
  }
}

handler.command = ["toptt", "tovn", "tovoicenote"]
export default handler
import axios  from 'axios'
import FormData  from 'form-data'

const handler = async (m, { sock, text, command, isBan }) => {

  try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
    
    if (!mime.startsWith('image/')) return m.reply('kirim juga gambar nya')

    m.reply('Wait...')

    const img = await q.download()
    const form = new FormData()
    form.append('image', img, 'image.jpg')
    form.append('scale', '2')

    const { data } = await axios.post('https://api2.pixelcut.app/image/upscale/v1', form, {
      headers: {
        ...form.getHeaders(),
        'accept': 'application/json',
        'x-client-version': 'web'
      }
    })

    await sock.sendMessage(m.chat, { 
      image: { url: data.result_url }, 
    }, { quoted: m })

  } catch (e) {
    m.reply(e.message)
  }
}


handler.command = ['hd', 'remini'];
export default handler;
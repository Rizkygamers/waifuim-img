import fs  from "fs"
import { exec }  from "child_process"
import path from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const handler = async (m, { sock, reply, example, isBan }) => {
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || "";
  if (!/video|audio/.test(mime)) return reply(example("reply ke video/audio yang ingin dijadikan MP3"));

  reply("Wait. . .");

  try {
    const mediaPath = await sock.downloadAndSaveMediaMessage(quoted);
    const outPath = path.join(__dirname, `temp_${Date.now()}.mp3`);

    await new Promise((resolve, reject) => {
      exec(`ffmpeg -i "${mediaPath}" -vn -ar 44100 -ac 2 -b:a 192k "${outPath}"`, (err) => {
        if (err) return reject(err);
        resolve();
      });
    });

    await sock.sendMessage(
      m.chat,
      {
        audio: { url: outPath },
        mimetype: "audio/mpeg",
        fileName: "audio.mp3",
      },
      { quoted: m }
    );
    fs.unlinkSync(mediaPath);
    fs.unlinkSync(outPath);
  } catch (err) {
    console.error(err);
    reply("❌ Gagal mengonversi video ke audio. Coba lagi nanti.");
  }
};

handler.command = ["tomp3", "toaudio"];
export default handler;
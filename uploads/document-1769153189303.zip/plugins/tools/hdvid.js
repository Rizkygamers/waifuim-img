import fs from "fs"
import { exec } from "child_process"

const handler = async (m, { sock, reply, quoted, text, usedPrefix, command, isBan }) => {
  try {
    if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    if (!/video/.test(mime)) return reply("Reply video yang ingin dijadikan HD!");

    let [res, fpsText] = text?.trim().toLowerCase().split(" ");
    let fps = 60;

    if (fpsText && fpsText.endsWith("fps")) {
      fps = parseInt(fpsText.replace("fps", ""));
      if (isNaN(fps) || fps < 30 || fps > 240) return reply("❗FPS antara 30 - 240 (contoh: 60fps)");
    }

    const resolutions = {
      "480": "480",
      "720": "720",
      "1080": "1080",
      "2k": "1440",
      "4k": "2160",
    };

    if (!resolutions[res]) {
      return reply(`Contoh: ${usedPrefix + command} 720\n${usedPrefix + command} 1080 60fps`);
    }

    const targetHeight = resolutions[res];
    const id = m.sender.split("@")[0];
    const input = `temp_input_${id}.mp4`;
    const output = `temp_hd_${id}.mp4`;

    reply(`Convert video to *${res.toUpperCase()} ${fps}FPS*`);

    const downloaded = await sock.downloadAndSaveMediaMessage(q, input);

    exec(
      `ffmpeg -i "${downloaded}" -vf "scale=-2:${targetHeight},fps=${fps}" -preset veryfast -b:v 3M -c:a copy "${output}"`,
      async (err) => {
        if (err) {
          console.error(err);
          reply("❌ Terjadi kesalahan saat proses video!");
          fs.unlinkSync(downloaded);
          return;
        }

        const buffer = fs.readFileSync(output);
        await sock.sendMessage(
          m.chat,
          { video: buffer, caption: `Video HD ${res.toUpperCase()} ${fps}FPS` },
          { quoted: m }
        );

        fs.unlinkSync(downloaded);
        fs.unlinkSync(output);
      }
    );
  } catch (e) {
    console.error(e);
    reply("❌ Error tidak diketahui.");
  }
};

handler.command = ["hdvid", "hdvideo"];
export default handler;
import axios from "axios"

const handler = async (m, { sock, args, reply, usedPrefix, command }) => {
  if (!m.quoted || !m.quoted.text) {
    return reply(
      `Ex: ${usedPrefix}${command} id (reply txt nya)`
    )
  }

  const target = args[0] || "id"
  const text = m.quoted.text

  try {
    
    const api = `https://api.deline.web.id/tools/translate?text=${encodeURIComponent(text)}&target=${encodeURIComponent(target)}`
    const res = await axios.get(api)
    const json = res.data

    if (!json.status || !json.data?.hasil_terjemahan) {
      return reply("❌ Gagal menerjemahkan teks")
    }

    const { terdeteksi_bahasa, ke_bahasa, hasil_terjemahan } = json.data

    await reply(
`${hasil_terjemahan}`
    )

  } catch (err) {
    console.error("Translate Error:", err)
    reply("⚠️ Terjadi error saat translate")
  }
}

handler.command = ["tr", "translate"]

export default handler
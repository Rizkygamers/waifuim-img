import axios from "axios"
import FormData from 'form-data'
import crypto from 'crypto'

const handler = async (m, { sock, text, command, isBan }) => {
    try {
        if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        const q = m.quoted ? m.quoted : m
        const mime = (q.msg || q).mimetype || ''
        if (!mime.startsWith('image/')) return m.reply('Mana gambarnya')
        m.reply('Wait...')
        const img = await q.download()

        const serial = crypto.randomBytes(16).toString('hex')
        const fname = `Image_${crypto.randomBytes(6).toString('hex')}.jpg`
        const form = new FormData()
        form.append('original_image_file', img, { filename: fname, contentType: 'image/jpeg' })
        form.append('scale_factor', 2)
        form.append('upscale_type', 'image-upscale')
        const headers = { ...form.getHeaders(), 'product-serial': serial }

        let res = await axios.post('https://api.unblurimage.ai/api/imgupscaler/v2/ai-image-unblur/create-job', form, { headers })
        let jobId = res.data?.result?.job_id

        let output, done = false
        const timeout = Date.now() + 180000
        while (!done && Date.now() < timeout) {
            let poll = await axios.get(`https://api.unblurimage.ai/api/imgupscaler/v2/ai-image-unblur/get-job/${jobId}`, { headers })
            if (poll.data.code === 100000 && poll.data.result?.output_url?.[0]) {
                output = poll.data.result.output_url[0]
                done = true
            } else {
                await new Promise(r => setTimeout(r, 3000))
            }
        }

        await sock.sendMessage(m.chat, { image: { url: output }, caption: "Nih kak hasilnya 👀"}, { quoted: m })
    } catch (e) {
        m.reply(e.message)
    }
}

handler.command = ["unblur", "unblr"]
export default handler;
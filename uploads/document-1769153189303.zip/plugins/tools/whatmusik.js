import axios from 'axios'
import FormData from 'form-data'
async function aha_music(buffer) {
  const form = new FormData()
  form.append('file', buffer, {
    filename: 'audio.mp3',
    contentType: 'audio/mp3'
  })
  form.append('sample_size', 118784)
  const { data } = await axios.post(
    'https://api.doreso.com/humming',
    form,
    {
      headers: {
        ...form.getHeaders(),
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
        accept: 'application/json, text/plain, */*',
        origin: 'https://www.aha-music.com',
        referer: 'https://www.aha-music.com/'
      },
      maxBodyLength: Infinity,
      maxContentLength: Infinity
    }
  )
  return data
}
let handler = async (m, { sock, isBan, usedPrefix, command }) => {
  try {
    if (isBan) return m.reply("lu di ban")
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
    if (!mime.startsWith('audio/')) return m.reply(`Ex: ${usedPrefix+command} dengan reply audio nya`)
    await m.reply("Wait. . .")
    const buffer = await q.download()
    const res = await aha_music(buffer)
    await m.reply(`*This is the results:*

🎧 ${res.data.title} - ${res.data.artists}`)
  } catch (e) {
    m.reply(e.message)
  }
}

handler.command = ["whatmusic", "whatmusik", "wms"]
export default handler
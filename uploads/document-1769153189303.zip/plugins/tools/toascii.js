import fetch from "node-fetch"
import FormData from "form-data"

const handler = async (m, { sock, reply, usedPrefix }) => {
  try {

    let msg = m.quoted && /image/.test(m.quoted.mimetype)
      ? m.quoted
      : /image/.test(m.mimetype)
      ? m
      : null

    if (!msg)
      return reply(`Kirim atau reply gambar dengan caption *${usedPrefix}toascii*`)

    const buffer = await msg.download()
    const form = new FormData()
    form.append("files[]", buffer, "image.jpg")

    const upload = await fetch("https://uguu.se/upload.php", {
      method: "POST",
      body: form
    })

    const up = await upload.json()
    if (!up.files?.[0]?.url) throw "Upload ke uguu gagal"

    const imageUrl = up.files[0].url

    const api = `https://asci.whyux-xec.my.id/api/art?image=${encodeURIComponent(imageUrl)}`
    const res = await fetch(api)
    const json = await res.json()

    if (!json.result) throw "Gagal convert ASCII"

    const txtBuffer = Buffer.from(json.result, "utf-8")

    await sock.sendMessage(
      m.chat,
      {
        document: txtBuffer,
        mimetype: "text/plain",
        fileName: "ascii-art.txt",
        caption: "Succes convert image to ascii"
      },
      { quoted: m }
    )

  } catch (err) {
    console.error(err)
    reply("Terjadi error saat convert gambar ke ASCII")
  }
}

handler.command = ["toascii", "ascii"]
export default handler
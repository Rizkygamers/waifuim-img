/* 
sumber: https://whatsapp.com/channel/0029Vb4fjWE1yT25R7epR110
*/

import { Videy } from "@zanixongroup/uploader";
import path from 'path';

let handler = async (m, { sock, text, usedPrefix, command, isBan, mime }) => {
  const q = m.quoted ? m.quoted : m;
  if (isBan) return 
  if (/^video/.test(mime) || /video\/(mp4|avi|mkv|mov|webm|flv)/.test(mime)) {
    m.reply('Wait...');
    
    try {
      const video = await q.download();

      let ext = path.extname(q.filename || '').slice(1);
      
      if (!ext && mime) {
        const mimeMap = {
          'video/mp4': 'mp4',
          'video/webm': 'webm',
          'video/avi': 'avi',
          'video/x-matroska': 'mkv',
          'video/quicktime': 'mov',
          'video/x-flv': 'flv'
        };
        ext = mimeMap[mime] || 'mp4';
      }
      
      const videyUrl = await Videy(video);
      
      if (!videyUrl) {
        throw new Error('Upload ke Videy gagal!');
      }
      
      await sock.sendMessage(m.chat, {
        text: `*Video Upload Berhasil!*

- Url: ${videyUrl}
- Platfrom: Videy
- Format: ${ext.toUpperCase()}`,
      }, { quoted: m });
      
    } catch (e) {
      console.error('Error:', e);
      m.reply('🚨 Error: ' + (e.message || e));
    }
  } else {
    m.reply(`*Example:* 
› *${usedPrefix + command}* reply video
    
*Format support:*
› mp4, webm, avi, mkv, mov, flv`);
  }
}

handler.command = ['tovidey', 'upvidey'];
export default handler;
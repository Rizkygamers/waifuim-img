// TOURL ALL SERVERS 
// t.me/jarroffc2

import fs from "fs"
import axios from "axios"
import fetch from "node-fetch"
import FormData from "form-data"
import crypto from "crypto"
import { fileTypeFromBuffer } from "file-type"

// === KONFIGURASI GITHUB ===
const githubToken = "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"
const owner = "jarroffc"
const branch = "main"
let repos = ["dat1", "dat2", "dat3", "dat4"]

async function ensureRepoExists(repo) {
  try {
    await axios.get(`https://api.github.com/repos/${owner}/${repo}`, {
      headers: { Authorization: `Bearer ${githubToken}` },
    })
  } catch (e) {
    if (e.response?.status === 404) {
      await axios.post(
        `https://api.github.com/user/repos`,
        { name: repo, private: false },
        { headers: { Authorization: `Bearer ${githubToken}` } }
      )
      if (!repos.includes(repo)) repos.push(repo)
    } else throw e
  }
}

function generateRepoName() {
  return `dat-${crypto.randomBytes(3).toString("hex")}`
}

async function uploadGitHub(buffer, originalName = "file") {
  const detected = await fileTypeFromBuffer(buffer)
  const ext = detected?.ext || (originalName.split(".").pop() || "bin")
  const code = crypto.randomBytes(3).toString("hex")
  const fileName = `${code}-${Date.now()}.${ext}`
  const filePathGitHub = `uploads/${fileName}`
  const base64Content = Buffer.from(buffer).toString("base64")

  let targetRepo = repos[Math.floor(Math.random() * repos.length)]
  try {
    await ensureRepoExists(targetRepo)
  } catch {
    targetRepo = generateRepoName()
    await ensureRepoExists(targetRepo)
  }

  await axios.put(
    `https://api.github.com/repos/${owner}/${targetRepo}/contents/${filePathGitHub}`,
    { message: `Upload file ${fileName}`, content: base64Content, branch },
    { headers: { Authorization: `Bearer ${githubToken}` } }
  )

  return `https://raw.githubusercontent.com/${owner}/${targetRepo}/${branch}/${filePathGitHub}`
}

// === CATBOX UPLOADER ===
async function uploadCatbox(buffer) {
  const typeInfo = await fileTypeFromBuffer(buffer)
  const ext = typeInfo?.ext || "bin"
  const form = new FormData()
  form.append("fileToUpload", buffer, "file." + ext)
  form.append("reqtype", "fileupload")

  const res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: form,
  })
  return (await res.text()).trim()
}

// === LUNARA UPLOADER ===
async function uploadLunara(buffer) {
  const typeInfo = await fileTypeFromBuffer(buffer)
  const ext = typeInfo?.ext || "bin"
  const fileName = `upload_${Date.now()}.${ext}`

  fs.writeFileSync(fileName, buffer)
  const form = new FormData()
  form.append("file", fs.createReadStream(fileName))
  form.append("expire_value", "24")
  form.append("expire_unit", "hours")

  const res = await axios.post("https://lunara.drizznesiasite.biz.id/upload", form, {
    headers: form.getHeaders(),
  })

  fs.unlinkSync(fileName)
  return res?.data?.file_url || null
}

// === NAUVAL.CLOUD UPLOADER ===
async function uploadNauvalCloud(buffer) {
  const typeInfo = await fileTypeFromBuffer(buffer)
  const ext = typeInfo?.ext || "bin"
  const fileName = `upload_${Date.now()}.${ext}`

  fs.writeFileSync(fileName, buffer)
  const form = new FormData()
  form.append("file", fs.createReadStream(fileName))
  form.append("expire_value", "24")
  form.append("expire_unit", "hours")

  const res = await axios.post("https://nauval.cloud/upload", form, { headers: form.getHeaders() })

  fs.unlinkSync(fileName)
  return res?.data?.file_url || null
}

// === PIXHOST UPLOADER ===
async function uploadPixhost(buffer) {
  const typeInfo = await fileTypeFromBuffer(buffer)
  const ext = typeInfo?.ext || "jpg"
  const form = new FormData()
  form.append("img", buffer, "upload." + ext)
  form.append("content_type", "0")

  const res = await fetch("https://api.pixhost.to/images", {
    method: "POST",
    body: form,
  })

  const json = await res.json().catch(() => ({}))
  if (!json || !json.show_url) throw new Error("Gagal upload ke Pixhost.")
  return json.show_url
}

// === YUPRA CDN UPLOADER ===
async function uploadYupra(buffer, filename) {
  const form = new FormData()
  form.append("files", buffer, { filename })

  const response = await axios.post("https://cdn.yupra.my.id/upload", form, {
    headers: {
      ...form.getHeaders(),
      "User-Agent": "Mozilla/5.0",
    },
    timeout: 120000,
  })

  if (response.data.success && response.data.files?.[0]) {
    return "https://cdn.yupra.my.id" + response.data.files[0].url
  }
  throw new Error("Upload ke Yupra gagal.")
}

// === TMPFILES UPLOADER ===
async function uploadTmpfiles(buffer, filename) {
  const form = new FormData()
  form.append("file", buffer, filename)
  const res = await fetch("https://tmpfiles.org/api/v1/upload", { method: "POST", body: form })
  const json = await res.json().catch(() => null)
  if (!json?.data?.url) throw new Error("Gagal upload ke tmpfiles.org")
  return json.data.url
}

// === UGUU.SE UPLOADER ===
async function uploadUguu(buffer, filename) {
  const form = new FormData()
  form.append("files[]", buffer, filename)
  const res = await fetch("https://uguu.se/upload.php", { method: "POST", body: form })
  const json = await res.json()
  return json.files?.[0]?.url || null
}

// === NEKOHIME CDN UPLOADER ===
async function uploadNekohime(buffer, filename = "upload.jpg") {
  const filePath = `./${filename}`
  fs.writeFileSync(filePath, buffer)
  const formData = new FormData()
  formData.append("file", fs.createReadStream(filePath))
  const response = await axios.post("https://cdn.nekohime.site/upload", formData, {
    headers: formData.getHeaders(),
  })
  fs.unlinkSync(filePath)
  return response.data.files
}

// === HANDLER UTAMA ===
const handler = async (m, { sock, text, isBan, usedPrefix }) => {
  if (isBan)
    return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } })

  const args = text.trim().split(" ")
  const choice = parseInt(args[0])
  if (![1, 2, 3, 4, 5, 6, 7, 8, 9].includes(choice))
    return m.reply(
      `*Pilih server upload:*
      
1. Upload to (catbox.moe)
2. Upload to (lunara.drizznesiasite.biz.id)
3. Upload to (github.com)
4. Upload to (pixhost.to) // Hanya gambar
5. Upload to (cdn.yupra.my.id)
6. Upload to (tmpfiles.org)
7. Upload to (uguu.se)
8. Upload to (nauval.cloud)
9. Upload to (cdn.nekohime.site)

Contoh:
${usedPrefix}tourl 1 balas foto/video/file`
    )

  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ""
  if (!/image|video|audio|application/.test(mime))
    return m.reply("Balas media yang ingin diupload (foto, video, audio, dokumen).")

  const buffer = await q.download?.()
  if (!buffer) return m.reply("Gagal mengunduh media.")
  if (buffer.length > 20 * 1024 * 1024) return m.reply("❌ File terlalu besar (maks 20MB).")

  let url, platform
  try {
    m.reply("Sbr...")

    const ext = (await fileTypeFromBuffer(buffer))?.ext || mime.split("/")[1] || "bin"
    const filename = `file_${Date.now()}.${ext}`

    if (choice === 1) { url = await uploadCatbox(buffer); platform = "Catbox.moe" }
    else if (choice === 2) { url = await uploadLunara(buffer); platform = "Lunara" }
    else if (choice === 3) { url = await uploadGitHub(buffer, filename); platform = "GitHub" }
    else if (choice === 4) {
      if (!/image/.test(mime)) return m.reply("Pixhost hanya mendukung gambar.")
      url = await uploadPixhost(buffer); platform = "Pixhost.to"
    } else if (choice === 5) { url = await uploadYupra(buffer, filename); platform = "Yupra CDN" }
    else if (choice === 6) { url = await uploadTmpfiles(buffer, filename); platform = "Tmpfiles.org" }
    else if (choice === 7) { url = await uploadUguu(buffer, filename); platform = "Uguu.se" }
    else if (choice === 8) { url = await uploadNauvalCloud(buffer); platform = "Nauval.cloud" }
    else if (choice === 9) { url = await uploadNekohime(buffer, filename); platform = "Nekohime CDN" }

    // 🔧 Fix universal url format (kalau array/object)
    if (Array.isArray(url)) url = url[0]
    if (url && typeof url === "object" && url.url) url = url.url

    if (!url || typeof url !== "string" || !url.startsWith("http"))
      throw new Error("Gagal mendapatkan URL upload")

    const type =
      /image/.test(mime) ? "Foto"
      : /video/.test(mime) ? "Video"
      : /audio/.test(mime) ? "Audio"
      : "File"

    await sock.sendMessage(
      m.chat,
      {
        text: `*Upload Berhasil 🤙*
        
- *Uploaded :* ${type}
- *To Server :* ${platform}
- *URL:* ${url}`,
      },
      { quoted: m }
    )
  } catch (err) {
    console.error("Upload Error:", err)
    await m.reply("❌ Gagal upload: " + err.message)
  }
}

handler.command = ["tourl"]
handler.help = ["tourl"]
handler.tags = ["tools"]

export default handler
let handler = async (m, { sock, isBan, isOwner, reply, text, qtxt }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner) return m.reply(mess.owner)
  if (!text) return m.reply(example("barang yang dipesan"))

  let teks = `*Pesanan dalam proses 🙏*\n
- Item dipesan : ${text}
- Hari/tanggal : ${global.tanggal(Date.now())}

> 📦 - mohon tunggu dan jangan spam!`

  await sock.sendMessage(m.chat, {
    text: teks,
    mentions: [m.sender, global.owner + "@s.whatsapp.net"],
    contextInfo: {
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idChannel,
        newsletterName: `Testimoni - ${global.namaOwner}`,
        serverId: 200
      },
      externalAdReply: {
        title: `Pending . . . 🕒`,
        body: ``,
        thumbnailUrl: global.fotoStore,
        renderLargerThumbnail: false,
        mediaType: 1,
        sourceUrl: ""
      }
    }
  }, { quoted: qtxt })
}

handler.command = ["proses"]

export default handler
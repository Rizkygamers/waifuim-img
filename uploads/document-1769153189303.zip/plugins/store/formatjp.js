let handler = async (m, { sock, isBan, reply }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })

  reply(`*Format Japost - ${namaOwner} 👀*

- Barang :
- Harga :
- Spesifikasi :
- Nomor : wa.me/628

⚠️ Wajib menggunakan Rekber *${namaOwner}* agar terhindar dari scamer/penipuan!
`)
}


handler.command = ["formatjp"]

export default handler
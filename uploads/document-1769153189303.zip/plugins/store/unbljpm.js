// plugins/jpm/unbl.js
import fs from "fs"

const handler = async (m, { sock, isOwner, text, reply }) => {
  if (m.isBan) return sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner) return reply(mess.owner)

  const path = './data/setbot.json'
  const set = JSON.parse(fs.readFileSync(path))
  set.blacklist = set.blacklist || []

  if (!set.blacklist.length) return reply("*Tidak ada grup dalam daftar blacklist.*")

  let target
  if (!text && m.isGroup) target = m.chat
  else if (text) {
    const input = text.trim()
    if (/^\d+$/.test(input)) {
      const index = parseInt(input)
      if (index < 1 || index > set.blacklist.length) return reply("Nomor list tidak valid!\n\n*.listbl* untuk melihat nomor list")
      target = set.blacklist[index - 1]
    } else {
      target = input
    }
  }

  if (!target) return reply(example("nomor list-nya\nKetik *.listbl* untuk lihat nomor list\n\n*Atau langsung ketik di grup yang di blacklist*"))

  if (!set.blacklist.includes(target)) return reply("Grup / ID tersebut tidak ada di daftar blacklist.")

  set.blacklist = set.blacklist.filter(id => id !== target)
  fs.writeFileSync(path, JSON.stringify(set, null, 2))

  const allGroups = await sock.groupFetchAllParticipating()
  const name = allGroups[target]?.subject || "Tidak ditemukan / sudah keluar"
  return reply(`Grup *${name}* berhasil dihapus dari blacklist.`)
}

handler.command = ['unbl','delbl']
export default handler
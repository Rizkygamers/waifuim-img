let handler = async (m, { sock, isBan, isOwner, reply, text, qtxt }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner) return m.reply(mess.owner)
  if (!text) return m.reply(example("produk yang dipesan"))

  let teks = `*Transaksi Berhasil ✅*\n
- Item pemesanan: ${text}
- Status pesanan: Selesai 
- Hari/tanggal: ${global.tanggal(Date.now())}

> 🌟 - trimakasih telah mempercayai kami`

  await sock.sendMessage(m.chat, {
    text: teks,
    contextInfo: {
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idChannel,
        newsletterName: `Testimoni - ${global.namaOwner}`,
        serverId: 200
      },
      externalAdReply: {
        title: `Nota Pemesanan 📄`,
        body: ``,
        thumbnailUrl: global.fotoStore,
        renderLargerThumbnail: false,
        mediaType: 1,
        sourceUrl: ""
      }
    }
  }, { quoted: qtxt })
}

handler.help = ["done"]
handler.tags = ["store"]
handler.command = ["done"]

export default handler
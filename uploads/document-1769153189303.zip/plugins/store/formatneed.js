let handler = async (m, { sock, isBan, reply, text, qtxt }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })

  reply(`*Format Cari - ${namaOwner} 🔎*

- Yang Dicari :
- Harga :
- Spesifikasi :
- Nomor : wa.me/628

⚠️ Wajib menggunakan Rekber *${namaOwner}* agar terhindar dari scamer/penipuan!
`)
}

handler.command = ["formatneed"]

export default handler
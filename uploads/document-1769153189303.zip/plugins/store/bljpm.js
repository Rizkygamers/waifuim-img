// plugins/jpm/blacklist.js
import fs from "fs"

const handler = async (m, { sock, isOwner, reply }) => {
  if (m.isBan) return sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!m.isGroup) return reply(mess.group)
  if (!isOwner) return reply(mess.owner)

  const path = './data/setbot.json'
  const set = JSON.parse(fs.readFileSync(path))
  set.blacklist = set.blacklist || []

  if (!set.blacklist.includes(m.chat)) {
    set.blacklist.push(m.chat)
    fs.writeFileSync(path, JSON.stringify(set, null, 2))
    return reply("Group berhasil di blacklist ✅")
  } else {
    return reply("Group ini sudah ada di blacklist!")
  }
}

handler.command = ['blacklist','bljpm','bl']
export default handler
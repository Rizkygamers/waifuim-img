import fs from "fs"
import { CatBox } from "../../control/uploader.js"

let handler = async (m, { sock, isBan, isOwner, isSewa, reply, text, list, example, isCmd }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner && !isSewa) return reply(mess.vip)
  if (!m.isGroup) return reply(mess.group)

  let quoted = m.quoted || m.msg?.quoted
  let teksCmd = text

  if (!teksCmd && m.message?.imageMessage?.caption) teksCmd = m.message.imageMessage.caption
  if (!teksCmd && quoted?.message?.imageMessage?.caption) teksCmd = quoted.message.imageMessage.caption

  if (!teksCmd || !teksCmd.includes("|"))
    return m.reply(example("cmd|responnya (bisa reply/kirim gambar)"))

  let [cmd, respon] = teksCmd.split("|")
  cmd = cmd.toLowerCase()
  const chatId = m.chat

  let cek = list.find(e => e.chatId === chatId && e.cmd === cmd)
  if (cek) return m.reply("Cmd respon sudah ada di grup ini")

  let imgUrl = false

  if (quoted && /image/.test(quoted.mtype)) {
    try {
      let mediaPath = await sock.downloadAndSaveMediaMessage(quoted)
      let link = await CatBox(mediaPath)
      if (link && link.startsWith("https://")) imgUrl = link
      fs.unlinkSync(mediaPath)
    } catch (e) {
      console.log(e)
    }
  }

  let obj = { chatId, cmd, respon, img: imgUrl }
  list.push(obj)
  fs.writeFileSync("./data/list.json", JSON.stringify(list, null, 2))

  m.reply(`Berhasil menambah respon *${cmd}* di grup ini`)
}

handler.command = ["addlist"]
export default handler
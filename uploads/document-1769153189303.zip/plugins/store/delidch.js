import fs from "fs";

const handler = async (m, { sock, isOwner, text, reply, isBan, usedPrefix }) => {
  if (isBan) return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  if (!isOwner) return reply(mess.owner);

  const db = "./data/listidch.json";
  let listidch = JSON.parse(fs.readFileSync(db));

  if (!listidch.length) return reply("*Tidak ada ID channel di database.*");

  if (!text) {
    const sections = [
      {
        title: "🗑️ Pilih Channel untuk Dihapus",
        rows: listidch.map((id, i) => ({
          title: `Channel ${i + 1}`,
          rowId: `${usedPrefix}delidch ${id}`,
          description: id,
        })),
      },
    ];

    return sock.sendMessage(
      m.chat,
      {
        text: "*📋 Daftar ID Channel*",
        footer: `Total: ${listidch.length}`,
        buttonText: "Klik",
        sections,
      },
      { quoted: m }
    );
  }

  const input = text.trim();

  if (input.toLowerCase() === "all") {
    listidch = [];
    fs.writeFileSync(db, JSON.stringify([], null, 2));
    return reply("Berhasil menghapus semua ID!");
  }

  if (!input.endsWith("@newsletter")) return reply("❌ Format ID tidak valid.");
  if (!listidch.includes(input)) return reply("❌ ID tidak ada di database!");

  listidch = listidch.filter((x) => x !== input);
  fs.writeFileSync(db, JSON.stringify(listidch, null, 2));

  reply(`Berhasil menghapus ID channel:\n*${input}*`);
};

handler.command = ['delidch','delch'];
export default handler;
// plugins/jpm/stopjpm.js
import fs from "fs"

const handler = async (m, { sock, isOwner, reply }) => {
  if (m.isBan) return sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner) return reply(mess.owner)
  if (!global.statusjpm) return reply("Jpm sedang tidak berjalan!")
  global.stopjpm = true
  return reply("Berhasil menghentikan jpm ✅")
}

handler.command = ['stopjpm']
export default handler
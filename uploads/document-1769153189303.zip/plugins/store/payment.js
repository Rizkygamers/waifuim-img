const handler = async (m, { sock, isBan }) => {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
const teksPayment = `Payment By *${global.namaOwner}* 🍟

* *Dana :* ${global.dana}
* *Ovo :* ${global.ovo}
* *Gopay :* ${global.gopay}

*⚠️ Sertakan bukti transfer valid sesuai nominal yang di sepakati!*
`
return sock.sendMessage(m.chat, {image: {url: global.qris}, caption: teksPayment}, {quoted: m})
}
handler.command = [
 "payment","pay"
] 
export default handler;
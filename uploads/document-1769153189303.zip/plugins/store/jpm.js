// plugins/jpm/jpm.js
import fs from "fs"

const handler = async (m, { sock, isOwner, text, qmsg, qtxt, mime, reply }) => {
  if (m.isBan) return sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner) return reply(mess.owner)
  if (!text && !/image/.test(mime)) return reply(example('teks & foto (opsional)'))

  const set = JSON.parse(fs.readFileSync('./data/setbot.json'))
  set.blacklist = set.blacklist || []

  let mediaPath
  if (/image/.test(mime)) mediaPath = await sock.downloadAndSaveMediaMessage(qmsg)

  const allGroups = await sock.groupFetchAllParticipating()
  const groupIds = Object.keys(allGroups)
  let successCount = 0

  const messageContent = mediaPath
    ? { image: fs.readFileSync(mediaPath), caption: text }
    : { text }

  const senderChat = m.chat
  await reply(`*Memproses Broadcast ⚡*\n- 💬 Type Jpm : ${mediaPath ? "teks & foto" : "teks saja"}\n- 🍀 Total Grup : ${groupIds.length} grup\n- 🚫 Blacklist : ${set.blacklist.length} grup\n- 🕒 Jeda JPM : ${global.JedaJpm / 1000} detik\n\n*Info ⚠️* \n> Ketik *.stopjpm* untuk menghentikan proses kirim.`)

  global.statusjpm = true
  for (const groupId of groupIds) {
    if (global.stopjpm) {
      delete global.stopjpm
      break
    }

    if (set.blacklist.includes(groupId)) continue

    try {
      await sock.sendMessage(groupId, messageContent, { quoted: qtxt })
      successCount++
    } catch (err) {
      console.error(`Gagal kirim ke ${groupId}:`, err)
    }

    await sleep(global.JedaJpm)
  }

  if (mediaPath && fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath)
  delete global.statusjpm

  await sock.sendMessage(senderChat, {
    text: `*Selesai Broadcast 🌟*\n\n- 💬 Type : ${mediaPath ? "teks & foto" : "teks saja"}\n- ✅ Sukses : ${successCount} grup\n- 🚫 Dilewati (blacklist) : ${set.blacklist.length} grup\n- 🕒 Jeda : ${global.JedaJpm / 1000} detik`
  }, { quoted: m })
}

handler.command = ['jpm','jaser']
export default handler
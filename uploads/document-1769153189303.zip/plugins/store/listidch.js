import fs from "fs";

const handler = async (m, { sock, isOwner, reply, isBan }) => {
  if (isBan) return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  if (!isOwner) return reply(mess.owner);

  const listidch = JSON.parse(fs.readFileSync("./data/listidch.json"));

  if (!listidch.length) return reply("*Tidak ada ID channel yang tersimpan.*");

  let teks = `*List ID Channel*\n> Total: ${listidch.length} channel\n\n`;
  listidch.forEach((id, i) => (teks += `${i + 1}. ${id}\n`));
  teks += `\nKetik *.delidch* untuk menghapus ID`;

  return reply(teks);
};

handler.command = ['listidch','listch'];
export default handler;
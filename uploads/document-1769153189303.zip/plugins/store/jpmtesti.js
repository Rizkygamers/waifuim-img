// plugins/jpm/jpmtesti.js
import fs from "fs"

const handler = async (m, { sock, isOwner, text, qmsg, qtxt, mime, reply }) => {
  if (m.isBan) return sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner) return reply(mess.owner)
  if (!text && !/image/.test(mime)) return reply(example('teks & foto (opsional)'))
  if (global.statusjpm) return reply("Jpm sedang berjalan, gunakan *.stopjpm* dulu untuk menghentikan.")

  global.statusjpm = true
  global.stopjpm = false

  const set = JSON.parse(fs.readFileSync('./data/setbot.json'))
  set.blacklist = set.blacklist || []

  let mediaPath
  const qmsgUse = qmsg || m
  const mimeType = (qmsgUse.msg || qmsgUse).mimetype || ""
  if (/image/.test(mimeType)) mediaPath = await sock.downloadAndSaveMediaMessage(qmsgUse)

  const allGroups = await sock.groupFetchAllParticipating()
  const groupIds = Object.keys(allGroups)
  let successCount = 0
  const senderChat = m.chat

  await reply(`*Memproses Broadcast Testimoni ⚡*\n- 💬 Type JPM : ${mediaPath ? "teks & foto" : "teks saja"} \n- 🍀 Total Grup : ${groupIds.length} grup + Saluran\n- 🚫 Blacklist : ${set.blacklist.length} grup\n- 🕒 Jeda JPM : ${global.JedaJpm / 1000} detik\n\n*Info ⚠️*\n> Ketik *.stopjpm* untuk menghentikan proses kirim.`)

  try {
    const messageContent = mediaPath
      ? { image: fs.readFileSync(mediaPath), caption: text }
      : { text }
    // Kirim ke saluran utama testimoni
    await sock.sendMessage(global.idChannel, messageContent)
  } catch (err) {
    console.error("Gagal mengirim ke channel:", err)
  }

  const groupMessage = mediaPath
    ? { image: fs.readFileSync(mediaPath), caption: text }
    : { text }

  for (const groupId of groupIds) {
    if (global.stopjpm) {
      delete global.statusjpm
      delete global.stopjpm
      break
    }

    if (set.blacklist.includes(groupId)) continue

    try {
      await sock.sendMessage(groupId, {
        ...groupMessage,
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender],
          forwardedNewsletterMessageInfo: {
            newsletterJid: global.idChannel,
            newsletterName: `Testimoni - ${global.namaOwner}`
          }
        }
      }, { quoted: qtxt })
      successCount++
    } catch (err) {
      console.error(`Gagal kirim ke ${groupId}:`, err)
    }

    await sleep(global.JedaJpm)
  }

  if (mediaPath && fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath)
  delete global.statusjpm
  delete global.stopjpm

  await sock.sendMessage(senderChat, {
    text: `*Selesai Broadcast Testimoni 🌟*\n\n- 💬 Type : ${mediaPath ? "teks & foto" : "teks saja"}\n- ✅ Sukses : ${successCount} grup + Saluran\n- 🚫 Dilewati (blacklist) : ${set.blacklist.length} grup\n- 🕒 Jeda : ${global.JedaJpm / 1000} detik`
  }, { quoted: m })
}

handler.command = ['jpmtesti','testi','uptesti']
export default handler
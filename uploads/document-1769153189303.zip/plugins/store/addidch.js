import fs from "fs";

const handler = async (m, { sock, isOwner, text, reply, isBan, usedPrefix }) => {
  if (isBan) return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  if (!isOwner) return reply(mess.owner);

  const db = "./data/listidch.json";
  const listidch = JSON.parse(fs.readFileSync(db));

  const input = text ? text.trim() : m.chat;

  if (!input.endsWith("@newsletter"))
    return reply(`Format salah!\n*${usedPrefix}addidch id@newsletter*\natau ketik langsung di saluran.`);

  if (listidch.includes(input)) return reply("ID tersebut sudah ada di database.");

  listidch.push(input);
  fs.writeFileSync(db, JSON.stringify(listidch, null, 2));

  reply(`Berhasil menambahkan ID:\n*${input}*`);
};

handler.command = ['addidch','addch'];
export default handler;
let handler = async (m, { sock, isBan, isOwner, isSewa, reply, list }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner && !isSewa) return reply(mess.vip)
  if (!m.isGroup) return reply(mess.group)

  const chatId = m.chat
  const data = list.filter(e => e.chatId === chatId)
  if (!data.length) return m.reply("Tidak ada cmd respon di grup ini")

  let teks = "*List key response grup ini:*\n"
  data.forEach((e, i) => {
    teks += `\n${i + 1}. *${e.cmd}* ${e.img ? "(📷)" : ""}`
  })

  m.reply(teks)
}


handler.command = ["getlist"]

export default handler
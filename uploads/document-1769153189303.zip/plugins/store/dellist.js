import fs from "fs"

let handler = async (m, { sock, isBan, isOwner, isSewa, reply, text, list, example }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  
  if (!isOwner && !isSewa) return reply(mess.vip)
  if (!m.isGroup) return reply(mess.group)
  if (!text) return m.reply(example("cmd\n\nketik *.getlist* untuk melihat semua cmd"))

  const chatId = m.chat
  const cmd = text.toLowerCase()
  const index = list.findIndex(e => e.chatId === chatId && e.cmd === cmd)

  if (index === -1) return m.reply(`Cmd *${cmd}* tidak ditemukan di grup ini`)

  list.splice(index, 1)
  fs.writeFileSync("./data/list.json", JSON.stringify(list, null, 2))
  m.reply(`Berhasil menghapus cmd respon *${cmd}* dari grup ini`)
}

handler.command = ["dellist"]

export default handler
import fs from "fs";

const handler = async (m, { sock, text, isOwner, mime, qmsg, reply, isBan }) => {
  if (isBan) return sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  if (!isOwner) return reply(mess.owner);

  const listidch = JSON.parse(fs.readFileSync("./data/listidch.json"));
  if (!listidch.length) return reply("Tidak ada ID channel.");

  if (!text && !/image/.test(mime)) return reply(example("Kirim teks atau foto."));

  let mediaPath;
  if (/image/.test(mime)) mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);

  const content = mediaPath
    ? { image: fs.readFileSync(mediaPath), caption: text }
    : { text };

  let success = 0;

  await reply(`Memulai broadcast ke ${listidch.length} channel...`);

  for (const id of listidch) {
    try {
      await sock.sendMessage(id, content);
      success++;
    } catch {}
    await sleep(global.JedaJpm);
  }

  if (mediaPath && fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath);

  reply(`Selesai broadcast.\nBerhasil: ${success} / ${listidch.length}`);
};

handler.command = ['jpmch','jpmallch'];
export default handler;
// plugins/jpm/listbl.js
import fs from "fs"

const handler = async (m, { sock, isOwner, reply }) => {
  if (m.isBan) return sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!isOwner) return reply(mess.owner)

  const path = './data/setbot.json'
  const set = JSON.parse(fs.readFileSync(path))
  set.blacklist = set.blacklist || []

  if (!set.blacklist.length) return reply("*Tidak ada grup yang masuk blacklist Jpm*.")

  const allGroups = await sock.groupFetchAllParticipating()
  let teks = `*Grup di Blacklist 💬*\n> Total diblacklist *${set.blacklist.length}* grup\n\n`
  set.blacklist.forEach((id, i) => {
    const name = allGroups[id]?.subject || "Tidak ditemukan / sudah keluar"
    teks += `${i + 1}. *${name}*\n   ID: ${id}\n\n`
  })
  teks += `Ketik *.unbl* nomor nya\nUntuk hapus *blacklist!*`
  reply(teks)
}

handler.command = ['listbl','listbljpm']
export default handler
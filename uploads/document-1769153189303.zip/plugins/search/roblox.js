import axios from 'axios'
import FormData from 'form-data'

const handler = async (m, { sock, isOwner, text, command, reply, owners, example, isSewa, isBan }) => {
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 
  if (!text) return reply(example("username nya mana??"));
  m.reply("Sabar . . .");

  try {
    const apiUrl = `https://api.zenzxz.my.id/api/stalker/roblox?user=${encodeURIComponent(text)}`;
    const res = await axios.get(apiUrl);

    if (!res.data?.success || !res.data?.data || Object.keys(res.data.data).length === 0) {
      return reply(`Username *${text}* tidak terdaftar di Roblox.`);
    }

    const data = res.data.data;
    const basic = data.basic || {};
    const social = data.social || {};
    const presence = data.presence?.userPresences?.[0] || {};

    const headshot = data.avatar?.headshot?.data?.[0]?.imageUrl || null;
    const fullBody = data.avatar?.fullBody?.data?.[0]?.imageUrl || null;

    const created = basic.created
      ? new Date(basic.created).toLocaleDateString("id-ID", {
          year: "numeric", month: "long", day: "numeric"
        })
      : "-";

    let teks = `*Roblox Profile Stalker 🎮*\n\n`;
    teks += `- 👤 *Username:* ${basic.name || "-"}\n`;
    teks += `- 🪪 *Display Name:* ${basic.displayName || "-"}\n`;
    teks += `- 🆔 *User ID:* ${data.userId || "-"}\n`;
    teks += `- 📝 *Description:* ${basic.description || "-"}\n`;
    teks += `- 📅 *Created:* ${created}\n`;
    teks += `- 🚫 *Banned:* ${basic.isBanned ? "Yes" : "No"}\n`;
    teks += `- 📍 *Status:* ${data.status || "-"}\n`;
    teks += `- 🌐 *Last Seen:* ${presence.lastLocation || "Unknown"}\n\n`;

    teks += `*Social Stats 👥*\n`;
    teks += `- Friends: ${social.friends?.count || 0}\n`;
    teks += `- Followers: ${social.followers?.count || 0}\n`;
    teks += `- Following: ${social.following?.count || 0}\n\n`;

    const groups = data.groups?.list?.data?.slice(0, 3) || [];
    if (groups.length > 0) {
      teks += `🏢 *Top Groups:*\n`;
      groups.forEach((g, i) => {
        teks += `${i + 1}. ${g.group.name} (${g.role.name})\n`;
      });
      teks += `\n📦 Total Groups: ${data.groups?.list?.data?.length || 0}`;
    }

    await sock.sendMessage(
      m.chat,
      {
        image: { url: fullBody || headshot },
        caption: teks.trim()
      },
      { quoted: m }
    );
  } catch (err) {
    console.error("Error Roblox:", err);
    reply("❌ Gagal mengambil data Roblox: " + err.message);
  }
}

handler.command = ["roblox", "rbx"]
export default handler;
const handler = async (m, { sock, text, command, reply, example, isSewa, isOwner, isBan }) => {
  try {
    if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    if (!text) return m.reply(example(`username YouTube nya (pakai @username)`));

    let api = await fetch(`https://api.zenzxz.my.id/stalker/youtube?username=${encodeURIComponent(text)}`);
    let res = await api.json();

    if (!res.success) throw '*❌ Gagal mengambil data dari API YouTube*';

    let ch = res.data.channel;
    let videos = res.data.latest_videos || [];

    let caption = `*YouTube Stalker 🔴*

🎬 Channel: ${ch.username || '-'}
📛 Subscribers: ${ch.subscriberCount ?? '-'}
🎥 Total Videos: ${ch.videoCount ?? '-'}
📝 Description: ${ch.description || '-'}
🔗 Channel URL: ${ch.channelUrl || '-'}

━━━━━━━━━━━━━━━
🎞️ *5 Video Terbaru:*
${videos.length
      ? videos.slice(0, 5).map((v, i) => `
${i + 1}. *${v.title || '-'}*
📅 ${v.publishedTime || '-'}
👁️ ${v.viewCount || '-'}
⏱️ ${v.duration || '-'}
🔗 ${v.videoUrl || '-'}
`).join('\n')
      : 'Tidak ada video terbaru'}
━━━━━━━━━━━━━━━`;

    await sock.sendMessage(m.chat, {
      image: { url: ch.avatarUrl },
      caption
    }, { quoted: m });

  } catch (error) {
    console.error(error);
    m.reply('❌ Terjadi kesalahan: ' + error);
  } finally {
    // Hapus react loading
    await sock.sendMessage(m.chat, { react: { text: '', key: m.key } });
  }
};

handler.command = ["ytstalk", "yts2"];
export default handler;
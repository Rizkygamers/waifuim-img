import axios from "axios"

const client_id = "acc6302297e040aeb6e4ac1fbdfd62c3";
const client_secret = "0e8439a1280a43aba9a5bc0a16f3f009";
const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");
const TOKEN_ENDPOINT = "https://accounts.spotify.com/api/token";

async function spotifyCreds() {
    try {
        const response = await axios.post(
            TOKEN_ENDPOINT,
            "grant_type=client_credentials",
            {
                headers: {
                    Authorization: "Basic " + basic,
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            }
        );
        return {
            status: true,
            data: response.data,
        };
    } catch {
        return {
            status: false,
            msg: "Failed to retrieve Spotify credentials.",
        };
    }
}

const toTime = (ms) => {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map((v) => v.toString().padStart(2, "0")).join(":");
};

class Spotify {
    async search(query, type = "track", limit = 10) {
        try {
            const creds = await spotifyCreds();
            if (!creds.status) return creds;

            const response = await axios.get(
                `https://api.spotify.com/v1/search?query=${encodeURIComponent(query)}&type=${type}&limit=${limit}`,
                {
                    headers: {
                        Authorization: "Bearer " + creds.data.access_token,
                    },
                }
            );

            const list = response.data[type + "s"].items;
            if (!list.length) return { msg: "Music not found!" };

            return list.map((item) => ({
                title: item.name,
                id: item.id,
                duration: toTime(item.duration_ms),
                artist: item.artists.map((a) => a.name).join(" & "),
                url: item.external_urls.spotify,
                cover: item.album.images?.[0]?.url || "",
            }));
        } catch (e) {
            return { status: false, msg: "Error searching Spotify: " + e.message };
        }
    }

    async download(url) {
        const BASEURL = "https://api.fabdl.com";
        const headers = {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "User-Agent":
                "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
        };

        try {
            const { data: info } = await axios.get(`${BASEURL}/spotify/get?url=${url}`, { headers });
            const { gid, id, name, image, duration_ms } = info.result;

            const { data: dl } = await axios.get(`${BASEURL}/spotify/mp3-convert-task/${gid}/${id}`, { headers });

            if (dl.result.download_url) {
                return {
                    title: name,
                    duration: toTime(duration_ms),
                    cover: image,
                    download: `${BASEURL}${dl.result.download_url}`,
                };
            }
        } catch (e) {
            throw new Error("Error downloading Spotify track: " + e.message);
        }
    }
}

const SpotifyScrape = new Spotify();

const handler = async (m, { sock, text, reply, example, isOwner, isSewa, isBan }) => {
    try {
        if (isBan) return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        if (!isOwner && !isSewa) return reply(mess.vip);
        if (!text) return reply(example("Masukkan judul lagu Spotify."));

        reply("Wait...");

        const data = await SpotifyScrape.search(text);
        if (!Array.isArray(data) || data.length === 0) return reply("⚠️ Lagu tidak ditemukan.");

        const song = data[0];
        const { title, artist, duration, url, cover } = song;

        const caption = `*Spotify Result 🎧*\n\n` +
            `- 🎵 *Judul:* ${title}\n` +
            `- 👨‍🎤 *Artis:* ${artist}\n` +
            `- ⏱ *Durasi:* ${duration}\n` +
            `- 🔗 *Link:* ${url}\n\n` +
            `> _Audio sedang di kirim_`;

        await sock.sendMessage(m.chat, {
            image: { url: cover },
            caption,
        }, { quoted: m });

        const dl = await SpotifyScrape.download(url);

        if (!dl?.download) return reply("⚠️ Gagal mengambil link download.");

        await sock.sendMessage(m.chat, {
            audio: { url: dl.download },
            mimetype: "audio/mpeg",
            fileName: `${title}.mp3`,
            caption: `${title} - ${artist}`,
        }, { quoted: m });

    } catch (err) {
        console.error("Error Spotify:", err.message);
        reply("⚠️ Terjadi kesalahan saat mencari atau mengunduh lagu.");
    }
};

handler.command = ["playspotify", "spotifysearch", "spp"];
export default handler;
import fetch from "node-fetch";

let handler = async (m, { sock, text, reply, command, usedPrefix, isBan }) => {
  if (isBan) return 
  if (!text) return reply(`Ex: ${usedPrefix + command} judul lagu`);

  try {
    const api = await fetch(
      `https://api.elrayyxml.web.id/api/search/applemusic?q=${encodeURIComponent(text)}`
    );

    if (!api.ok) return reply(`API Error ${api.status}`);

    const json = await api.json();

    if (!json.status || !json.result?.length)
      return reply("Tidak ada hasil!");

    let list = `🎵 *Apple Music Search*\nQuery: *${text}*\n\n`;

    json.result.slice(0, 10).forEach((v, i) => {
      list += `*${i + 1}. ${v.title}*\n${v.subtitle}\n🔗 ${v.link}\n\n`;
    });

    // kirim foto pertama
    await sock.sendMessage(
      m.chat,
      {
        image: { url: json.result[0].image },
        caption: list.trim()
      },
      { quoted: m }
    );
  } catch (e) {
    console.error(e);
    reply("❌ Terjadi error.");
  }
};

handler.command = ["apples", "sapple", "applesearch", "aples"];
export default handler;
import axios from "axios"

const handler = async (m, { sock, isBan, isOwner, isSewa, text, reply, example }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!text) return m.reply(example("mau cari apa??"))
  m.reply("Wait...")

  try {
    const { data } = await axios.get(
      `https://api.jarroffc.my.id/search/bstation?apikey=jarroffc&q=${encodeURIComponent(text)}`
    )

    if (!data.result || data.result.length === 0)
      return m.reply("Tidak ada hasil ditemukan.")

    let teks = `*BStation Search Results 👀*\n\n`
    data.result.slice(0, 5).forEach((v, i) => {
      teks += `*${i + 1}.* ${v.title}\n`
      teks += `📺 *Uploader:* ${v.uploader}\n`
      teks += `⏱ *Durasi:* ${v.duration}\n`
      teks += `👁 *Views:* ${v.views}\n`
      teks += `🔗 *Link:* ${v.url}\n\n`
    })
    let thumb = data.result[0].thumbnail

    await sock.sendMessage(
      m.chat,
      {
        image: { url: thumb },
        caption: teks.trim(),
      },
      { quoted: m }
    )
  } catch (err) {
    console.error(err)
    m.reply("❌ Terjadi kesalahan: " + err.message)
  }
}

handler.command = ["bili", "bstation","bs"]

export default handler
// plugins/ffstalk.js
import axios from "axios";

const handler = async (m, { sock, text, command, reply, usedPrefix, isBan }) => {
  try {
    if (isBan) return reply ("lu di ban")
    if (!text) return reply(`Ex: ${usedPrefix}${command} 2775229425`);
    reply ("wait. . .")
    const url = `https://api.deline.web.id/stalker/stalkff?id=${text}`;
    const { data } = await axios.get(url);

    if (!data?.status) return reply("Gagal mengambil data FF!");

    const res = data.result;

    let cap = `*Free Fire Stalker*

- 🆔 *Player ID:* ${res.player_id}
- 👤 *Nickname:* ${res.nickname}
- 🎮 *Game:* ${res.game}
- 📡 *Status:* ${res.status}`;

    await sock.sendMessage(
      m.chat,
      { text: cap },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    reply("Error bang, mungkin ID nya salah!");
  }
};

handler.command = ["ffstalk"]
export default handler;
const handler = async (m, { sock, text, command, reply, example, args, isSewa, isOwner, isBan }) => {
  try {
if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner && !isSewa) return reply(mess.vip)
    reply("Wait...")

    if (!text) return m.reply(example(`username github nya`))

    const apiUrl = `https://www.velyn.mom/api/stalker/github?apikey=jarroffc&username=${encodeURIComponent(text)}`
    const response = await fetch(apiUrl)
    const res = await response.json()

    if (res.status !== 200 || !res.data) throw '*Gagal mengambil data dari API*'

    const user = res.data
    const caption = `*GitHub Stalker Profile 🔍*

- 👤 Username: ${user.username || 'Tidak diketahui'}
- 📛 Nickname: ${user.nickname || 'Tidak diketahui'}
- 🏢 Company: ${user.company || '-'}
- 🌍 Location: ${user.location || '-'}
- 📬 Email: ${user.email || '-'}
- 📦 Public Repos: ${user.public_repo || 0}
- 📜 Public Gists: ${user.public_gists || 0}
- 👥 Followers: ${user.followers || 0}
- 🫂 Following: ${user.following || 0}
- 🏷️ Type: ${user.type || 'User'}
- 🛠️ Admin: ${user.admin ? 'Yes' : 'No'}
- 🕒 Dibuat: ${new Date(user.created_at).toLocaleString('id-ID')}
- 🔄 Diperbarui: ${new Date(user.updated_at).toLocaleString('id-ID')}
- 🔗 Profile: ${user.url}

> Jarr Multi Device 👀`

    await sock.sendMessage(m.chat, {
      image: { url: user.profile_pic },
      caption
    }, { quoted: m })

  } catch (error) {
    console.error(error)
    m.reply('❌ Error: ' + (error.message || error))
  } finally {
    await sock.sendMessage(m.chat, { react: { text: '', key: m.key } })
  }
}

handler.command = ["gitstalk", "githubstalk","git"]
export default handler;
// plugins/mlstalk.js
import axios from "axios";

const handler = async (m, { sock, text, command, reply, usedPrefix, isBan }) => {
  try {
    if (isBan) return reply ("lu di ban")
    if (!text) return reply(`Ex: ${usedPrefix}${command} id|zone id
Cht: ${usedPrefix}${command} 1343331387|15397`);
    reply("Wait. . .")
    const [id, zone] = text.split("|");
    if (!id || !zone) return reply(`Ex: ${usedPrefix}${command} id|zone id
Cht: ${usedPrefix}${command} 1343331387|15397`);

    const url = `https://api.deline.web.id/stalker/stalkml?id=${id}&zone=${zone}`;
    const { data } = await axios.get(url);

    if (!data?.status || !data?.result?.success)
      return reply("Gagal mengambil data ML!");

    const res = data.result;

    let cap = `*Mobile Legends Stalker*

- 🆔 *ID:* ${id}
- 🌐 *Zone:* ${zone}
- 👤 *Username:* ${res.username}
- 📍 *Region:* ${res.region}`;

    await sock.sendMessage(
      m.chat,
      { text: cap },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    reply("Error bang, cek ID & Zone nya!");
  }
};

handler.command = ["mlstalk"]
export default handler;
/**
fitur 
https://whatsapp.com/channel/0029Vb6ru1s2Jl87BaI4RJ1H

scrape 
https://whatsapp.com/channel/0029VbAeMWdHFxP73goAZ23x/332
**/
import axios from "axios";
import * as cheerio from "cheerio";

let handler = async (m, { sock, text, usedPrefix, command, isBan }) => {

  if (isBan) return 
  if (!text) {
    return m.reply(`mau cari apa bang?`);
  }
  m.reply("Wait...")
  const results = await sfileSearch(text);
  if (!results.length)
    return m.reply("Tidak ditemukan hasil untuk keyword itu");

  let msg = results
    .map(
      (item) =>
        `*${item.title}*
- Info: ${item.info}
- Uploader: ${item.uploader || "-"}
- Uploaded on: ${item.uploadDate || "-"}
- Size: ${item.size || "-"}
- Link: ${item.link}`
    )
    .join("\n\n");

  m.reply(msg);
};

handler.help = handler.command = ["sfilesearch", "sfs"];
export default handler;

async function sfileSearch(query) {
  try {
    const { data: html } = await axios.get(
      `https://sfile.mobi/search.php?q=${encodeURIComponent(query)}`,
      { headers: { "User-Agent": "Mozilla/5.0" } }
    );

    const $ = cheerio.load(html);
    let results = [];

    $(".list").each((_, el) => {
      const a = $(el).find("a").first();
      const link = a.attr("href");
      if (!link) return;

      results.push({
        title: a.text().trim(),
        info: $(el).find(".file-info").text().trim(),
        link,
      });
    });

    results = results.sort(() => Math.random() - 0.5).slice(0, 15);

    const output = [];
    for (const item of results) {
      const detail = await getFileDetail(item.link);
      output.push({
        title: item.title,
        info: item.info,
        uploader: detail.uploader,
        uploadDate: detail.uploadDate,
        size: detail.size,
        link: item.link,
      });
    }

    return output;
  } catch {
    return [];
  }
}

async function getFileDetail(url) {
  try {
    const { data: html } = await axios.get(url, {
      headers: { "User-Agent": "Mozilla/5.0" },
    });

    const $ = cheerio.load(html);

    const uploader = $('a[href*="/user/"]').first().text().trim() || null;
    const uploadDate = $('span:contains("Uploaded:") span').text().trim() || null;
    const size = html.match(/with size\s([^.]*)\./i)?.[1] || null;

    return { uploader, uploadDate, size };
  } catch {
    return { uploader: null, uploadDate: null, size: null };
  }
}
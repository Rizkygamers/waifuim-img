import axios from "axios"

const handler = async (m, { sock, isBan, isOwner, isSewa, text, reply, example }) => {

  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!text) return m.reply(example("mw cari apa ?"))
  m.reply("Wait. . .")

  try {
    const { data } = await axios.get(
      `https://api.jarroffc.my.id/search/playstore?apikey=jarroffc&q=${encodeURIComponent(text)}`
    )

    if (!data.result || data.result.length === 0) {
      return m.reply("❌ Aplikasi tidak ditemukan.")
    }

    let hasil = data.result
      .slice(0, 5)
      .map((v, i) => {
        return `📱 *${i + 1}. ${v.nama || "No name"}*\n👤 Developer: ${v.developer || "Tidak diketahui"}\n⭐ Rating: ${v.rate2 || v.rate || "No rating"}\n🔗 Link: ${v.link}\n🔗 Developer: ${v.link_dev}`
      })
      .join("\n\n")

    let caption = `*Playstore Search Result 📲*\n\n${hasil}`

    await sock.sendMessage(
      m.chat,
      {
        image: { url: data.result[0].img || "https://files.catbox.moe/dklg5y.jpg" },
        caption: caption,
      },
      { quoted: m }
    )
  } catch (err) {
    console.error(err)
    m.reply("❌ Terjadi kesalahan: " + err.message)
  }
}

handler.command = ["playstore", "ps"]

export default handler
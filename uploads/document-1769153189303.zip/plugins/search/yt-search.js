import yts from "yt-search"

function toRupiah(num) {
  return Intl.NumberFormat("id-ID", { notation: "compact" }).format(num);
}

const handler = async (m, { sock, isBan, isOwner, isSewa, text, reply, example }) => {
  if (isBan) return sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  if (!text) return m.reply(example("apa yang mau dicari?"))

  m.reply("Wait...")

  let data = await yts(text)
  if (!data.all || data.all.length === 0) 
    return m.reply("❌ Result tidak ditemukan!")

  // Batasi 5 hasil saja biar nggak over panjang
  let list = data.all.slice(0, 5)

  let teks = "*🔎 YouTube Search Results*\n\n"

  for (let res of list) {
    teks += `- 🎬 *${res.title}*\n`
    teks += `- ⏳ Durasi: ${res.timestamp}\n`
    teks += `- 📅 Upload: ${res.ago}\n`
    teks += `- 👀 Views: ${toRupiah(res.views)}\n`
    teks += `- 👤 Channel: ${res.author?.name || '-'}\n`
    teks += `- 🔗 Link: ${res.url}\n\n`
  }

  await m.reply(teks)
}

handler.command = ["yts"]

export default handler

import axios from "axios";

const handler = async (m, { sock, text, command, reply, usedPrefix, isBan }) => {
  try {
    if (isBan) return reply("lu di ban")
    if (!text) return reply(`Ex: ${usedPrefix}${command} username ny`);
    reply ("Wait...")
    const url = `https://api.deline.web.id/stalker/ttstalk?username=${text}`;
    const { data } = await axios.get(url);

    if (!data?.status) return reply("Gagal mengambil data!");

    const user = data.result.user;
    const stats = data.result.stats;

    let cap = `*🐣 TikTok Stalker Result*
- *Username:* ${user.uniqueId}
- *Nickname:* ${user.nickname}
- *Region:* ${user.region}
- *Akun dibuat:* ${new Date(user.createTime * 1000).toLocaleDateString()}
- *Verified:* ${user.verified ? "Yes" : "No"}
- *Private:* ${user.privateAccount ? "Yes" : "No"}

*💌 Other information*
- *Stats*
- Followers: ${stats.followerCount}
- Following: ${stats.followingCount}
- Likes: ${stats.heartCount}
- Video: ${stats.videoCount}`;

    await sock.sendMessage(m.chat, {
      image: { url: user.avatarLarger },
      caption: cap
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    reply("Error bang, cek username nya!");
  }
};

handler.command = ["ttstalker", "ttstalk", "stt"]
export default handler;
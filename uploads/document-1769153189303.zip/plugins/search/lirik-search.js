import axios from "axios";

const handler = async (m, { sock, text, reply, example, isBan }) => {
  try {
    if (isBan) return m.reply("Kamu diblokir!");

    if (!text) return reply(example("judul lagu nya?"));

    m.reply("Wait...");

    const apiUrl = `https://chocomilk.amira.us.kg/v1/search/lyrics?query=${encodeURIComponent(text)}`;
    const res = await axios.get(apiUrl);

    if (!res.data?.success || !res.data?.data || !res.data.data.lyrics?.length)
      return m.reply(`⚠️ Lirik untuk "${text}" tidak ditemukan.`);

    const song = res.data.data;
    const lyricsText = song.lyrics.join("\n");

    let caption = `🎵 *${song.title}*\n`;
    caption += `👤 *Artist:* ${song.artist || "-"}\n`;
    caption += `💽 *Album:* ${song.album || "-"}\n`;
    caption += `⏱️ *Duration:* ${song.duration ? song.duration + "s" : "-"}\n\n`;
    caption += `${lyricsText}`;

    reply(caption);

  } catch (err) {
    console.error("Error Lirik:", err.message);
    reply("⚠️ Gagal mengambil lirik. Coba kata kunci lain.");
  }
};

handler.command = ["lirik", "lr"];
export default handler;
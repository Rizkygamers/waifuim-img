const handler = async (m, { sock, text, command, reply, example, isBan }) => {
    try {
        if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        if (!text) return m.reply(example(`Masukkan username Instagram`));

        // Memanggil API
        let api = await fetch(`https://api.zenzxz.my.id/stalker/instagram?username=${encodeURIComponent(text)}`);
        let res = await api.json();

        if (!res.success) throw '*❌ Gagal mengambil data*';

        let data = res.data; // Sesuai struktur JSON baru
        let caption = `*Instagram Stalker Profile 🔎* 

- *✨ Username:* ${data.username || 'Tidak diketahui'}
- *📛 Name:* ${data.name || 'Tidak diketahui'}
- *📝 Bio:* ${data.bio || 'Tidak ada bio'}
- *👥 Followers:* ${data.followers ?? 0}
- *🫂 Following:* ${data.following ?? 0}
- *📮 Posts:* ${data.posts ?? 0}
- *✅ Verified:* ${data.verified ? 'Yes' : 'No'}
- *📊 Engagement Rate:* ${data.engagement_rate ?? 0}%`;

    await sock.sendMessage(m.chat, {
    image: { url: data.profile_pic },
    caption: caption
}, { quoted: m });

    } catch (error) {
        console.error(error);
        m.reply('*❌ Terjadi kesalahan: ' + error + '*');
    } finally {
        // Menghapus react "⏳"
        await sock.sendMessage(m.chat, { react: { text: '', key: m.key } });
    }
};

handler.command = ["igstalk", "igs"];
export default handler;
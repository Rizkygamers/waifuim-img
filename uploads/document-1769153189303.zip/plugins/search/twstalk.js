// plugins/twstalk.js
import axios from "axios";

const handler = async (m, { sock, text, command, reply, usedPrefix, isBan }) => {
  try {
    if (isBan) return reply ("lu di ban")
    if (!text) return reply(`Example: ${usedPrefix}${command} juicee90y`);
    reply ("Wait. . .")
    const url = `https://api.deline.web.id/stalker/twitter?username=${text}`;
    const { data } = await axios.get(url);

    if (!data?.status) return reply("Gagal mengambil data Twitter!");

    const u = data.result;

    let cap = `🐦 *Twitter Stalker Result*

- *Name:* ${u.core.name}
- *Username:* @${u.core.screen_name}
- *Rest ID:* ${u.rest_id}
- *Created At:* ${u.core.created_at}
- *Verified:* ${u.verification.verified ? "Yes" : "No"}
- *Private:* ${u.privacy.protected ? "Yes" : "No"}

📊 *Other Information*
- Followers: ${u.legacy.followers_count}
- Following: ${u.legacy.friends_count}
- Favorites: ${u.legacy.favourites_count}
- Tweets: ${u.legacy.statuses_count}
- Media: ${u.legacy.media_count}
- *Location:* ${u.location?.location || "-"}
`;

    await sock.sendMessage(
      m.chat,
      {
        image: { url: u.avatar.image_url },
        caption: cap
      },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    reply("Error bang, cek username nya!");
  }
};

handler.command = ["twstalk", "tws"]
export default handler;
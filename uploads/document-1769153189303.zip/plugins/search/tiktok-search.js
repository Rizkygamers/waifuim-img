import fetch from "node-fetch"

const handler = async (m, { sock, text, command, reply, example, isSewa, isOwner, isBan }) => {
  try {
    if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    if (!isOwner && !isSewa) return reply(mess.vip);
    if (!text) return m.reply(example("mw cari apa?"));

    m.reply("Wait...");

    const api = await fetch(`https://api.nekolabs.my.id/discovery/tiktok/search?q=${encodeURIComponent(text)}`);
    const res = await api.json();

    if (!res.success || !res.result || res.result.length === 0)
      return m.reply("⚠️ Tidak ditemukan video dengan kata kunci tersebut.");

    const video = res.result[0];

    const caption = `*TikTok search results 🐾*
> Next untuk melihat lainnya`;

    await sock.sendMessage(m.chat, {
      video: { url: video.videoUrl },
      caption,
      footer: `© ${namaBot} 2025`,
      buttons: [
        {
          buttonId: `.tts ${text}`,
          buttonText: { displayText: "Next" },
          type: 1,
        },
      ],
      headerType: 1,
    }, { quoted: m });

  } catch (error) {
    console.error("❌ Error TikTok Search:", error);
    await m.reply("⚠️ Gagal mengambil data TikTok. Coba lagi nanti.");
  }
};

handler.command = ["tts", "ttsearch", "tiks"];
export default handler;
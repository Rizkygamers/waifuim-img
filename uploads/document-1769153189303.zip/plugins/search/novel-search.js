import axios from "axios";

const handler = async (m, { sock, text, reply, command, isBan, usedPrefix }) => {
  try {
    if (isBan) return 
    if (!text) 
      return reply(`Ex : *${usedPrefix}novel judul nya*`);

    await reply("Wait...");

    const url = `https://chocomilk.amira.us.kg/v1/novel/search?query=${encodeURIComponent(text)}`;

    const { data } = await axios.get(url);

    if (!data || !data.success || !data.data || !data.data.items)
      return reply("⚠️ Tidak ada hasil ditemukan.");

    const list = data.data.items.slice(0, 10); // ambil 10 teratas

    let teks = `📚 *Hasil pencarian novel*: *${text}*\n\n`;

    list.forEach((v, i) => {
      teks += `*${i + 1}. ${v.title}*\n`;
      teks += `🆔 ID: ${v.novelId}\n`;
      teks += `⭐ Score: ${v.score}\n`;
      teks += `👁️ Views: ${v.totalViews}\n`;
      teks += `📄 Chapters: ${v.totalChapters}\n`;
      teks += `📚 Genre: ${v.genres.join(", ")}\n`;
      teks += `🏷️ Tags: ${v.tags.join(", ")}\n`;
      teks += `🖼️ Cover: ${v.cover.url}\n`;
      teks += `📘 Status: ${v.novelStatusDesc}\n`;
      teks += `────────────────\n`;
    });

    await sock.sendMessage(m.chat, { text: teks }, { quoted: m });

  } catch (err) {
    console.error(err);
    reply("❌ Terjadi kesalahan: " + err.message);
  }
};

handler.command = ["novel", "nv"];
export default handler;
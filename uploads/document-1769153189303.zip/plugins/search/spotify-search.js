import fetch from "node-fetch";

if (!global.spotifySearch) global.spotifySearch = {};

const handler = async (m, { text, usedPrefix, command, isBan }) => {

  if (isBan) return m.reply("lu di ban paok");
  if (!text) return m.reply(`Ex: ${usedPrefix + command} nama lagu`);
  await m.reply("Wait. . .")
  try {
    const API = `https://ytdlpyton.nvlgroup.my.id/spotify/search?query=${encodeURIComponent(text)}`;

    const res = await fetch(API, {
      method: "GET",
      headers: {
        "accept": "application/json",
        "X-API-Key": "jarr"
      }
    });

    if (!res.ok) throw await res.text();
    const json = await res.json();

    if (!json.results || json.results.length === 0)
      return m.reply("Tidak ditemukan hasil pencarian.");

    global.spotifySearch[m.sender] = json.results;

    let msg = `🎧 *Spotify Search Results*\n`;
    msg += `Download musik?\n- Ex : *${usedPrefix}spotify nomor*\n\n`;
    json.results.forEach((v, i) => {
      msg += `*${i + 1}. ${v.title}*\n`;
      msg += `Artist: ${v.artist}\n`;
      msg += `URL: ${v.spotify_url}\n`;
    });
    
    m.reply(msg);

  } catch (e) {
    console.error(e);
    return m.reply("❌ Error pencarian.\n" + e);
  }
};

handler.command = ["spos", "spotifysearch", "sposearch", "spotifys"];
export default handler;
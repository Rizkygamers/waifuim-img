import axios from "axios"

const Func = {
  ago(dateString) {
    const date = new Date(dateString)
    const now = new Date()
    const diff = Math.floor((now - date) / 1000)

    if (diff < 60) return `${diff}s lalu`
    if (diff < 3600) return `${Math.floor(diff / 60)}m lalu`
    if (diff < 86400) return `${Math.floor(diff / 3600)}j lalu`
    if (diff < 2592000) return `${Math.floor(diff / 86400)}h lalu`
    return date.toLocaleDateString()
  },

  h2k(num) {
    if (num >= 1e6) return (num / 1e6).toFixed(1) + "M"
    if (num >= 1e3) return (num / 1e3).toFixed(1) + "K"
    return num.toString()
  }
}

const handler = async (m, { sock, text, reply, isBan }) => {
  if (isBan) return await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
  if (!text) return reply("*masukkan nama package yang ingin dicari*")

  try {
    const res = await axios.get(
      `https://registry.npmjs.com/-/v1/search?text=${encodeURIComponent(text)}`
    )

    const data = res.data
    if (!data.objects || data.objects.length === 0)
      return reply("*Package tidak ditemukan. Coba kata kunci lain atau periksa kembali nama package-nya!*")

    let cap = "*Hasil Pencarian NPMJS - Package Info*\n\n"

    for (let i of data.objects.slice(0, 10)) {
      const pkg = i.package
      cap += `- 🔹 *Nama Package:* ${pkg.name}@^${pkg.version}\n`
      cap += pkg.publisher ? `- 👤 *Pembuat:* ${pkg.publisher.username}\n` : ""
      cap += `- 🕒 *Diperbarui:* ${Func?.ago ? Func.ago(pkg.date) : pkg.date}\n`

      if (pkg.links) {
        cap += Object.entries(pkg.links)
          .map(([a, b]) => `🔗 *${a.charAt(0).toUpperCase() + a.slice(1)}:* ${b}`)
          .join("\n")
      }
      cap += "\n\n"
    }

    reply(cap)
  } catch (err) {
    console.error("Error fetching npm package:", err)
    reply("*Terjadi kesalahan saat mencari package, coba lagi nanti.*")
  }
}

handler.command = ["npm", "npmjs", "package"]
export default handler
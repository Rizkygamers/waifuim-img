import axios from "axios";
import FormData from "form-data";
import { fileTypeFromBuffer } from "file-type";
import fetch from "node-fetch";
import fs from "fs";
import * as cheerio from "cheerio";

export async function upload(buffer, filename = "file.png") {
  try {
    const formData = new FormData();
    formData.append("fileToUpload", buffer, filename);
    formData.append("reqtype", "fileupload");
    formData.append("userhash", "");

    const response = await axios.post("https://catbox.moe/user/api.php", formData, {
      headers: { ...formData.getHeaders() },
    });

    return response.data;
  } catch (error) {
    console.error("Error at Catbox uploader:", error);
    return null;
  }
}

export async function CatBox(filePath) {
  try {
    const fileStream = fs.createReadStream(filePath);
    const formData = new FormData();
    formData.append("fileToUpload", fileStream);
    formData.append("reqtype", "fileupload");
    formData.append("userhash", "");

    const response = await axios.post("https://catbox.moe/user/api.php", formData, {
      headers: { ...formData.getHeaders() },
    });

    return response.data;
  } catch (error) {
    console.error("Error at Catbox uploader:", error);
    return "Terjadi kesalahan saat upload ke Catbox.";
  }
}

export function TelegraPh(Path) {
  return new Promise(async (resolve, reject) => {
    if (!fs.existsSync(Path)) return reject(new Error("File not Found"));
    try {
      const form = new FormData();
      form.append("file", fs.createReadStream(Path));
      const data = await axios({
        url: "https://telegra.ph/upload",
        method: "POST",
        headers: { ...form.getHeaders() },
        data: form,
      });
      return resolve("https://telegra.ph" + data.data[0].src);
    } catch (err) {
      return reject(new Error(String(err)));
    }
  });
}

export async function UploadFileUgu(input) {
  return new Promise(async (resolve, reject) => {
    const form = new FormData();
    form.append("files[]", fs.createReadStream(input));
    await axios({
      url: "https://uguu.se/upload.php",
      method: "POST",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
        ...form.getHeaders(),
      },
      data: form,
    })
      .then((data) => resolve(data.data.files[0]))
      .catch((err) => reject(err));
  });
}

export function webp2mp4File(path) {
  return new Promise((resolve, reject) => {
    const form = new FormData();
    form.append("new-image-url", "");
    form.append("new-image", fs.createReadStream(path));
    axios({
      method: "post",
      url: "https://s6.ezgif.com/webp-to-mp4",
      data: form,
      headers: { "Content-Type": `multipart/form-data; boundary=${form._boundary}` },
    })
      .then(({ data }) => {
        const bodyFormThen = new FormData();
        const $ = cheerio.load(data);
        const file = $('input[name="file"]').attr("value");
        bodyFormThen.append("file", file);
        bodyFormThen.append("convert", "Convert WebP to MP4!");
        axios({
          method: "post",
          url: "https://ezgif.com/webp-to-mp4/" + file,
          data: bodyFormThen,
          headers: { "Content-Type": `multipart/form-data; boundary=${bodyFormThen._boundary}` },
        })
          .then(({ data }) => {
            const $ = cheerio.load(data);
            const result = "https:" + $("div#output > p.outfile > video > source").attr("src");
            resolve({
              status: true,
              message: "Created By Jarr",
              result,
            });
          })
          .catch(reject);
      })
      .catch(reject);
  });
}

export async function floNime(medianya, options = {}) {
  const typeInfo = await fileTypeFromBuffer(medianya);
  const ext = typeInfo?.ext || options.ext || "bin"; 

  const form = new FormData();
  form.append("file", medianya, "tmp." + ext);

  const response = await fetch("https://flonime.my.id/upload", {
    method: "POST",
    body: form,
  });

  const jsonnya = await response.json();
  return jsonnya;
}
export async function uptotelegra(Path) {
  return new Promise(async (resolve, reject) => {
    if (!fs.existsSync(Path)) return reject(new Error("File not Found"));
    try {
      const form = new FormData();
      form.append("file", fs.createReadStream(Path));
      const data = await axios({
        url: "https://telegra.ph/upload",
        method: "POST",
        headers: { ...form.getHeaders() },
        data: form,
      });
      return resolve("https://telegra.ph" + data.data[0].src);
    } catch (err) {
      return reject(new Error(String(err)));
    }
  });
}
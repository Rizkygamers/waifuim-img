/*

  Created By Jarr Officiall 
  Wm Jarr Officiall 
  Telegram @jarroffc2
  
  Don't Delete WM!
  
*/

import canvafy from "canvafy"

async function welcomeBanner(avatar, background, description) {
  const image = await new canvafy.WelcomeLeave()
    .setAvatar(avatar)
    .setBackground("image", background)
    .setTitle("Welcome")
    .setDescription(description)
    .setBorder("#2a2e35")
    .setAvatarBorder("#2a2e35")
    .setOverlayOpacity(0.3)
    .build();

  return image;
}

async function leaveBanner(avatar, background, description) {
  const image = await new canvafy.WelcomeLeave()
    .setAvatar(avatar)
    .setBackground("image", background)
    .setTitle("Goodbye")
    .setDescription(description)
    .setBorder("#2a2e35")
    .setAvatarBorder("#2a2e35")
    .setOverlayOpacity(0.3)
    .build();

  return image;
}


export { welcomeBanner, leaveBanner };
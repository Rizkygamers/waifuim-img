/* wm : Jarr Officiall 
  telegram @jarroffc2
  
  Don't Delete WM 
*/

import fs from "fs";
import "../settings.js"
import "../control/function.js"
import { welcomeBanner, leaveBanner } from "./banner.js"
import { getGroup } from "../control/database.js"; 

async function WelcomeMessage(sock, update) {
  try {
      const { id, author, participants, action } = update;
      const groupData = await getGroup(id);
      
      const qtext = {
        key: {
          remoteJid: "0@s.whatsapp.net",
          participant: "0@s.whatsapp.net"
        },
        message: { extendedTextMessage: { text: "Group Information 💬" } }
      };

      let backgroundBuffer;
      try {
          backgroundBuffer = "https://raw.githubusercontent.com/jarroffc/dat1/main/uploads/6712bc-1764815730705.jpg"; 
      } catch (e) {
          console.error("Gagal membaca background URL", e.message);
          return; 
      }
      
      const metadata = await sock.groupMetadata(id);
      const groupName = metadata.subject;
          
      for (let n of participants) {
          let teks = "";
          let profile;
          
          try {
            profile = await sock.profilePictureUrl(n, "image");
          } catch {
            profile = "https://telegra.ph/file/265c672094dfa87caea19.jpg"; 
          }
          
          if (action === "add") {
              // Cek Database: Jika welcome mati (0), skip.
              if (groupData.welcome !== 1) continue; 

              teks = `Hallo @${n.split("@")[0]}, selamat datang di grup *${groupName}*

Ketik *.intro* untuk perkenalan 
*Jangan lupa baca deskripsi grup yaa kak 👀*`;

              let deskripsi = ucapan();
              const imgBuffer = await welcomeBanner(profile, backgroundBuffer, deskripsi);

              await sock.sendMessage(id, { 
                  text: teks,
                  contextInfo: {
                    mentionedJid: [author, n],
                    isForwarded: true,
                    externalAdReply: {
                      title: `Welcome friends`, 
                      body: ``,
                      thumbnail: imgBuffer,
                      sourceUrl: ``,
                      mediaType: 1,
                      renderLargerThumbnail: true 
                    }
                  }
              }, { quoted: qtext });

          } else if (action === "remove") {
              if (groupData.goodbye !== 1) continue;

              teks = `Yahh @${n.split("@")[0]}, malah keluar dari grup

*See you, sukses selalu 🤙*`;

              let deskripsi = ucapan();
              const imgBuffer = await leaveBanner(profile, backgroundBuffer, deskripsi);

              await sock.sendMessage(id, { 
                  text: teks,
                  contextInfo: {
                    mentionedJid: [author, n],
                    isForwarded: true,
                    externalAdReply: {
                      title: `Goodbye friends`, 
                      body: ``,
                      thumbnail: imgBuffer,
                      sourceUrl: ``,
                      mediaType: 1,
                      renderLargerThumbnail: true 
                    }
                  }
              }, { quoted: qtext });

          } else if (action === "promote") {
              if (groupData.welcome !== 1) continue;

              teks = `*Someone Got Promoted ⭐*

Kini @${n.split("@")[0]} menjadi *admin grup!*
Ditambahkan oleh @${author.split("@")[0]}`;

              await sock.sendMessage(id, { 
                  text: teks,
                  contextInfo: {
                    mentionedJid: [author, n],
                    isForwarded: true,
                    externalAdReply: {
                      title: `Congratulations on your promotion 🌻`, 
                      body: ``,
                      thumbnailUrl: "https://files.catbox.moe/s4l54p.jpg",
                      sourceUrl: ``,
                      mediaType: 1,
                      renderLargerThumbnail: true 
                    }
                  }
              }, { quoted: qtext });

          } else if (action === "demote") {
              if (groupData.welcome !== 1) continue;

              teks = `*Demote Information 📢*
            
Kini @${n.split("@")[0]} sudah bukan admin 
Diturunkan oleh @${author.split("@")[0]}`;

              await sock.sendMessage(id, { 
                  text: teks,
                  contextInfo: {
                    mentionedJid: [author, n],
                    isForwarded: true,
                    externalAdReply: {
                      title: `Yeah, I got demoted 👀`, 
                      body: ``,
                      thumbnailUrl: "https://files.catbox.moe/s4l54p.jpg",
                      sourceUrl: ``,
                      mediaType: 1,
                      renderLargerThumbnail: true 
                    }
                  }
              }, { quoted: qtext });
          }
      }
  } catch (e) {
    console.log("Error di WelcomeMessage:", e);
  }
}

export default WelcomeMessage;